# 开发补充与开工清单

[返回阅读入口](README.md) · [按功能阅读](features/README.md)

阅读顺序：[七类工程决定](#engineering-decisions) → [产品缺口摘要](#product-issues) → [开发待确认问题](#development-questions) → [开发待办明细](#development-issues)。

产品交接门禁检查需求是否完整；开发开工门禁检查工程决定、字段和接口映射、任务及验证是否完整。产品交接通过不代表业务编码已经具备开工条件。

允许先做代码库建立、脚手架、技术验证和方案评估等准备工作。门禁约束正式业务实现；准备工作的结果须回填后再核验。

开发负责技术选择和实现映射。业务含义、字段值域、权限、状态、异常及 UI 行为有疑问时交回产品负责人确认，不得由开发或 AI 猜测补齐。

证据引用须来自当前代码库快照；继承已有规范还须填写版本和本次适用范围。结构检查只核验证据可定位与快照一致，不代替语义审阅，也不表示测试已经执行。

<a id="engineering-decisions"></a>

## 七类工程决定

| 类别 | 状态 | 负责人员或角色 |
| --- | --- | --- |
| [脚手架与代码库入口](#engineering-scaffold) | pending | 开发负责人 |
| [技术栈与版本](#engineering-stack) | pending | 开发负责人 |
| [后端框架与服务边界](#engineering-backend) | pending | 开发负责人 |
| [数据约定与字段映射](#engineering-data) | pending | 开发负责人 |
| [接口约定](#engineering-api) | pending | 开发负责人及对应接口提供方 |
| [编码与协作规范](#engineering-coding) | pending | 开发负责人 |
| [测试与运行约定](#engineering-verification) | pending | 开发负责人 |

<a id="engineering-scaffold"></a>

### 脚手架与代码库入口

状态：pending；负责人员或角色：开发负责人

应补内容：代码库、目录与入口、复用或新建方式、依赖准备方式。

验收方式：提供可复现的准备检查步骤、预期结果与代码库证据；记录实际执行证据时另行说明结果。

当前决定：提供正式仓库路径、当前版本和构建/启动办法；当前HTML原型只作为已审业务演示，不能默认是生产仓库。

适用范围：正式仓库及脚手架；适用于v1.1.0的17项功能生产设计

代码库证据：未填写

<a id="engineering-stack"></a>

### 技术栈与版本

状态：pending；负责人员或角色：开发负责人

应补内容：语言、运行时、核心依赖及采用的版本范围。

验收方式：对照依赖清单或工程规范，确认与当前代码库及交付范围一致。

当前决定：确定前后端语言、框架、运行时和团队版本约束；产品的主子批语义与此选型无关，不能由演示HTML推定生产栈。

适用范围：团队技术栈与版本；适用于v1.1.0的17项功能生产设计

代码库证据：未填写

<a id="engineering-backend"></a>

### 后端框架与服务边界

状态：pending；负责人员或角色：开发负责人

应补内容：后端框架、服务职责、部署边界及对接方式；没有服务端时说明原因。

验收方式：核对架构和模块边界；前端原型可以说明不适用，不能虚构后端已经存在。

当前决定：在实际仓库中确定应用鉴权、DCC接收、供应商适配、事件归并、失败下载、回传服务边界及职责落点。

适用范围：服务边界与部署约束；适用于v1.1.0的17项功能生产设计

代码库证据：未填写

<a id="engineering-data"></a>

### 数据约定与字段映射

状态：pending；负责人员或角色：开发负责人

应补内容：业务字段到内存、传输或存储的映射；类型、空值、时间、标识、迁移约定。

验收方式：逐项对照字段规格；无数据库也需明确函数入参或本地数据约定。

当前决定：在真实数据库确定请求唯一约束、完整规范化摘要、逐行record/batch/root原子写、供应商fileId映射、事件去重、分片和下载快照保留；不预设表名与DDL。

适用范围：事务存储与并发一致性；适用于v1.1.0的17项功能生产设计

代码库证据：未填写

<a id="engineering-api"></a>

### 接口约定

状态：pending；负责人员或角色：开发负责人及对应接口提供方

应补内容：协议、路径或函数签名、请求响应、错误格式、认证和幂等约定。

验收方式：核对本次实际接口和产品行为；无远程接口时解释本地接口由哪份规范承担。

当前决定：逐项落实上游deferred协议，验证同号两次独立fileId与精确查询/删除隔离；保持未知、冲突、认证失败和超时不盲配不重交。

适用范围：正式接口与联调证据；适用于v1.1.0的17项功能生产设计

代码库证据：未填写

<a id="engineering-coding"></a>

### 编码与协作规范

状态：pending；负责人员或角色：开发负责人

应补内容：命名、目录归属、依赖限制、错误处理、提交和代码审阅规则。

验收方式：引用适用规范及版本，核对计划修改路径与编码约定。

当前决定：提供团队目录、命名、日志脱敏、密钥管理、错误码与依赖约束证据；不得在原型目录写业务后端。

适用范围：仓库编码与安全规范；适用于v1.1.0的17项功能生产设计

代码库证据：未填写

<a id="engineering-verification"></a>

### 测试与运行约定

状态：pending；负责人员或角色：开发负责人

应补内容：运行方式、环境、测试命令或手工步骤、预期结果与验收责任。

验收方式：将产品验收关联到可复现的开发验证；未执行的测试仅标记为计划。

当前决定：提供测试框架、命令及隔离联调环境；将CHECK验收转为同ID任务测试，复验并发重试、迟到事件、删除隔离、下载中断。

适用范围：可执行测试与环境；适用于v1.1.0的17项功能生产设计

代码库证据：未填写

<a id="product-issues"></a>

## 仍需产品方确认

这些问题不能通过补技术栈或把状态改为已完成而关闭。

产品侧共有 **8** 项结构阻塞。完整路径与内容见 [产品门禁完整报告](validation-report.md#product-gate)，本清单只汇总类别：

| 检查类别 | 数量 |
| --- | --- |
| `issue.deferred` | 8 |

<a id="development-questions"></a>

## 开发待确认问题

技术问题保留原始描述和分类依据；若问题涉及业务行为，须转交产品负责人确认，不能通过改变负责方来绕过产品语义审阅。

### ENG-SCAFFOLD

提供正式仓库路径、当前版本和构建/启动办法；当前HTML原型只作为已审业务演示，不能默认是生产仓库。

阻塞开发：是；工程类别：scaffold

分类依据：此项确定生产实现环境和工程落点，承接已批准业务含义而不改变功能范围；当前未提供真实仓库或对应技术证据。

### ENG-STACK

确定前后端语言、框架、运行时和团队版本约束；产品的主子批语义与此选型无关，不能由演示HTML推定生产栈。

阻塞开发：是；工程类别：stack

分类依据：此项确定生产实现环境和工程落点，承接已批准业务含义而不改变功能范围；当前未提供真实仓库或对应技术证据。

### ENG-BACKEND

在实际仓库中确定应用鉴权、DCC接收、供应商适配、事件归并、失败下载、回传服务边界及职责落点。

阻塞开发：是；工程类别：backend

分类依据：此项确定生产实现环境和工程落点，承接已批准业务含义而不改变功能范围；当前未提供真实仓库或对应技术证据。

### ENG-DATA

在真实数据库确定请求唯一约束、完整规范化摘要、逐行record/batch/root原子写、供应商fileId映射、事件去重、分片和下载快照保留；不预设表名与DDL。

阻塞开发：是；工程类别：data

分类依据：此项确定生产实现环境和工程落点，承接已批准业务含义而不改变功能范围；当前未提供真实仓库或对应技术证据。

### ENG-API

逐项落实上游deferred协议，验证同号两次独立fileId与精确查询/删除隔离；保持未知、冲突、认证失败和超时不盲配不重交。

阻塞开发：是；工程类别：api

分类依据：此项确定生产实现环境和工程落点，承接已批准业务含义而不改变功能范围；当前未提供真实仓库或对应技术证据。

### ENG-CODING

提供团队目录、命名、日志脱敏、密钥管理、错误码与依赖约束证据；不得在原型目录写业务后端。

阻塞开发：是；工程类别：coding

分类依据：此项确定生产实现环境和工程落点，承接已批准业务含义而不改变功能范围；当前未提供真实仓库或对应技术证据。

### ENG-VERIFICATION

提供测试框架、命令及隔离联调环境；将CHECK验收转为同ID任务测试，复验并发重试、迟到事件、删除隔离、下载中断。

阻塞开发：是；工程类别：verification

分类依据：此项确定生产实现环境和工程落点，承接已批准业务含义而不改变功能范围；当前未提供真实仓库或对应技术证据。

<a id="development-issues"></a>

## 仍需开发方完成

开发侧另有 **1309** 项结构阻塞。共同依赖的产品缺口见上方摘要；不转派给开发方。

逐条补回 engineering.json 或计划中的相应技术字段，再运行开发开工检查；不要只在本阅读文档中打勾。

<details>
<summary>展开开发待办的完整路径与检查原因</summary>

- `plan.technical_design.interfaces[10].inputs[1]`：Replace placeholder content with a reviewed decision.（placeholder）
- `plan.technical_design.interfaces[12].caller`：Replace placeholder content with a reviewed decision.（placeholder）
- `plan.technical_design.interfaces[14].caller`：Replace placeholder content with a reviewed decision.（placeholder）
- `repository.root`：Provide an explicit target repository directory; a new project may use an existing empty directory.（repository.root）
- `engineering.stack`：At least one concrete entry is required.（required）
- `engineering.modules`：At least one entry is required.（required）
- `plan.technical_design.modules`：At least one entry is required.（required）
- `plan.technical_design.modules`：Features lack a design module: FUNC-001, FUNC-002, FUNC-004, FUNC-005, FUNC-006, FUNC-009, FUNC-010, FUNC-011, FUNC-012, FUNC-013, FUNC-015, FUNC-016, FUNC-017, FUNC-018, FUNC-019, FUNC-020, FUNC-021（coverage.design）
- `plan.tasks`：At least one entry is required.（required）
- `plan.tasks`：Missing coverage: FUNC-001, FUNC-002, FUNC-004, FUNC-005, FUNC-006, FUNC-009, FUNC-010, FUNC-011, FUNC-012, FUNC-013, FUNC-015, FUNC-016, FUNC-017, FUNC-018, FUNC-019, FUNC-020, FUNC-021（coverage.features）
- `plan.tasks`：Missing coverage: AC-001, AC-002, AC-003, AC-004, AC-005, AC-006, AC-007, AC-008, AC-009, AC-010, AC-011, AC-012, AC-013, AC-014, AC-015, AC-016, AC-017, AC-018, AC-019, AC-020, AC-021, AC-022, AC-023, AC-024, AC-025, AC-026, AC-027, AC-028, AC-029, AC-030, AC-031, AC-032, AC-033, AC-034, AC-035, AC-036, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-044, AC-045, AC-046, AC-047, AC-048, AC-049, AC-050, AC-051, AC-052, AC-053, AC-054, AC-055, AC-056, AC-057, AC-058, AC-059, AC-060, AC-061, AC-062（coverage.acceptance）
- `plan.tasks.tests`：Missing coverage: AC-001, AC-002, AC-003, AC-004, AC-005, AC-006, AC-007, AC-008, AC-009, AC-010, AC-011, AC-012, AC-013, AC-014, AC-015, AC-016, AC-017, AC-018, AC-019, AC-020, AC-021, AC-022, AC-023, AC-024, AC-025, AC-026, AC-027, AC-028, AC-029, AC-030, AC-031, AC-032, AC-033, AC-034, AC-035, AC-036, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-044, AC-045, AC-046, AC-047, AC-048, AC-049, AC-050, AC-051, AC-052, AC-053, AC-054, AC-055, AC-056, AC-057, AC-058, AC-059, AC-060, AC-061, AC-062（coverage.tests）
- `plan.open_questions[0]`：Resolve blocking questions owned by this stage before export.（question.blocking）
- `plan.open_questions[1]`：Resolve blocking questions owned by this stage before export.（question.blocking）
- `plan.open_questions[2]`：Resolve blocking questions owned by this stage before export.（question.blocking）
- `plan.open_questions[3]`：Resolve blocking questions owned by this stage before export.（question.blocking）
- `plan.open_questions[4]`：Resolve blocking questions owned by this stage before export.（question.blocking）
- `plan.open_questions[5]`：Resolve blocking questions owned by this stage before export.（question.blocking）
- `plan.open_questions[6]`：Resolve blocking questions owned by this stage before export.（question.blocking）
- `plan.acceptance_checks[CHECK-001]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-002]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-003]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-004]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-005]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-006]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-007]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-008]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-009]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-010]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-011]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-012]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-013]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-014]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-015]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-016]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-017]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-018]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-019]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-020]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-021]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-022]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-023]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-024]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-025]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-026]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-027]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-028]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-029]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-030]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-031]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-032]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-033]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-034]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-035]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-036]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-037]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-038]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-039]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-040]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-041]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-042]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-043]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-044]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-045]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-046]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-047]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-048]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-049]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-050]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-051]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-052]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-053]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-054]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-055]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-056]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-057]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-058]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-059]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-060]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-061]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.acceptance_checks[CHECK-062]`：Each product scenario needs a task test with the same ID.（acceptance_check.unimplemented）
- `plan.logic.locals[LOCAL-001].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-002].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-004-B].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-004].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-004-A].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-005].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-006].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-009].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-010].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-011].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-012].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-013].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-015].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-016].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-017].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-018].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-019].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-020].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.locals[LOCAL-021].module`：Local logic must name an engineering module.（logic.local.module）
- `plan.logic.fields[FLD-001].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-001].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-001].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-002].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-002].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-002].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-003].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-003].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-003].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-004].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-004].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-004].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-006].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-006].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-006].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-007].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-007].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-007].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-008].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-008].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-008].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-PHONE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-PHONE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-PHONE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-009].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-009].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-009].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-010].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-010].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-010].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-011].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-011].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-011].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-013].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-013].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-013].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-ROW-ID].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-ROW-ID].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-ROW-ID].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-BATCH-KIND].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-BATCH-KIND].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-BATCH-KIND].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-015].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-015].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-015].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-020].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-020].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-020].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-021].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-021].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-021].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-022].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-022].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-022].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-023].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-023].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-023].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-025].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-025].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-025].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-026].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-026].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-026].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-027].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-027].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-027].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-028].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-028].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-028].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-029].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-029].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-029].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-030].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-030].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-030].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-031].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-031].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-031].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-033].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-033].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-033].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-035].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-035].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-035].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-036].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-036].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-036].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-EVENT-TYPE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EVENT-TYPE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EVENT-TYPE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-EVENT-PAYLOAD].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EVENT-PAYLOAD].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EVENT-PAYLOAD].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-040].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-040].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-040].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-041].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-041].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-041].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-043].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-043].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-043].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-044].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-044].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-044].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-045].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-045].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-045].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-046].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-046].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-046].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-047].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-047].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-047].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-048].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-048].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-048].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-049].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-049].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-049].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-050].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-050].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-050].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-051].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-051].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-051].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-STATUS-DESC].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-STATUS-DESC].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-STATUS-DESC].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-052].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-052].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-052].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-054].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-054].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-054].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-OCCURRED-AT].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-OCCURRED-AT].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-OCCURRED-AT].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-RESULT-STAGE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RESULT-STAGE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RESULT-STAGE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-RESULT-REASON].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RESULT-REASON].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RESULT-REASON].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-CUSTOMER-ANSWERED].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-CUSTOMER-ANSWERED].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-CUSTOMER-ANSWERED].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-AGENT-ANSWERED].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-AGENT-ANSWERED].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-AGENT-ANSWERED].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-SHORT-HANGUP].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-SHORT-HANGUP].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-SHORT-HANGUP].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-066].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-066].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-066].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-EVIDENCE-SOURCE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EVIDENCE-SOURCE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EVIDENCE-SOURCE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-068].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-068].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-068].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-070].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-070].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-070].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-071].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-071].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-071].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-APP-PAGE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-APP-PAGE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-APP-PAGE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-APP-ID].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-APP-ID].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-APP-ID].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-APP-CREATED].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-APP-CREATED].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-APP-CREATED].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-089].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-089].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-089].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-090].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-090].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-090].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-093].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-093].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-093].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-ORIGINAL-IMPORT-AT].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-ORIGINAL-IMPORT-AT].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-ORIGINAL-IMPORT-AT].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-RECEIVED-AT].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RECEIVED-AT].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RECEIVED-AT].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-BATCH-CREATED-AT].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-BATCH-CREATED-AT].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-BATCH-CREATED-AT].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-RECEIVED-SEQUENCE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RECEIVED-SEQUENCE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RECEIVED-SEQUENCE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FLD-078].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-078].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FLD-078].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-SUBMISSION-STATE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-SUBMISSION-STATE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-SUBMISSION-STATE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-FRAGMENT-COMPLETENESS].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-FRAGMENT-COMPLETENESS].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-FRAGMENT-COMPLETENESS].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-EXPORT-SNAPSHOT].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EXPORT-SNAPSHOT].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-EXPORT-SNAPSHOT].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-DOWNLOAD-STATE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DOWNLOAD-STATE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DOWNLOAD-STATE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-DEDUP-EVIDENCE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DEDUP-EVIDENCE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DEDUP-EVIDENCE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-DELIVERY-STATE].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DELIVERY-STATE].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DELIVERY-STATE].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-RESULT-VERSION].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RESULT-VERSION].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-RESULT-VERSION].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-REVIEW-REASON].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-REVIEW-REASON].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-REVIEW-REASON].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-UNTRUSTED-SIP].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-UNTRUSTED-SIP].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-UNTRUSTED-SIP].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-CSV-TEXT].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-CSV-TEXT].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-CSV-TEXT].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-CSV-PREVIEW].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-CSV-PREVIEW].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-CSV-PREVIEW].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-DELETION-SELECTION].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DELETION-SELECTION].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DELETION-SELECTION].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.fields[FIELD-DELETION-FEEDBACK].interface_note`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DELETION-FEEDBACK].persistence.mapping`：Provide an explicit nonempty statement.（logic.required.text）
- `plan.logic.fields[FIELD-DELETION-FEEDBACK].interfaces`：Expected an array of objects.（logic.type.array）
- `plan.logic.units[GR-001].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-001].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[GR-001].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[GR-001].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[GR-001].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[GR-001].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[GR-001].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-010（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-006（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-007（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-001（logic.test.unknown）
- `plan.logic.units[GR-002].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[GR-003].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-003].test_refs`：Unknown task test: CHECK-009（logic.test.unknown）
- `plan.logic.units[GR-003].test_refs`：Unknown task test: CHECK-005（logic.test.unknown）
- `plan.logic.units[GR-003].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[GR-003].test_refs`：Unknown task test: CHECK-030（logic.test.unknown）
- `plan.logic.units[GR-004].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-004].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[GR-004].test_refs`：Unknown task test: CHECK-011（logic.test.unknown）
- `plan.logic.units[GR-004].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[GR-004].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[GR-004].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[GR-005].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-005].test_refs`：Unknown task test: CHECK-031（logic.test.unknown）
- `plan.logic.units[GR-005].test_refs`：Unknown task test: CHECK-008（logic.test.unknown）
- `plan.logic.units[GR-005].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[GR-006].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-006].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[GR-006].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[GR-006].test_refs`：Unknown task test: CHECK-015（logic.test.unknown）
- `plan.logic.units[GR-007].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-007].test_refs`：Unknown task test: CHECK-061（logic.test.unknown）
- `plan.logic.units[GR-007].test_refs`：Unknown task test: CHECK-016（logic.test.unknown）
- `plan.logic.units[GR-007].test_refs`：Unknown task test: CHECK-024（logic.test.unknown）
- `plan.logic.units[GR-007].test_refs`：Unknown task test: CHECK-025（logic.test.unknown）
- `plan.logic.units[GR-008].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-008].test_refs`：Unknown task test: CHECK-002（logic.test.unknown）
- `plan.logic.units[GR-008].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[GR-008].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[GR-009].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-009].test_refs`：Unknown task test: CHECK-003（logic.test.unknown）
- `plan.logic.units[GR-009].test_refs`：Unknown task test: CHECK-033（logic.test.unknown）
- `plan.logic.units[GR-009].test_refs`：Unknown task test: CHECK-020（logic.test.unknown）
- `plan.logic.units[GR-010].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-010].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[GR-010].test_refs`：Unknown task test: CHECK-034（logic.test.unknown）
- `plan.logic.units[GR-011].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-011].test_refs`：Unknown task test: CHECK-022（logic.test.unknown）
- `plan.logic.units[GR-011].test_refs`：Unknown task test: CHECK-004（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-019（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[GR-012].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[GR-013].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-013].test_refs`：Unknown task test: CHECK-027（logic.test.unknown）
- `plan.logic.units[GR-013].test_refs`：Unknown task test: CHECK-026（logic.test.unknown）
- `plan.logic.units[GR-014].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-014].test_refs`：Unknown task test: CHECK-031（logic.test.unknown）
- `plan.logic.units[GR-014].test_refs`：Unknown task test: CHECK-060（logic.test.unknown）
- `plan.logic.units[GR-014].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[GR-014].test_refs`：Unknown task test: CHECK-059（logic.test.unknown）
- `plan.logic.units[GR-014].test_refs`：Unknown task test: CHECK-030（logic.test.unknown）
- `plan.logic.units[GR-015].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-015].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[GR-015].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[GR-015].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[GR-015].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[GR-015].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[GR-015].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[GR-016].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-016].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[GR-016].test_refs`：Unknown task test: CHECK-059（logic.test.unknown）
- `plan.logic.units[GR-016].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[GR-017].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-017].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[GR-017].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[GR-017].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[GR-017].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[GR-017].test_refs`：Unknown task test: CHECK-037（logic.test.unknown）
- `plan.logic.units[GR-018].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-018].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[GR-018].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[GR-018].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[GR-018].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[GR-019].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-019].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[GR-019].test_refs`：Unknown task test: CHECK-008（logic.test.unknown）
- `plan.logic.units[GR-019].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[GR-019].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-054（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[GR-020].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[GR-021].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GR-021].test_refs`：Unknown task test: CHECK-009（logic.test.unknown）
- `plan.logic.units[GR-021].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[GR-021].test_refs`：Unknown task test: CHECK-030（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-054（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[GFLOW-APP].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-009（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-007（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-015（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-001（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-012（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-011（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-010（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-019（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-006（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-005（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[GFLOW-DCC].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-031（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-060（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-007（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-005（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-001（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-059（logic.test.unknown）
- `plan.logic.units[GFLOW-MANUAL].test_refs`：Unknown task test: CHECK-030（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-026（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-022（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-004（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-002（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-003（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-033（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-027（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-034（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-020（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[GFLOW-RESULT].test_refs`：Unknown task test: CHECK-037（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-031（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-008（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[GFLOW-FAILURE].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[GFLOW-DELETE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[GFLOW-DELETE].test_refs`：Unknown task test: CHECK-025（logic.test.unknown）
- `plan.logic.units[GFLOW-DELETE].test_refs`：Unknown task test: CHECK-016（logic.test.unknown）
- `plan.logic.units[GFLOW-DELETE].test_refs`：Unknown task test: CHECK-024（logic.test.unknown）
- `plan.logic.units[GFLOW-DELETE].test_refs`：Unknown task test: CHECK-061（logic.test.unknown）
- `plan.logic.units[GFLOW-DELETE].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[LOCAL-001].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-001].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[LOCAL-001].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[LOCAL-001].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[LOCAL-001].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[LOCAL-001].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[LOCAL-002].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-002].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[LOCAL-002].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[LOCAL-002].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[LOCAL-002].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[LOCAL-002].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[LOCAL-002].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-012（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-010（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-006（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-019（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[LOCAL-004-B].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-010（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-009（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-006（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-007（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-015（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-005（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-019（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-001（logic.test.unknown）
- `plan.logic.units[LOCAL-004].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-031（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-060（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-007（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-015（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-005（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-001（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-059（logic.test.unknown）
- `plan.logic.units[LOCAL-004-A].test_refs`：Unknown task test: CHECK-030（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-012（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-011（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-015（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-019（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[LOCAL-005].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-031（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-008（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[LOCAL-006].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[LOCAL-009].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-009].test_refs`：Unknown task test: CHECK-025（logic.test.unknown）
- `plan.logic.units[LOCAL-009].test_refs`：Unknown task test: CHECK-016（logic.test.unknown）
- `plan.logic.units[LOCAL-009].test_refs`：Unknown task test: CHECK-024（logic.test.unknown）
- `plan.logic.units[LOCAL-009].test_refs`：Unknown task test: CHECK-061（logic.test.unknown）
- `plan.logic.units[LOCAL-009].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-026（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-002（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-027（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[LOCAL-010].test_refs`：Unknown task test: CHECK-037（logic.test.unknown）
- `plan.logic.units[LOCAL-011].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-011].test_refs`：Unknown task test: CHECK-022（logic.test.unknown）
- `plan.logic.units[LOCAL-011].test_refs`：Unknown task test: CHECK-004（logic.test.unknown）
- `plan.logic.units[LOCAL-011].test_refs`：Unknown task test: CHECK-024（logic.test.unknown）
- `plan.logic.units[LOCAL-011].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[LOCAL-011].test_refs`：Unknown task test: CHECK-034（logic.test.unknown）
- `plan.logic.units[LOCAL-011].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[LOCAL-012].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-012].test_refs`：Unknown task test: CHECK-003（logic.test.unknown）
- `plan.logic.units[LOCAL-012].test_refs`：Unknown task test: CHECK-033（logic.test.unknown）
- `plan.logic.units[LOCAL-012].test_refs`：Unknown task test: CHECK-020（logic.test.unknown）
- `plan.logic.units[LOCAL-013].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-013].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[LOCAL-013].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[LOCAL-013].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[LOCAL-013].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[LOCAL-013].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[LOCAL-013].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[LOCAL-013].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-015（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-037（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-019（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-059（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[LOCAL-015].test_refs`：Unknown task test: CHECK-028（logic.test.unknown）
- `plan.logic.units[LOCAL-016].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-016].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[LOCAL-016].test_refs`：Unknown task test: CHECK-059（logic.test.unknown）
- `plan.logic.units[LOCAL-016].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[LOCAL-017].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-017].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[LOCAL-017].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[LOCAL-017].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[LOCAL-017].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[LOCAL-017].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[LOCAL-018].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-018].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[LOCAL-018].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[LOCAL-018].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[LOCAL-018].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[LOCAL-018].test_refs`：Unknown task test: CHECK-028（logic.test.unknown）
- `plan.logic.units[LOCAL-019].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-019].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[LOCAL-019].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[LOCAL-019].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[LOCAL-019].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[LOCAL-019].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[LOCAL-020].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-020].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[LOCAL-020].test_refs`：Unknown task test: CHECK-054（logic.test.unknown）
- `plan.logic.units[LOCAL-020].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[LOCAL-020].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[LOCAL-020].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[LOCAL-021].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[LOCAL-021].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[LOCAL-021].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[LOCAL-021].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[LOCAL-021].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[FLD-001].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-001].test_refs`：Unknown task test: CHECK-005（logic.test.unknown）
- `plan.logic.units[FLD-002].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-002].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[FLD-002].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[FLD-002].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[FLD-003].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-003].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[FLD-003].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[FLD-003].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[FLD-004].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-004].test_refs`：Unknown task test: CHECK-012（logic.test.unknown）
- `plan.logic.units[FLD-004].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[FLD-004].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[FLD-006].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-006].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[FLD-006].test_refs`：Unknown task test: CHECK-044（logic.test.unknown）
- `plan.logic.units[FLD-006].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[FLD-006].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[FLD-006].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[FLD-007].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-007].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[FLD-007].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[FLD-007].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[FLD-007].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[FLD-007].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[FLD-008].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-008].test_refs`：Unknown task test: CHECK-031（logic.test.unknown）
- `plan.logic.units[FLD-008].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[FLD-008].test_refs`：Unknown task test: CHECK-001（logic.test.unknown）
- `plan.logic.units[FLD-008].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-PHONE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-PHONE].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-PHONE].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[FIELD-PHONE].test_refs`：Unknown task test: CHECK-001（logic.test.unknown）
- `plan.logic.units[FIELD-PHONE].test_refs`：Unknown task test: CHECK-006（logic.test.unknown）
- `plan.logic.units[FLD-009].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-009].test_refs`：Unknown task test: CHECK-009（logic.test.unknown）
- `plan.logic.units[FLD-009].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[FLD-009].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[FLD-009].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[FLD-009].test_refs`：Unknown task test: CHECK-030（logic.test.unknown）
- `plan.logic.units[FLD-010].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-010].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FLD-010].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[FLD-010].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[FLD-010].test_refs`：Unknown task test: CHECK-006（logic.test.unknown）
- `plan.logic.units[FLD-011].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-011].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FLD-011].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[FLD-011].test_refs`：Unknown task test: CHECK-006（logic.test.unknown）
- `plan.logic.units[FLD-013].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-013].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FLD-013].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[FLD-013].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[FIELD-ROW-ID].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-ROW-ID].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[FIELD-ROW-ID].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-ROW-ID].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[FIELD-ROW-ID].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[FIELD-BATCH-KIND].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-BATCH-KIND].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-BATCH-KIND].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[FLD-015].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-015].test_refs`：Unknown task test: CHECK-051（logic.test.unknown）
- `plan.logic.units[FLD-015].test_refs`：Unknown task test: CHECK-047（logic.test.unknown）
- `plan.logic.units[FLD-015].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[FLD-015].test_refs`：Unknown task test: CHECK-007（logic.test.unknown）
- `plan.logic.units[FLD-020].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-020].test_refs`：Unknown task test: CHECK-012（logic.test.unknown）
- `plan.logic.units[FLD-020].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FLD-020].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-020].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FLD-021].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-021].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FLD-021].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-022].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-022].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FLD-022].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-023].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-023].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FLD-023].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-025].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-025].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FLD-025].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[FLD-026].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-026].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FLD-026].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[FLD-027].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-027].test_refs`：Unknown task test: CHECK-003（logic.test.unknown）
- `plan.logic.units[FLD-027].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-028].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-028].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FLD-028].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-028].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-029].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-029].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-029].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-030].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-030].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FLD-030].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[FLD-030].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[FLD-030].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-031].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-031].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FLD-031].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-031].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-033].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-033].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-033].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-035].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-035].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FLD-035].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-035].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-036].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-036].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FLD-036].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FIELD-EVENT-TYPE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-EVENT-TYPE].test_refs`：Unknown task test: CHECK-003（logic.test.unknown）
- `plan.logic.units[FIELD-EVENT-TYPE].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FIELD-EVENT-PAYLOAD].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-EVENT-PAYLOAD].test_refs`：Unknown task test: CHECK-003（logic.test.unknown）
- `plan.logic.units[FIELD-EVENT-PAYLOAD].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FIELD-EVENT-PAYLOAD].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FIELD-EVENT-PAYLOAD].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FLD-040].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-040].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[FLD-040].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-041].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-041].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[FLD-041].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-043].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-043].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[FLD-043].test_refs`：Unknown task test: CHECK-034（logic.test.unknown）
- `plan.logic.units[FLD-044].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-044].test_refs`：Unknown task test: CHECK-002（logic.test.unknown）
- `plan.logic.units[FLD-044].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-045].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-045].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-045].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[FLD-046].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-046].test_refs`：Unknown task test: CHECK-033（logic.test.unknown）
- `plan.logic.units[FLD-046].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[FLD-047].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-047].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FLD-047].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[FLD-047].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-048].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-048].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[FLD-048].test_refs`：Unknown task test: CHECK-034（logic.test.unknown）
- `plan.logic.units[FLD-049].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-049].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FLD-049].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[FLD-049].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-050].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-050].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FLD-050].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[FLD-050].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-051].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-051].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[FLD-051].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-051].test_refs`：Unknown task test: CHECK-038（logic.test.unknown）
- `plan.logic.units[FIELD-STATUS-DESC].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-STATUS-DESC].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[FIELD-STATUS-DESC].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-052].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-052].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-052].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[FLD-052].test_refs`：Unknown task test: CHECK-027（logic.test.unknown）
- `plan.logic.units[FLD-054].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-054].test_refs`：Unknown task test: CHECK-061（logic.test.unknown）
- `plan.logic.units[FLD-054].test_refs`：Unknown task test: CHECK-016（logic.test.unknown）
- `plan.logic.units[FLD-054].test_refs`：Unknown task test: CHECK-024（logic.test.unknown）
- `plan.logic.units[FLD-054].test_refs`：Unknown task test: CHECK-025（logic.test.unknown）
- `plan.logic.units[FIELD-OCCURRED-AT].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-OCCURRED-AT].test_refs`：Unknown task test: CHECK-033（logic.test.unknown）
- `plan.logic.units[FIELD-OCCURRED-AT].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[FIELD-OCCURRED-AT].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-STAGE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-RESULT-STAGE].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-STAGE].test_refs`：Unknown task test: CHECK-013（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-STAGE].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-REASON].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-RESULT-REASON].test_refs`：Unknown task test: CHECK-002（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-REASON].test_refs`：Unknown task test: CHECK-033（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-REASON].test_refs`：Unknown task test: CHECK-020（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-REASON].test_refs`：Unknown task test: CHECK-003（logic.test.unknown）
- `plan.logic.units[FIELD-CUSTOMER-ANSWERED].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-CUSTOMER-ANSWERED].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[FIELD-CUSTOMER-ANSWERED].test_refs`：Unknown task test: CHECK-034（logic.test.unknown）
- `plan.logic.units[FIELD-AGENT-ANSWERED].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-AGENT-ANSWERED].test_refs`：Unknown task test: CHECK-018（logic.test.unknown）
- `plan.logic.units[FIELD-AGENT-ANSWERED].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[FIELD-SHORT-HANGUP].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-SHORT-HANGUP].test_refs`：Unknown task test: CHECK-004（logic.test.unknown）
- `plan.logic.units[FIELD-SHORT-HANGUP].test_refs`：Unknown task test: CHECK-021（logic.test.unknown）
- `plan.logic.units[FIELD-SHORT-HANGUP].test_refs`：Unknown task test: CHECK-034（logic.test.unknown）
- `plan.logic.units[FLD-066].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-066].test_refs`：Unknown task test: CHECK-033（logic.test.unknown）
- `plan.logic.units[FLD-066].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-066].test_refs`：Unknown task test: CHECK-023（logic.test.unknown）
- `plan.logic.units[FLD-066].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-EVIDENCE-SOURCE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-EVIDENCE-SOURCE].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FIELD-EVIDENCE-SOURCE].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FIELD-EVIDENCE-SOURCE].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-068].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-068].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[FLD-068].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FLD-068].test_refs`：Unknown task test: CHECK-037（logic.test.unknown）
- `plan.logic.units[FLD-070].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-070].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[FLD-071].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-071].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[FIELD-APP-PAGE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-APP-PAGE].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[FIELD-APP-ID].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-APP-ID].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[FIELD-APP-ID].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[FIELD-APP-ID].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[FIELD-APP-ID].test_refs`：Unknown task test: CHECK-054（logic.test.unknown）
- `plan.logic.units[FIELD-APP-CREATED].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-APP-CREATED].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[FIELD-APP-CREATED].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[FIELD-APP-CREATED].test_refs`：Unknown task test: CHECK-054（logic.test.unknown）
- `plan.logic.units[FLD-089].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-089].test_refs`：Unknown task test: CHECK-017（logic.test.unknown）
- `plan.logic.units[FLD-089].test_refs`：Unknown task test: CHECK-057（logic.test.unknown）
- `plan.logic.units[FLD-089].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[FLD-089].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[FLD-090].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-090].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[FLD-090].test_refs`：Unknown task test: CHECK-053（logic.test.unknown）
- `plan.logic.units[FLD-090].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[FLD-090].test_refs`：Unknown task test: CHECK-054（logic.test.unknown）
- `plan.logic.units[FLD-093].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-093].test_refs`：Unknown task test: CHECK-045（logic.test.unknown）
- `plan.logic.units[FLD-093].test_refs`：Unknown task test: CHECK-054（logic.test.unknown）
- `plan.logic.units[FLD-093].test_refs`：Unknown task test: CHECK-055（logic.test.unknown）
- `plan.logic.units[FLD-093].test_refs`：Unknown task test: CHECK-058（logic.test.unknown）
- `plan.logic.units[FLD-093].test_refs`：Unknown task test: CHECK-056（logic.test.unknown）
- `plan.logic.units[FIELD-ORIGINAL-IMPORT-AT].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-ORIGINAL-IMPORT-AT].test_refs`：Unknown task test: CHECK-032（logic.test.unknown）
- `plan.logic.units[FIELD-ORIGINAL-IMPORT-AT].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[FIELD-ORIGINAL-IMPORT-AT].test_refs`：Unknown task test: CHECK-015（logic.test.unknown）
- `plan.logic.units[FIELD-RECEIVED-AT].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-RECEIVED-AT].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[FIELD-RECEIVED-AT].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[FIELD-BATCH-CREATED-AT].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-BATCH-CREATED-AT].test_refs`：Unknown task test: CHECK-014（logic.test.unknown）
- `plan.logic.units[FIELD-BATCH-CREATED-AT].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[FIELD-RECEIVED-SEQUENCE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-RECEIVED-SEQUENCE].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[FIELD-RECEIVED-SEQUENCE].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[FIELD-RECEIVED-SEQUENCE].test_refs`：Unknown task test: CHECK-048（logic.test.unknown）
- `plan.logic.units[FLD-078].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FLD-078].test_refs`：Unknown task test: CHECK-029（logic.test.unknown）
- `plan.logic.units[FLD-078].test_refs`：Unknown task test: CHECK-059（logic.test.unknown）
- `plan.logic.units[FLD-078].test_refs`：Unknown task test: CHECK-036（logic.test.unknown）
- `plan.logic.units[FIELD-SUBMISSION-STATE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-SUBMISSION-STATE].test_refs`：Unknown task test: CHECK-039（logic.test.unknown）
- `plan.logic.units[FIELD-SUBMISSION-STATE].test_refs`：Unknown task test: CHECK-046（logic.test.unknown）
- `plan.logic.units[FIELD-SUBMISSION-STATE].test_refs`：Unknown task test: CHECK-011（logic.test.unknown）
- `plan.logic.units[FIELD-FRAGMENT-COMPLETENESS].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-FRAGMENT-COMPLETENESS].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FIELD-FRAGMENT-COMPLETENESS].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FIELD-FRAGMENT-COMPLETENESS].test_refs`：Unknown task test: CHECK-040（logic.test.unknown）
- `plan.logic.units[FIELD-EXPORT-SNAPSHOT].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-EXPORT-SNAPSHOT].test_refs`：Unknown task test: CHECK-008（logic.test.unknown）
- `plan.logic.units[FIELD-EXPORT-SNAPSHOT].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FIELD-EXPORT-SNAPSHOT].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FIELD-DOWNLOAD-STATE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-DOWNLOAD-STATE].test_refs`：Unknown task test: CHECK-008（logic.test.unknown）
- `plan.logic.units[FIELD-DOWNLOAD-STATE].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FIELD-DOWNLOAD-STATE].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FIELD-DEDUP-EVIDENCE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-DEDUP-EVIDENCE].test_refs`：Unknown task test: CHECK-042（logic.test.unknown）
- `plan.logic.units[FIELD-DEDUP-EVIDENCE].test_refs`：Unknown task test: CHECK-050（logic.test.unknown）
- `plan.logic.units[FIELD-DEDUP-EVIDENCE].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-DELIVERY-STATE].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-DELIVERY-STATE].test_refs`：Unknown task test: CHECK-041（logic.test.unknown）
- `plan.logic.units[FIELD-DELIVERY-STATE].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FIELD-DELIVERY-STATE].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-DELIVERY-STATE].test_refs`：Unknown task test: CHECK-037（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-VERSION].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-RESULT-VERSION].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-VERSION].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FIELD-RESULT-VERSION].test_refs`：Unknown task test: CHECK-052（logic.test.unknown）
- `plan.logic.units[FIELD-REVIEW-REASON].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-REVIEW-REASON].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FIELD-REVIEW-REASON].test_refs`：Unknown task test: CHECK-043（logic.test.unknown）
- `plan.logic.units[FIELD-REVIEW-REASON].test_refs`：Unknown task test: CHECK-035（logic.test.unknown）
- `plan.logic.units[FIELD-REVIEW-REASON].test_refs`：Unknown task test: CHECK-049（logic.test.unknown）
- `plan.logic.units[FIELD-UNTRUSTED-SIP].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-UNTRUSTED-SIP].test_refs`：Unknown task test: CHECK-062（logic.test.unknown）
- `plan.logic.units[FIELD-CSV-TEXT].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-CSV-TEXT].test_refs`：Unknown task test: CHECK-060（logic.test.unknown）
- `plan.logic.units[FIELD-CSV-PREVIEW].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-CSV-PREVIEW].test_refs`：Unknown task test: CHECK-060（logic.test.unknown）
- `plan.logic.units[FIELD-CSV-PREVIEW].test_refs`：Unknown task test: CHECK-030（logic.test.unknown）
- `plan.logic.units[FIELD-DELETION-SELECTION].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-DELETION-SELECTION].test_refs`：Unknown task test: CHECK-061（logic.test.unknown）
- `plan.logic.units[FIELD-DELETION-FEEDBACK].test_refs`：Each logic unit and field must be referenced by an implementation task.（logic.unit.unowned）
- `plan.logic.units[FIELD-DELETION-FEEDBACK].test_refs`：Unknown task test: CHECK-061（logic.test.unknown）
- `plan.logic.locals[LOCAL-001].branches[LOCAL-001-B01]`：Unknown branch test: CHECK-056（logic.test.unknown）
- `plan.logic.locals[LOCAL-001].branches[LOCAL-001-B01]`：Unknown branch test: CHECK-044（logic.test.unknown）
- `plan.logic.locals[LOCAL-001].branches[LOCAL-001-B02]`：Unknown branch test: CHECK-056（logic.test.unknown）
- `plan.logic.locals[LOCAL-002].branches[LOCAL-002-B01]`：Unknown branch test: CHECK-017（logic.test.unknown）
- `plan.logic.locals[LOCAL-002].branches[LOCAL-002-B01]`：Unknown branch test: CHECK-057（logic.test.unknown）
- `plan.logic.locals[LOCAL-002].branches[LOCAL-002-B01]`：Unknown branch test: CHECK-056（logic.test.unknown）
- `plan.logic.locals[LOCAL-002].branches[LOCAL-002-B02]`：Unknown branch test: CHECK-045（logic.test.unknown）
- `plan.logic.locals[LOCAL-002].branches[LOCAL-002-B02]`：Unknown branch test: CHECK-044（logic.test.unknown）
- `plan.logic.locals[LOCAL-002].branches[LOCAL-002-B03]`：Unknown branch test: CHECK-017（logic.test.unknown）
- `plan.logic.locals[LOCAL-002].branches[LOCAL-002-B03]`：Unknown branch test: CHECK-045（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-B].branches[LOCAL-004-B-B01]`：Unknown branch test: CHECK-012（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-B].branches[LOCAL-004-B-B01]`：Unknown branch test: CHECK-029（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-B].branches[LOCAL-004-B-B01]`：Unknown branch test: CHECK-036（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-B].branches[LOCAL-004-B-B02]`：Unknown branch test: CHECK-050（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-B].branches[LOCAL-004-B-B03]`：Unknown branch test: CHECK-051（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-B].branches[LOCAL-004-B-B04]`：Unknown branch test: CHECK-050（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-B].branches[LOCAL-004-B-B04]`：Unknown branch test: CHECK-047（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B01]`：Unknown branch test: CHECK-009（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B01]`：Unknown branch test: CHECK-049（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B01]`：Unknown branch test: CHECK-007（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B02]`：Unknown branch test: CHECK-049（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B03]`：Unknown branch test: CHECK-048（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B03]`：Unknown branch test: CHECK-010（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B04]`：Unknown branch test: CHECK-048（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B04]`：Unknown branch test: CHECK-047（logic.test.unknown）
- `plan.logic.locals[LOCAL-004].branches[LOCAL-004-B04]`：Unknown branch test: CHECK-010（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-A].branches[LOCAL-004-A-B01]`：Unknown branch test: CHECK-060（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-A].branches[LOCAL-004-A-B01]`：Unknown branch test: CHECK-059（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-A].branches[LOCAL-004-A-B02]`：Unknown branch test: CHECK-031（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-A].branches[LOCAL-004-A-B02]`：Unknown branch test: CHECK-030（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-A].branches[LOCAL-004-A-B03]`：Unknown branch test: CHECK-029（logic.test.unknown）
- `plan.logic.locals[LOCAL-004-A].branches[LOCAL-004-A-B03]`：Unknown branch test: CHECK-059（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B01]`：Unknown branch test: CHECK-046（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B01]`：Unknown branch test: CHECK-035（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B01]`：Unknown branch test: CHECK-050（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B02]`：Unknown branch test: CHECK-039（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B02]`：Unknown branch test: CHECK-011（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B03]`：Unknown branch test: CHECK-013（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B03]`：Unknown branch test: CHECK-041（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B04]`：Unknown branch test: CHECK-039（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B04]`：Unknown branch test: CHECK-043（logic.test.unknown）
- `plan.logic.locals[LOCAL-005].branches[LOCAL-005-B04]`：Unknown branch test: CHECK-035（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B01]`：Unknown branch test: CHECK-008（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B01]`：Unknown branch test: CHECK-042（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B02]`：Unknown branch test: CHECK-052（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B02]`：Unknown branch test: CHECK-008（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B02]`：Unknown branch test: CHECK-043（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B02]`：Unknown branch test: CHECK-042（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B03]`：Unknown branch test: CHECK-042（logic.test.unknown）
- `plan.logic.locals[LOCAL-006].branches[LOCAL-006-B03]`：Unknown branch test: CHECK-040（logic.test.unknown）
- `plan.logic.locals[LOCAL-009].branches[LOCAL-009-B01]`：Unknown branch test: CHECK-016（logic.test.unknown）
- `plan.logic.locals[LOCAL-009].branches[LOCAL-009-B01]`：Unknown branch test: CHECK-025（logic.test.unknown）
- `plan.logic.locals[LOCAL-009].branches[LOCAL-009-B02]`：Unknown branch test: CHECK-052（logic.test.unknown）
- `plan.logic.locals[LOCAL-009].branches[LOCAL-009-B02]`：Unknown branch test: CHECK-016（logic.test.unknown）
- `plan.logic.locals[LOCAL-009].branches[LOCAL-009-B02]`：Unknown branch test: CHECK-024（logic.test.unknown）
- `plan.logic.locals[LOCAL-009].branches[LOCAL-009-B02]`：Unknown branch test: CHECK-025（logic.test.unknown）
- `plan.logic.locals[LOCAL-009].branches[LOCAL-009-B03]`：Unknown branch test: CHECK-061（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B01]`：Unknown branch test: CHECK-018（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B01]`：Unknown branch test: CHECK-038（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B01]`：Unknown branch test: CHECK-037（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B02]`：Unknown branch test: CHECK-052（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B02]`：Unknown branch test: CHECK-037（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B03]`：Unknown branch test: CHECK-041（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B03]`：Unknown branch test: CHECK-043（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B03]`：Unknown branch test: CHECK-035（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B03]`：Unknown branch test: CHECK-052（logic.test.unknown）
- `plan.logic.locals[LOCAL-010].branches[LOCAL-010-B04]`：Unknown branch test: CHECK-038（logic.test.unknown）
- `plan.logic.locals[LOCAL-011].branches[LOCAL-011-B01]`：Unknown branch test: CHECK-021（logic.test.unknown）
- `plan.logic.locals[LOCAL-011].branches[LOCAL-011-B01]`：Unknown branch test: CHECK-034（logic.test.unknown）
- `plan.logic.locals[LOCAL-011].branches[LOCAL-011-B02]`：Unknown branch test: CHECK-021（logic.test.unknown）
- `plan.logic.locals[LOCAL-011].branches[LOCAL-011-B02]`：Unknown branch test: CHECK-034（logic.test.unknown）
- `plan.logic.locals[LOCAL-011].branches[LOCAL-011-B03]`：Unknown branch test: CHECK-022（logic.test.unknown）
- `plan.logic.locals[LOCAL-011].branches[LOCAL-011-B03]`：Unknown branch test: CHECK-004（logic.test.unknown）
- `plan.logic.locals[LOCAL-011].branches[LOCAL-011-B03]`：Unknown branch test: CHECK-024（logic.test.unknown）
- `plan.logic.locals[LOCAL-012].branches[LOCAL-012-B01]`：Unknown branch test: CHECK-003（logic.test.unknown）
- `plan.logic.locals[LOCAL-012].branches[LOCAL-012-B01]`：Unknown branch test: CHECK-033（logic.test.unknown）
- `plan.logic.locals[LOCAL-012].branches[LOCAL-012-B01]`：Unknown branch test: CHECK-020（logic.test.unknown）
- `plan.logic.locals[LOCAL-012].branches[LOCAL-012-B02]`：Unknown branch test: CHECK-003（logic.test.unknown）
- `plan.logic.locals[LOCAL-012].branches[LOCAL-012-B02]`：Unknown branch test: CHECK-033（logic.test.unknown）
- `plan.logic.locals[LOCAL-013].branches[LOCAL-013-B01]`：Unknown branch test: CHECK-062（logic.test.unknown）
- `plan.logic.locals[LOCAL-013].branches[LOCAL-013-B01]`：Unknown branch test: CHECK-043（logic.test.unknown）
- `plan.logic.locals[LOCAL-013].branches[LOCAL-013-B01]`：Unknown branch test: CHECK-035（logic.test.unknown）
- `plan.logic.locals[LOCAL-013].branches[LOCAL-013-B02]`：Unknown branch test: CHECK-062（logic.test.unknown）
- `plan.logic.locals[LOCAL-013].branches[LOCAL-013-B02]`：Unknown branch test: CHECK-035（logic.test.unknown）
- `plan.logic.locals[LOCAL-013].branches[LOCAL-013-B03]`：Unknown branch test: CHECK-062（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B01]`：Unknown branch test: CHECK-052（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B01]`：Unknown branch test: CHECK-048（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B01]`：Unknown branch test: CHECK-050（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B01]`：Unknown branch test: CHECK-047（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B02]`：Unknown branch test: CHECK-039（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B02]`：Unknown branch test: CHECK-043（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B02]`：Unknown branch test: CHECK-040（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B03]`：Unknown branch test: CHECK-029（logic.test.unknown）
- `plan.logic.locals[LOCAL-015].branches[LOCAL-015-B03]`：Unknown branch test: CHECK-059（logic.test.unknown）
- `plan.logic.locals[LOCAL-016].branches[LOCAL-016-B01]`：Unknown branch test: CHECK-036（logic.test.unknown）
- `plan.logic.locals[LOCAL-016].branches[LOCAL-016-B02]`：Unknown branch test: CHECK-029（logic.test.unknown）
- `plan.logic.locals[LOCAL-016].branches[LOCAL-016-B02]`：Unknown branch test: CHECK-059（logic.test.unknown）
- `plan.logic.locals[LOCAL-016].branches[LOCAL-016-B02]`：Unknown branch test: CHECK-036（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B01]`：Unknown branch test: CHECK-041（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B01]`：Unknown branch test: CHECK-040（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B02]`：Unknown branch test: CHECK-042（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B02]`：Unknown branch test: CHECK-043（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B02]`：Unknown branch test: CHECK-040（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B03]`：Unknown branch test: CHECK-039（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B03]`：Unknown branch test: CHECK-043（logic.test.unknown）
- `plan.logic.locals[LOCAL-017].branches[LOCAL-017-B03]`：Unknown branch test: CHECK-040（logic.test.unknown）
- `plan.logic.locals[LOCAL-018].branches[LOCAL-018-B01]`：Unknown branch test: CHECK-053（logic.test.unknown）
- `plan.logic.locals[LOCAL-018].branches[LOCAL-018-B02]`：Unknown branch test: CHECK-053（logic.test.unknown）
- `plan.logic.locals[LOCAL-018].branches[LOCAL-018-B03]`：Unknown branch test: CHECK-053（logic.test.unknown）
- `plan.logic.locals[LOCAL-018].branches[LOCAL-018-B03]`：Unknown branch test: CHECK-044（logic.test.unknown）
- `plan.logic.locals[LOCAL-019].branches[LOCAL-019-B01]`：Unknown branch test: CHECK-017（logic.test.unknown）
- `plan.logic.locals[LOCAL-019].branches[LOCAL-019-B01]`：Unknown branch test: CHECK-055（logic.test.unknown）
- `plan.logic.locals[LOCAL-019].branches[LOCAL-019-B01]`：Unknown branch test: CHECK-058（logic.test.unknown）
- `plan.logic.locals[LOCAL-019].branches[LOCAL-019-B02]`：Unknown branch test: CHECK-055（logic.test.unknown）
- `plan.logic.locals[LOCAL-019].branches[LOCAL-019-B02]`：Unknown branch test: CHECK-044（logic.test.unknown）
- `plan.logic.locals[LOCAL-020].branches[LOCAL-020-B01]`：Unknown branch test: CHECK-054（logic.test.unknown）
- `plan.logic.locals[LOCAL-020].branches[LOCAL-020-B01]`：Unknown branch test: CHECK-058（logic.test.unknown）
- `plan.logic.locals[LOCAL-020].branches[LOCAL-020-B02]`：Unknown branch test: CHECK-054（logic.test.unknown）
- `plan.logic.locals[LOCAL-020].branches[LOCAL-020-B02]`：Unknown branch test: CHECK-044（logic.test.unknown）
- `plan.logic.locals[LOCAL-021].branches[LOCAL-021-B01]`：Unknown branch test: CHECK-057（logic.test.unknown）
- `plan.logic.locals[LOCAL-021].branches[LOCAL-021-B02]`：Unknown branch test: CHECK-057（logic.test.unknown）
- `plan.logic.locals[LOCAL-021].branches[LOCAL-021-B03]`：Unknown branch test: CHECK-057（logic.test.unknown）
- `plan.logic.locals[LOCAL-021].branches[LOCAL-021-B03]`：Unknown branch test: CHECK-044（logic.test.unknown）
- `plan.ui.pages[UI-PAGE-001]`：Each UI page needs an implementation task with ui_page_ids.（ui.task.owner）
- `plan.ui.pages[UI-PAGE-001]`：All page local logic must be implemented by tasks referencing this page.（ui.task.locals）
- `plan.ui.pages[UI-PAGE-001]`：UI fields must be implemented by tasks referencing this page.（ui.task.fields）
- `plan.ui.pages[UI-PAGE-001].test_refs`：UI test CHECK-045 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].test_refs`：UI test CHECK-044 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].test_refs`：UI test CHECK-053 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].test_refs`：UI test CHECK-058 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].test_refs`：UI test CHECK-057 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].test_refs`：UI test CHECK-028 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002]`：Each UI page needs an implementation task with ui_page_ids.（ui.task.owner）
- `plan.ui.pages[UI-PAGE-002]`：All page local logic must be implemented by tasks referencing this page.（ui.task.locals）
- `plan.ui.pages[UI-PAGE-002]`：UI fields must be implemented by tasks referencing this page.（ui.task.fields）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-042 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-013 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-060 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-040 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-009 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-016 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-007 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-015 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-002 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-029 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-032 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-001 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-012 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-062 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-011 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-047 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-010 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-008 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-022 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-038 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-018 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-048 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-039 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-037 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-031 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-025 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-026 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-043 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-004 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-046 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-019 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-034 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-061 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-020 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-049 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-050 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-021 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-030 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-051 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-052 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-059 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-035 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-023 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-006 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-024 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-003 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-005 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-033 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-041 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-027 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-036 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-014 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].test_refs`：UI test CHECK-028 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003]`：Each UI page needs an implementation task with ui_page_ids.（ui.task.owner）
- `plan.ui.pages[UI-PAGE-003]`：All page local logic must be implemented by tasks referencing this page.（ui.task.locals）
- `plan.ui.pages[UI-PAGE-003]`：UI fields must be implemented by tasks referencing this page.（ui.task.fields）
- `plan.ui.pages[UI-PAGE-003].test_refs`：UI test CHECK-045 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].test_refs`：UI test CHECK-044 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].test_refs`：UI test CHECK-055 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].test_refs`：UI test CHECK-017 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].test_refs`：UI test CHECK-058 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004]`：Each UI page needs an implementation task with ui_page_ids.（ui.task.owner）
- `plan.ui.pages[UI-PAGE-004]`：All page local logic must be implemented by tasks referencing this page.（ui.task.locals）
- `plan.ui.pages[UI-PAGE-004]`：UI fields must be implemented by tasks referencing this page.（ui.task.fields）
- `plan.ui.pages[UI-PAGE-004].test_refs`：UI test CHECK-045 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].test_refs`：UI test CHECK-054 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].test_refs`：UI test CHECK-044 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].test_refs`：UI test CHECK-017 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].test_refs`：UI test CHECK-058 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].test_refs`：UI test CHECK-057 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005]`：Each UI page needs an implementation task with ui_page_ids.（ui.task.owner）
- `plan.ui.pages[UI-PAGE-005]`：All page local logic must be implemented by tasks referencing this page.（ui.task.locals）
- `plan.ui.pages[UI-PAGE-005]`：UI fields must be implemented by tasks referencing this page.（ui.task.fields）
- `plan.ui.pages[UI-PAGE-005].test_refs`：UI test CHECK-045 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].test_refs`：UI test CHECK-044 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].test_refs`：UI test CHECK-017 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].test_refs`：UI test CHECK-058 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].test_refs`：UI test CHECK-028 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].test_refs`：UI test CHECK-056 must belong to a task referencing the page.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].interactions[UI-APP-QUERY].test_refs`：Interaction test CHECK-053 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].interactions[UI-APP-CREATE-OPEN].test_refs`：Interaction test CHECK-055 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].interactions[UI-APP-DETAIL-OPEN].test_refs`：Interaction test CHECK-054 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].interactions[UI-APP-EDIT-OPEN].test_refs`：Interaction test CHECK-056 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-001].interactions[UI-APP-DELETE-LIST].test_refs`：Interaction test CHECK-057 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-CREATE-SOURCE].test_refs`：Interaction test CHECK-029 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-CREATE-SOURCE].test_refs`：Interaction test CHECK-036 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-IMPORT-ENTRY].test_refs`：Interaction test CHECK-029 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-IMPORT-ENTRY].test_refs`：Interaction test CHECK-059 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-PREVIEW].test_refs`：Interaction test CHECK-031 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-PREVIEW].test_refs`：Interaction test CHECK-060 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-PREVIEW].test_refs`：Interaction test CHECK-030 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-SUBMIT].test_refs`：Interaction test CHECK-060 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-SUBMIT].test_refs`：Interaction test CHECK-011 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-SUBMIT].test_refs`：Interaction test CHECK-006 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-SUBMIT].test_refs`：Interaction test CHECK-007 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-MANUAL-SUBMIT].test_refs`：Interaction test CHECK-030 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DCC-RECEIPT].test_refs`：Interaction test CHECK-047 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DCC-RECEIPT].test_refs`：Interaction test CHECK-048 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DCC-RECEIPT].test_refs`：Interaction test CHECK-049 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DCC-RECEIPT].test_refs`：Interaction test CHECK-051 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DCC-RECEIPT].test_refs`：Interaction test CHECK-050 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SUPPLIER-OBSERVE].test_refs`：Interaction test CHECK-039 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SUPPLIER-OBSERVE].test_refs`：Interaction test CHECK-046 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SUPPLIER-OBSERVE].test_refs`：Interaction test CHECK-011 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SUPPLIER-OBSERVE].test_refs`：Interaction test CHECK-040 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-RECORD-VIEW].test_refs`：Interaction test CHECK-047 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-RECORD-VIEW].test_refs`：Interaction test CHECK-015 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-RECORD-VIEW].test_refs`：Interaction test CHECK-032 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-RECORD-VIEW].test_refs`：Interaction test CHECK-048 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-RECORD-VIEW].test_refs`：Interaction test CHECK-014 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-RECORD-VIEW].test_refs`：Interaction test CHECK-059 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-RECORD-VIEW].test_refs`：Interaction test CHECK-052 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-FAILURE-VIEW].test_refs`：Interaction test CHECK-039 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-FAILURE-VIEW].test_refs`：Interaction test CHECK-043 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-FAILURE-VIEW].test_refs`：Interaction test CHECK-040 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-FAILURE-EXPORT].test_refs`：Interaction test CHECK-052 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-FAILURE-EXPORT].test_refs`：Interaction test CHECK-008 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-FAILURE-EXPORT].test_refs`：Interaction test CHECK-043 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-FAILURE-EXPORT].test_refs`：Interaction test CHECK-042 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-LINE-RESULT].test_refs`：Interaction test CHECK-026 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-LINE-RESULT].test_refs`：Interaction test CHECK-035 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-LINE-RESULT].test_refs`：Interaction test CHECK-002 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-LINE-RESULT].test_refs`：Interaction test CHECK-018 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-LINE-RESULT].test_refs`：Interaction test CHECK-027 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SHORT-RESULT].test_refs`：Interaction test CHECK-022 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SHORT-RESULT].test_refs`：Interaction test CHECK-004 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SHORT-RESULT].test_refs`：Interaction test CHECK-023 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SHORT-RESULT].test_refs`：Interaction test CHECK-035 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SHORT-RESULT].test_refs`：Interaction test CHECK-034 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SHORT-RESULT].test_refs`：Interaction test CHECK-021 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-NOCDR-VIEW].test_refs`：Interaction test CHECK-003 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-NOCDR-VIEW].test_refs`：Interaction test CHECK-033 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-NOCDR-VIEW].test_refs`：Interaction test CHECK-020 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SIP-UPDATE].test_refs`：Interaction test CHECK-062 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-SIP-UPDATE].test_refs`：Interaction test CHECK-035 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELIVERY-VIEW].test_refs`：Interaction test CHECK-062 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELIVERY-VIEW].test_refs`：Interaction test CHECK-043 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELIVERY-VIEW].test_refs`：Interaction test CHECK-038 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELIVERY-VIEW].test_refs`：Interaction test CHECK-041 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELIVERY-VIEW].test_refs`：Interaction test CHECK-018 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELIVERY-VIEW].test_refs`：Interaction test CHECK-052 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELIVERY-VIEW].test_refs`：Interaction test CHECK-037 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELETE-PRECISE].test_refs`：Interaction test CHECK-025 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELETE-PRECISE].test_refs`：Interaction test CHECK-016 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELETE-PRECISE].test_refs`：Interaction test CHECK-024 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELETE-PRECISE].test_refs`：Interaction test CHECK-061 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-002].interactions[UI-TASK-DELETE-PRECISE].test_refs`：Interaction test CHECK-052 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].interactions[UI-APP-CREATE-SAVE].test_refs`：Interaction test CHECK-017 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].interactions[UI-APP-CREATE-SAVE].test_refs`：Interaction test CHECK-045 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].interactions[UI-APP-CREATE-SAVE].test_refs`：Interaction test CHECK-055 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].interactions[UI-APP-CREATE-SAVE].test_refs`：Interaction test CHECK-058 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-003].interactions[UI-APP-CREATE-CANCEL].test_refs`：Interaction test CHECK-055 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].interactions[UI-APP-SECRET-READ].test_refs`：Interaction test CHECK-054 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].interactions[UI-APP-SECRET-READ].test_refs`：Interaction test CHECK-058 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].interactions[UI-APP-DETAIL-BACK].test_refs`：Interaction test CHECK-054 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].interactions[UI-APP-DETAIL-EDIT].test_refs`：Interaction test CHECK-056 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-004].interactions[UI-APP-DETAIL-DELETE].test_refs`：Interaction test CHECK-057 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].interactions[UI-APP-EDIT-SAVE].test_refs`：Interaction test CHECK-017 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].interactions[UI-APP-EDIT-SAVE].test_refs`：Interaction test CHECK-045 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].interactions[UI-APP-EDIT-SAVE].test_refs`：Interaction test CHECK-056 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].interactions[UI-APP-EDIT-SAVE].test_refs`：Interaction test CHECK-058 must be owned by a task implementing this page interaction.（ui.test.owner）
- `plan.ui.pages[UI-PAGE-005].interactions[UI-APP-EDIT-CANCEL].test_refs`：Interaction test CHECK-056 must be owned by a task implementing this page interaction.（ui.test.owner）
- `engineering.readiness.scaffold.status`：脚手架与代码库入口尚未补齐，由开发方完成后再检查开工门禁。（readiness.pending）
- `engineering.readiness.stack.status`：技术栈与版本尚未补齐，由开发方完成后再检查开工门禁。（readiness.pending）
- `engineering.readiness.backend.status`：后端框架与服务边界尚未补齐，由开发方完成后再检查开工门禁。（readiness.pending）
- `engineering.readiness.data.status`：数据约定与字段映射尚未补齐，由开发方完成后再检查开工门禁。（readiness.pending）
- `engineering.readiness.api.status`：接口约定尚未补齐，由开发方完成后再检查开工门禁。（readiness.pending）
- `engineering.readiness.coding.status`：编码与协作规范尚未补齐，由开发方完成后再检查开工门禁。（readiness.pending）
- `engineering.readiness.verification.status`：测试与运行约定尚未补齐，由开发方完成后再检查开工门禁。（readiness.pending）

</details>

## 接口清单维护

接口条目统一维护在工作区 plan.json 的 technical_design.interfaces 中。重新生成产品讨论稿后，再用同一工作区 render-interface-catalog.py 指定新导出目录，生成 interface-list.md、证据引用和入口，并更新文件清单指纹。该补充器只接受 draft，不改变两阶段门禁结果；接口真实验证和正式工程交付仍按本清单前述要求完成。
