# 按功能阅读

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回开发包入口](../README.md)

先选择一个业务功能。每份功能页把页面、逻辑、字段、任务和验收串在一起；共同规则继续引用原说明。功能目录的顺序不代表开发执行顺序，实施安排见[任务计划](../task-plan.md)。

本次选择 17 个功能；目录按来源的业务域分组，缺业务域时采用来源业务模块，两者都没有时列入未分组。

<a id="GROUP-e86ea3f280d920a2"></a>

## 未分组

- [修改应用 · FUNC\-001](../features/FUNC-001.md)
- [交换指定租户身份 · FUNC\-002](../features/FUNC-002.md)
- [接收预外呼线索 · FUNC\-004](../features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](../features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](../features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](../features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](../features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](../features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](../features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](../features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](../features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](../features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](../features/FUNC-017.md)
- [查询应用列表 · FUNC\-018](../features/FUNC-018.md)
- [创建应用 · FUNC\-019](../features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](../features/FUNC-020.md)
- [删除应用 · FUNC\-021](../features/FUNC-021.md)
