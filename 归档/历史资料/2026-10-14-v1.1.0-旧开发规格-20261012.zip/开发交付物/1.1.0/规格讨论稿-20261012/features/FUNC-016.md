# 创建任务并锁定导入方式 · FUNC\-016

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

创建确认选择单一DCC/手工来源，租户/原supplierTaskId/来源锁定；既有名单/修改入口不能改变来源或归属。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md) — 共用页面，另有 10 个功能

## 局部逻辑

- [创建任务并锁定单一导入来源 · LOCAL\-016](../local-logic/LOCAL-016.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：用户在创建任务时选择DCC接口或手工来源并确认提交

- 沿原任务创建权限及供应商任务归属校验；任务属于租户而非应用

### 处理步骤

1. **LOCAL\-016\-S01**：创建确认前选择且仅选择一种来源，并核验tenant和原supplierTaskId

2. **LOCAL\-016\-S02**：成功创建时保存锁定来源及归属，任务不绑定应用

3. **LOCAL\-016\-S03**：后续页面与业务调用均复核锁来源/归属；历史任务补导只沿未启动等原条件且累计原名单批次

### 分支与异常

- **LOCAL\-016\-B01**：当确认创建前合法选择DCC或手工，保存对应单一来源，不自动额外授予权限。

- **LOCAL\-016\-B02**：当提交后试图切换来源、归属或混入另一方式，拒绝且保留原任务/名单；常驻入口不能绕过。

### 完成后的状态

- 提交成功后租户、原供应商任务和来源锁定；既有名单/修改/导入入口不允许切换或混用

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [业务租户 · FLD\-003](../field-specs.md#FLD-003)；依据：[创建任务并锁定单一导入来源 · LOCAL\-016](../local-logic/LOCAL-016.md)

- [原供应商任务号 · FLD\-004](../field-specs.md#FLD-004)；依据：[创建任务并锁定单一导入来源 · LOCAL\-016](../local-logic/LOCAL-016.md)

- [任务导入来源 · FLD\-078](../field-specs.md#FLD-078)；依据：[创建任务并锁定单一导入来源 · LOCAL\-016](../local-logic/LOCAL-016.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [坐席实际接听状态 · FIELD\-AGENT\-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本批次创建时间 · FIELD\-BATCH\-CREATED\-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地批次归属类型 · FIELD\-BATCH\-KIND](../field-specs.md#FIELD-BATCH-KIND)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前有效预览草稿 · FIELD\-CSV\-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [手工当前CSV文本 · FIELD\-CSV\-TEXT](../field-specs.md#FIELD-CSV-TEXT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户真实接听状态 · FIELD\-CUSTOMER\-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [必要去重与关联留存 · FIELD\-DEDUP\-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前删除操作反馈 · FIELD\-DELETION\-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [精准删除当前目标与样例 · FIELD\-DELETION\-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC逐次交付状态 · FIELD\-DELIVERY\-STATE](../field-specs.md#FIELD-DELIVERY-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败快照下载状态 · FIELD\-DOWNLOAD\-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [结果来源与可信依据 · FIELD\-EVIDENCE\-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次失败导出快照 · FIELD\-EXPORT\-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片完整性 · FIELD\-FRAGMENT\-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原始导入时间 · FIELD\-ORIGINAL\-IMPORT\-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户手机号 · FIELD\-PHONE](../field-specs.md#FIELD-PHONE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次本地接收时间 · FIELD\-RECEIVED\-AT](../field-specs.md#FIELD-RECEIVED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地保存稳定顺序 · FIELD\-RECEIVED\-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [呼叫或业务结果原因 · FIELD\-RESULT\-REASON](../field-specs.md#FIELD-RESULT-REASON)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [同一结果更新版本 · FIELD\-RESULT\-VERSION](../field-specs.md#FIELD-RESULT-VERSION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [待核原因 · FIELD\-REVIEW\-REASON](../field-specs.md#FIELD-REVIEW-REASON)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [请求内行定位 · FIELD\-ROW\-ID](../field-specs.md#FIELD-ROW-ID)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [秒挂识别结果 · FIELD\-SHORT\-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单状态描述 · FIELD\-STATUS\-DESC](../field-specs.md#FIELD-STATUS-DESC)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商提交状态 · FIELD\-SUBMISSION\-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [独立未可信SIP证据 · FIELD\-UNTRUSTED\-SIP](../field-specs.md#FIELD-UNTRUSTED-SIP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [来源渠道R · FLD\-001](../field-specs.md#FLD-001)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC请求标识 · FLD\-002](../field-specs.md#FLD-002)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [是否另开主批次 · FLD\-007](../field-specs.md#FLD-007)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [线索编码 · FLD\-008](../field-specs.md#FLD-008)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次导入优先级 · FLD\-009](../field-specs.md#FLD-009)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地本次批次号 · FLD\-010](../field-specs.md#FLD-010)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地记录号 · FLD\-011](../field-specs.md#FLD-011)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [关联主批次号 · FLD\-013](../field-specs.md#FLD-013)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原逐行接收回执 · FLD\-015](../field-specs.md#FLD-015)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次供应商批次号 · FLD\-020](../field-specs.md#FLD-020)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商请求号码总数 · FLD\-021](../field-specs.md#FLD-021)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商非法号码数 · FLD\-022](../field-specs.md#FLD-022)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商成功导入数 · FLD\-023](../field-specs.md#FLD-023)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片序号 · FLD\-028](../field-specs.md#FLD-028)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [导入失败原始原因 · FLD\-030](../field-specs.md#FLD-030)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [声明失败分片总数 · FLD\-035](../field-specs.md#FLD-035)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户实际接听时长原值 · FLD\-043](../field-specs.md#FLD-043)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商最后一条标志 · FLD\-046](../field-specs.md#FLD-046)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [obSipCause原字段 · FLD\-047](../field-specs.md#FLD-047)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [挂断来源原字段 · FLD\-048](../field-specs.md#FLD-048)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [sipCause原字段 · FLD\-049](../field-specs.md#FLD-049)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [SIP异步更新标志 · FLD\-050](../field-specs.md#FLD-050)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单原始状态码 · FLD\-051](../field-specs.md#FLD-051)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次精准删除结果 · FLD\-054](../field-specs.md#FLD-054)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [真实通话或稳定事件标识 · FLD\-066](../field-specs.md#FLD-066)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

## 本功能验收

- **AC\-036**：创建任务提交后锁定DCC接口导入或手工导入一种来源，不可切换或混用；后端同时校验taskId与方式，任务归租户不绑定应用。

- **AC\-029**：预外呼“导入客户”入口常驻，按任务已锁DCC接口或手工来源进入对应入口；接口任务不能手工混入，手工任务按既有导入并仅平台查看结果。权限/状态不可导入时保留禁用入口和原因，后端同时校验来源、租户任务归属；不通过按钮改变既有历史任务可补导状态规则。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-016。产品：云呼叫中心 DCC 预外呼实际原型方案 / 1\.1\.0。

来源类型：reviewed；来源指纹：1c685199ed5a95789ae12252ec1c767614dc33176dc673815fccbe5647d2c4ec。

- product\-input\.json\#FUNC\-016

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
