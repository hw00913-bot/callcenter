# 删除指定供应商号码 · FUNC\-009

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

租户/原任务/record/batch/phone/file精确供应商删除合成请求及结果；未知不标已删，主删不删子和本地映射，选择变化清旧反馈。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md) — 共用页面，另有 10 个功能

## 局部逻辑

- [精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：DCC请求删除指定租户原任务中的当前记录/批次号码

- 租户身份有效；record/batch/fileId/phone精确映射明确，root仅追溯

### 处理步骤

1. **LOCAL\-009\-S01**：重核租户/原任务和精确record/batch/fileId/phone，拒绝root或lead单键整组定位

2. **LOCAL\-009\-S02**：切换目标或合成结果样例即清旧界面反馈，旧对象保存证据保持

3. **LOCAL\-009\-S03**：发起对应精确目标合成删除并登记明确成功/失败/未知；真实参数作用域及并发仍待核

4. **LOCAL\-009\-S04**：明确成功仅标该供应商目标，保留原本地record/batch/root/request/file映射并按来源交付状态

### 分支与异常

- **LOCAL\-009\-B01**：当映射缺失、多候选、越界或实际返回未知，拒绝或待核，不能显示已删除，不承诺撤销已执行呼叫。

- **LOCAL\-009\-B02**：当精准目标明确成功，只标该目标已删，主删不删子、子删不删主，不清业务历史。

- **LOCAL\-009\-B03**：当切换目标/样例但未执行新操作，当前反馈为空，旧目标已保存证据仍可查。

### 完成后的状态

- 只在明确成功时标本目标供应商已删除；所有必要本地记录/关联保留，其他同号主子不受影响

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [当前删除操作反馈 · FIELD\-DELETION\-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [精准删除当前目标与样例 · FIELD\-DELETION\-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [DCC逐次交付状态 · FIELD\-DELIVERY\-STATE](../field-specs.md#FIELD-DELIVERY-STATE)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [客户手机号 · FIELD\-PHONE](../field-specs.md#FIELD-PHONE)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [待核原因 · FIELD\-REVIEW\-REASON](../field-specs.md#FIELD-REVIEW-REASON)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [业务租户 · FLD\-003](../field-specs.md#FLD-003)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [原供应商任务号 · FLD\-004](../field-specs.md#FLD-004)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [租户业务身份token · FLD\-006](../field-specs.md#FLD-006)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [线索编码 · FLD\-008](../field-specs.md#FLD-008)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [本地本次批次号 · FLD\-010](../field-specs.md#FLD-010)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [本地记录号 · FLD\-011](../field-specs.md#FLD-011)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [关联主批次号 · FLD\-013](../field-specs.md#FLD-013)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [本次供应商批次号 · FLD\-020](../field-specs.md#FLD-020)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

- [本次精准删除结果 · FLD\-054](../field-specs.md#FLD-054)；依据：[精确删除指定供应商批次号码 · LOCAL\-009](../local-logic/LOCAL-009.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [坐席实际接听状态 · FIELD\-AGENT\-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本批次创建时间 · FIELD\-BATCH\-CREATED\-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地批次归属类型 · FIELD\-BATCH\-KIND](../field-specs.md#FIELD-BATCH-KIND)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前有效预览草稿 · FIELD\-CSV\-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [手工当前CSV文本 · FIELD\-CSV\-TEXT](../field-specs.md#FIELD-CSV-TEXT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户真实接听状态 · FIELD\-CUSTOMER\-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [必要去重与关联留存 · FIELD\-DEDUP\-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败快照下载状态 · FIELD\-DOWNLOAD\-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [结果来源与可信依据 · FIELD\-EVIDENCE\-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次失败导出快照 · FIELD\-EXPORT\-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片完整性 · FIELD\-FRAGMENT\-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原始导入时间 · FIELD\-ORIGINAL\-IMPORT\-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次本地接收时间 · FIELD\-RECEIVED\-AT](../field-specs.md#FIELD-RECEIVED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地保存稳定顺序 · FIELD\-RECEIVED\-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [呼叫或业务结果原因 · FIELD\-RESULT\-REASON](../field-specs.md#FIELD-RESULT-REASON)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [同一结果更新版本 · FIELD\-RESULT\-VERSION](../field-specs.md#FIELD-RESULT-VERSION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [请求内行定位 · FIELD\-ROW\-ID](../field-specs.md#FIELD-ROW-ID)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [秒挂识别结果 · FIELD\-SHORT\-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单状态描述 · FIELD\-STATUS\-DESC](../field-specs.md#FIELD-STATUS-DESC)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商提交状态 · FIELD\-SUBMISSION\-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [独立未可信SIP证据 · FIELD\-UNTRUSTED\-SIP](../field-specs.md#FIELD-UNTRUSTED-SIP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [来源渠道R · FLD\-001](../field-specs.md#FLD-001)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC请求标识 · FLD\-002](../field-specs.md#FLD-002)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [是否另开主批次 · FLD\-007](../field-specs.md#FLD-007)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次导入优先级 · FLD\-009](../field-specs.md#FLD-009)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原逐行接收回执 · FLD\-015](../field-specs.md#FLD-015)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商请求号码总数 · FLD\-021](../field-specs.md#FLD-021)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商非法号码数 · FLD\-022](../field-specs.md#FLD-022)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商成功导入数 · FLD\-023](../field-specs.md#FLD-023)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片序号 · FLD\-028](../field-specs.md#FLD-028)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [导入失败原始原因 · FLD\-030](../field-specs.md#FLD-030)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [声明失败分片总数 · FLD\-035](../field-specs.md#FLD-035)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户实际接听时长原值 · FLD\-043](../field-specs.md#FLD-043)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商最后一条标志 · FLD\-046](../field-specs.md#FLD-046)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [obSipCause原字段 · FLD\-047](../field-specs.md#FLD-047)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [挂断来源原字段 · FLD\-048](../field-specs.md#FLD-048)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [sipCause原字段 · FLD\-049](../field-specs.md#FLD-049)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [SIP异步更新标志 · FLD\-050](../field-specs.md#FLD-050)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单原始状态码 · FLD\-051](../field-specs.md#FLD-051)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [真实通话或稳定事件标识 · FLD\-066](../field-specs.md#FLD-066)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [任务导入来源 · FLD\-078](../field-specs.md#FLD-078)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

## 本功能验收

- **AC\-016**：DCC删除仅指定原任务具体供应商批次的号码，明确成功后本地记录、必要幂等结果、固定phone组/主子root及精确供应商/通话映射保留并标记该实际批次已删。不按leadCode/主批/分组整体删除，不作用同组其他主子或其他任务同号批次。

- **AC\-024**：平台无秒挂待执行重导；定向删除保留本地及必要关联记录，明确成功仅标记对应供应商批次已删除，不影响其他任务或同号其他批次，不创建每日衰减或重导计划。

- **AC\-025**：指定供应商记录明确删除成功后本地保留并回传删除状态；平台无待执行重导计划或每日priority衰减，供应商执行中/并发删除由开发核实，不作用其他同号记录。

- **AC\-052**：DCC逐行回执携requestId\+行定位、tenant/原supplierTaskId/leadCode/phone及recordId/batchId/rootBatchId；结果由精确vendorfileId/实际批次/原始号码及callID或稳定事件匹配后携保存的相同业务关联回传。leadCode归组不替代实际供应商/call匹配；previous/parent不再必需且不虚构。原逐行幂等结果、固定phone组/主子root/精确供应商通话映射不随失败快照清理或精准删除丢失；重复/晚更新/补送不新增导入或呼叫。手工仅平台查看不新增DCC协议。

- **AC\-061**：精准供应商删除页面切换目标记录或供应商结果样例时，清除此前目标/样例的成功或失败反馈，不把旧结果显示为当前选择已处理。新操作按当前精确record/batch/fileId/号码与既有租户任务守卫执行；此前已保存的对应删除证据继续留在对应旧对象中，不因清反馈被抹掉。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-009。产品：云呼叫中心 DCC 预外呼实际原型方案 / 1\.1\.0。

来源类型：reviewed；来源指纹：1c685199ed5a95789ae12252ec1c767614dc33176dc673815fccbe5647d2c4ec。

- product\-input\.json\#FUNC\-009

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
