# 识别客户秒挂结果 · FUNC\-011

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

按客户已接通、客户挂断和可信实际桥接时长0～2秒识别秒挂；未知/未接通不伪造，DCC决策再次导入。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md) — 共用页面，另有 10 个功能

## 局部逻辑

- [识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：收到可精确关联且可信的客户接听与挂断结果

- 实际记录及call或稳定事件关联已确认；客户真实接听语义可确认

### 处理步骤

1. **LOCAL\-011\-S01**：核实客户真实接通、客户主动挂断及客户实际接听时长来源；不拿坐席时长替代

2. **LOCAL\-011\-S02**：对可信时长0到2秒含端点识别秒挂并保存到实际call对象

3. **LOCAL\-011\-S03**：将识别结果交LOCAL\-010按任务来源处理；无平台30分钟重导或额外额度

### 分支与异常

- **LOCAL\-011\-B01**：当真实接通、客户挂断且客户实际时长为0、1、2秒，标记本次秒挂；真实0秒不能当缺失。

- **LOCAL\-011\-B02**：当未接通、时长null/异常或不是客户挂断，不纳入秒挂；缺证据不伪造条件成立。

- **LOCAL\-011\-B03**：当已识别秒挂结果重复或时间经过30分钟，保留原结果且不新增呼叫、重导计划或额外4次。

### 完成后的状态

- 仅真实客户接通且客户主动挂断、有效客户时长0～2秒识别秒挂，结果按来源交付/查看

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [坐席实际接听状态 · FIELD\-AGENT\-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [客户真实接听状态 · FIELD\-CUSTOMER\-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [呼叫或业务结果原因 · FIELD\-RESULT\-REASON](../field-specs.md#FIELD-RESULT-REASON)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [秒挂识别结果 · FIELD\-SHORT\-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [话单状态描述 · FIELD\-STATUS\-DESC](../field-specs.md#FIELD-STATUS-DESC)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [客户实际接听时长原值 · FLD\-043](../field-specs.md#FLD-043)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [通话结束时间原值 · FLD\-045](../field-specs.md#FLD-045)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [挂断来源原字段 · FLD\-048](../field-specs.md#FLD-048)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [话单原始状态码 · FLD\-051](../field-specs.md#FLD-051)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [真实通话或稳定事件标识 · FLD\-066](../field-specs.md#FLD-066)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

- [任务导入来源 · FLD\-078](../field-specs.md#FLD-078)；依据：[识别客户秒挂结果 · LOCAL\-011](../local-logic/LOCAL-011.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [本批次创建时间 · FIELD\-BATCH\-CREATED\-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地批次归属类型 · FIELD\-BATCH\-KIND](../field-specs.md#FIELD-BATCH-KIND)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前有效预览草稿 · FIELD\-CSV\-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [手工当前CSV文本 · FIELD\-CSV\-TEXT](../field-specs.md#FIELD-CSV-TEXT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [必要去重与关联留存 · FIELD\-DEDUP\-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前删除操作反馈 · FIELD\-DELETION\-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [精准删除当前目标与样例 · FIELD\-DELETION\-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC逐次交付状态 · FIELD\-DELIVERY\-STATE](../field-specs.md#FIELD-DELIVERY-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败快照下载状态 · FIELD\-DOWNLOAD\-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [结果来源与可信依据 · FIELD\-EVIDENCE\-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次失败导出快照 · FIELD\-EXPORT\-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片完整性 · FIELD\-FRAGMENT\-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原始导入时间 · FIELD\-ORIGINAL\-IMPORT\-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户手机号 · FIELD\-PHONE](../field-specs.md#FIELD-PHONE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次本地接收时间 · FIELD\-RECEIVED\-AT](../field-specs.md#FIELD-RECEIVED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地保存稳定顺序 · FIELD\-RECEIVED\-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [同一结果更新版本 · FIELD\-RESULT\-VERSION](../field-specs.md#FIELD-RESULT-VERSION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [待核原因 · FIELD\-REVIEW\-REASON](../field-specs.md#FIELD-REVIEW-REASON)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [请求内行定位 · FIELD\-ROW\-ID](../field-specs.md#FIELD-ROW-ID)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商提交状态 · FIELD\-SUBMISSION\-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [独立未可信SIP证据 · FIELD\-UNTRUSTED\-SIP](../field-specs.md#FIELD-UNTRUSTED-SIP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [来源渠道R · FLD\-001](../field-specs.md#FLD-001)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC请求标识 · FLD\-002](../field-specs.md#FLD-002)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [业务租户 · FLD\-003](../field-specs.md#FLD-003)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原供应商任务号 · FLD\-004](../field-specs.md#FLD-004)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [是否另开主批次 · FLD\-007](../field-specs.md#FLD-007)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [线索编码 · FLD\-008](../field-specs.md#FLD-008)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次导入优先级 · FLD\-009](../field-specs.md#FLD-009)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地本次批次号 · FLD\-010](../field-specs.md#FLD-010)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地记录号 · FLD\-011](../field-specs.md#FLD-011)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [关联主批次号 · FLD\-013](../field-specs.md#FLD-013)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原逐行接收回执 · FLD\-015](../field-specs.md#FLD-015)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次供应商批次号 · FLD\-020](../field-specs.md#FLD-020)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商请求号码总数 · FLD\-021](../field-specs.md#FLD-021)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商非法号码数 · FLD\-022](../field-specs.md#FLD-022)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商成功导入数 · FLD\-023](../field-specs.md#FLD-023)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片序号 · FLD\-028](../field-specs.md#FLD-028)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [导入失败原始原因 · FLD\-030](../field-specs.md#FLD-030)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [声明失败分片总数 · FLD\-035](../field-specs.md#FLD-035)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商最后一条标志 · FLD\-046](../field-specs.md#FLD-046)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [obSipCause原字段 · FLD\-047](../field-specs.md#FLD-047)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [sipCause原字段 · FLD\-049](../field-specs.md#FLD-049)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [SIP异步更新标志 · FLD\-050](../field-specs.md#FLD-050)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次精准删除结果 · FLD\-054](../field-specs.md#FLD-054)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

## 本功能验收

- **AC\-004**：平台识别自定义秒挂并回传DCC，不由平台启动30分钟自动重导；手工任务仅平台查看。

- **AC\-021**：秒挂须客户真实接通、客户主动挂断、客户实际接通有效时长0～2秒含真实0及2；null、未接通、异常不纳入，不以坐席桥接时长替代；字段单位及映射交开发供应商核实。

- **AC\-022**：秒挂是否/何时重导及次数由DCC决策，原30分钟业务上下文不形成平台计时器；不再发放独立额外4次。

- **AC\-023**：接口任务每次结果携tenant/原supplierTaskId/leadCode/phone、requestId\+行定位、该实际记录batchId/rootBatchId和真实callID或稳定事件；供应商未给平台业务字段时由已保存vendorfileId/实际批次/原始号码精确映射回查，不新增供应商协议承诺。leadCode仅组归属，不可单键匹配结果，也不按最近同号/最近主/结果时间替换实际call批次。手工仍沿既有记录/独立批次/号码/通话事件仅平台查看，不新增DCCflag/request/主子协议。

- **AC\-024**：平台无秒挂待执行重导；定向删除保留本地及必要关联记录，明确成功仅标记对应供应商批次已删除，不影响其他任务或同号其他批次，不创建每日衰减或重导计划。

- **AC\-034**：能确认已接听、客户挂断且真实接听时长0秒，纳入秒挂；未接通、缺失或异常时长不纳入。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-011。产品：云呼叫中心 DCC 预外呼实际原型方案 / 1\.1\.0。

来源类型：reviewed；来源指纹：1c685199ed5a95789ae12252ec1c767614dc33176dc673815fccbe5647d2c4ec。

- product\-input\.json\#FUNC\-011

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
