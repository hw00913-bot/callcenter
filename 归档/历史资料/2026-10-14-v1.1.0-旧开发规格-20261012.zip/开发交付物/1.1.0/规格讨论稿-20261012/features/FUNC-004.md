# 接收预外呼线索 · FUNC\-004

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

按锁来源导入；DCC鉴权及归一request幂等先行，新有效行固定phone组主子/root；手工当前CSV有效预览和最终priority，旧稿/身份变更拒绝。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md) — 共用页面，另有 10 个功能

## 局部逻辑

- [核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：锁定DCC来源任务接到requestId及逐行导入内容

- 租户业务身份已解析；task归属和锁定DCC来源需本次再次核验

### 处理步骤

1. **LOCAL\-004\-B\-S01**：校验当前租户身份、原供应商任务归属及来源

2. **LOCAL\-004\-B\-S02**：仅将缺省isNewBatch归一false；保留完整行数/定位/已给R/priority等有效业务内容

3. **LOCAL\-004\-B\-S03**：按requestId比较已保存的完整请求内容及逐行结果，重复不重新分配主子

### 分支与异常

- **LOCAL\-004\-B\-B01**：当身份、来源或原任务归属不满足，拒绝本请求，不创建或提交记录。

- **LOCAL\-004\-B\-B02**：当同requestId且归一后完整内容相同，返回原成功/失败/待核逐行结果及原record/batch/root，后来新主不改变原映射。

- **LOCAL\-004\-B\-B03**：当同requestId但完整内容不同，拒绝整个重复请求且不覆盖原结果，不为任一行新建或提交。

- **LOCAL\-004\-B\-B04**：当新requestId，交LOCAL\-004逐行校验；具体技术key/规范化/原子性/保留期仍待工程设计。

### 完成后的状态

- 同ID同内容返原逐行映射；同ID异内容整个重复请求拒绝；仅新request进入逐行归组

- [接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：LOCAL\-004\-B确认是新的有效DCC业务请求

- 身份/任务/来源通过且request未重放；各行保留独立行定位

### 处理步骤

1. **LOCAL\-004\-S01**：逐行校验leadCode/phone/priority及isNewBatch Boolean；R可选来源元数据，不做字典范围校验

2. **LOCAL\-004\-S02**：按tenant/原supplierTaskId/leadCode定位固定phone组，冲突或历史关联不明不猜配

3. **LOCAL\-004\-S03**：每有效新行创建新recordId和batchId；true新主，false/缺省有主挂最近已保存主，无主自动首主

4. **LOCAL\-004\-S04**：保存本次priority和审计时间及request行到record/batch/root映射，形成逐行回执后触发自动提交

### 分支与异常

- **LOCAL\-004\-B01**：当缺必要字段或flag不是Boolean，仅该行明确失败；不将非Boolean当false，其他有效行继续。

- **LOCAL\-004\-B02**：当同组固定phone改变或归属/历史主关系冲突、多lead同号仍未决，该行拒绝或待核且不提交，不修改旧记录；isNewBatch=true不能绕过。

- **LOCAL\-004\-B03**：当true，或false/缺省但同组无主，新批次为独立主，rootBatchId等于本次batchId。

- **LOCAL\-004\-B04**：当false/缺省且已有同组主，创建新的子批次，root指保存创建顺序最近主，不挂上一子，不复用旧record/batch。

### 完成后的状态

- 每有效新行新record和单手机号batch并保存root及原回执；无效行不提交且不回滚其他有效行

- [预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：用户从已锁手工来源任务的常驻导入客户入口粘贴/读取CSV、预览并提交

- 沿既有权限/任务可导入状态核验；不授予DCC任务手工导入能力

### 处理步骤

1. **LOCAL\-004\-A\-S01**：按锁来源、当前身份及历史任务可补导状态核验入口；不可操作仍显示入口及原因

2. **LOCAL\-004\-A\-S02**：解析当前CSV预览；文本变化或新预览失败立即使旧稿不可提交

3. **LOCAL\-004\-A\-S03**：统一priority后允许逐行覆盖，仅作用当前有效预览，提交前复核文本和身份未变化

4. **LOCAL\-004\-A\-S04**：逐行校验leadCode/phone/最终priority和可选R；有效行新record/单号batch保存审计时间后自动提交

### 分支与异常

- **LOCAL\-004\-A\-B01**：当无有效当前预览、文本已变、预览失败或提交前身份/任务状态变化，拒绝提交旧草稿并提示重新预览或无权限原因。

- **LOCAL\-004\-A\-B02**：当手工来源当前任务允许导入且预览有效，有效行逐行保存；失败行进入失败下载，不要求DCCrequest/flag/root输入。

- **LOCAL\-004\-A\-B03**：当任务锁定DCC来源或已启动历史任务不符合原补导规则，不能以常驻按钮绕过来源或状态守卫。

### 完成后的状态

- 仅当前文本的有效预览可提交；有效行独立记录/单号批次，以提交前最终priority自动提交

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [客户手机号 · FIELD\-PHONE](../field-specs.md#FIELD-PHONE)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [请求内行定位 · FIELD\-ROW\-ID](../field-specs.md#FIELD-ROW-ID)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [来源渠道R · FLD\-001](../field-specs.md#FLD-001)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [DCC请求标识 · FLD\-002](../field-specs.md#FLD-002)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)

- [业务租户 · FLD\-003](../field-specs.md#FLD-003)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [原供应商任务号 · FLD\-004](../field-specs.md#FLD-004)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [租户业务身份token · FLD\-006](../field-specs.md#FLD-006)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)

- [是否另开主批次 · FLD\-007](../field-specs.md#FLD-007)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)

- [线索编码 · FLD\-008](../field-specs.md#FLD-008)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [本次导入优先级 · FLD\-009](../field-specs.md#FLD-009)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [本地本次批次号 · FLD\-010](../field-specs.md#FLD-010)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [本地记录号 · FLD\-011](../field-specs.md#FLD-011)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [关联主批次号 · FLD\-013](../field-specs.md#FLD-013)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)

- [原逐行接收回执 · FLD\-015](../field-specs.md#FLD-015)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [任务导入来源 · FLD\-078](../field-specs.md#FLD-078)；依据：[核验DCC身份与请求级幂等 · LOCAL\-004\-B](../local-logic/LOCAL-004-B.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [本批次创建时间 · FIELD\-BATCH\-CREATED\-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)；依据：[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [本地批次归属类型 · FIELD\-BATCH\-KIND](../field-specs.md#FIELD-BATCH-KIND)；依据：[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)

- [原始导入时间 · FIELD\-ORIGINAL\-IMPORT\-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)；依据：[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [本次本地接收时间 · FIELD\-RECEIVED\-AT](../field-specs.md#FIELD-RECEIVED-AT)；依据：[接收DCC新行并分配主子批次 · LOCAL\-004](../local-logic/LOCAL-004.md)、[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [当前有效预览草稿 · FIELD\-CSV\-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)；依据：[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

- [手工当前CSV文本 · FIELD\-CSV\-TEXT](../field-specs.md#FIELD-CSV-TEXT)；依据：[预览并提交手工线索 · LOCAL\-004\-A](../local-logic/LOCAL-004-A.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [坐席实际接听状态 · FIELD\-AGENT\-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户真实接听状态 · FIELD\-CUSTOMER\-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [必要去重与关联留存 · FIELD\-DEDUP\-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前删除操作反馈 · FIELD\-DELETION\-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [精准删除当前目标与样例 · FIELD\-DELETION\-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC逐次交付状态 · FIELD\-DELIVERY\-STATE](../field-specs.md#FIELD-DELIVERY-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败快照下载状态 · FIELD\-DOWNLOAD\-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [结果来源与可信依据 · FIELD\-EVIDENCE\-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次失败导出快照 · FIELD\-EXPORT\-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片完整性 · FIELD\-FRAGMENT\-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地保存稳定顺序 · FIELD\-RECEIVED\-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [呼叫或业务结果原因 · FIELD\-RESULT\-REASON](../field-specs.md#FIELD-RESULT-REASON)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [同一结果更新版本 · FIELD\-RESULT\-VERSION](../field-specs.md#FIELD-RESULT-VERSION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [待核原因 · FIELD\-REVIEW\-REASON](../field-specs.md#FIELD-REVIEW-REASON)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [秒挂识别结果 · FIELD\-SHORT\-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单状态描述 · FIELD\-STATUS\-DESC](../field-specs.md#FIELD-STATUS-DESC)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商提交状态 · FIELD\-SUBMISSION\-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [独立未可信SIP证据 · FIELD\-UNTRUSTED\-SIP](../field-specs.md#FIELD-UNTRUSTED-SIP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次供应商批次号 · FLD\-020](../field-specs.md#FLD-020)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商请求号码总数 · FLD\-021](../field-specs.md#FLD-021)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商非法号码数 · FLD\-022](../field-specs.md#FLD-022)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商成功导入数 · FLD\-023](../field-specs.md#FLD-023)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片序号 · FLD\-028](../field-specs.md#FLD-028)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [导入失败原始原因 · FLD\-030](../field-specs.md#FLD-030)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [声明失败分片总数 · FLD\-035](../field-specs.md#FLD-035)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户实际接听时长原值 · FLD\-043](../field-specs.md#FLD-043)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商最后一条标志 · FLD\-046](../field-specs.md#FLD-046)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [obSipCause原字段 · FLD\-047](../field-specs.md#FLD-047)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [挂断来源原字段 · FLD\-048](../field-specs.md#FLD-048)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [sipCause原字段 · FLD\-049](../field-specs.md#FLD-049)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [SIP异步更新标志 · FLD\-050](../field-specs.md#FLD-050)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单原始状态码 · FLD\-051](../field-specs.md#FLD-051)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次精准删除结果 · FLD\-054](../field-specs.md#FLD-054)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [真实通话或稳定事件标识 · FLD\-066](../field-specs.md#FLD-066)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

## 本功能验收

- **AC\-001**：不同手机号形成独立批次，各批次带对应线索编码；R可选，提供则保留来源追踪，缺R不失败。

- **AC\-005**：接口与手工导入的R渠道为可选来源元数据，无需字典维护，不做字典允许范围校验；未传R不导致该条失败，传入则保留追踪；priority独立。保留旧记录R值，不新增默认R枚举；通用输入安全/长度校验仍需技术定义。

- **AC\-006**：每次有效新业务导入新增独立本地recordId和单手机号batchId，不覆盖旧记录；保留手机号、线索编码及已提供可选R。DCC接口每个有效新行归固定phone同组并保存主子root；相同requestId和归一后完整有效内容技术重试复用原逐行结果，不新增记录或批次、不重交。

- **AC\-007**：一次DCC传入多客户，某条上述记录校验失败时仅拒绝该条，其余有效记录继续导入并按手机号拆批，不因该条失败整请求业务回滚。

- **AC\-009**：DCC接口每条业务导入priority必填，未传仅该条失败，不补默认值，其他有效记录继续；本次有效priority独立于R，平台按本次DCC传入值保存、排序并提交供应商，不强制继承之前批次priority。

- **AC\-010**：DCC接口同tenant/原supplierTaskId/leadCode固定phone的真实再次业务导入用新请求级requestId；有效新行创建新记录/单手机号batchId并归同组。isNewBatch=true另开独立主\(root=batch\)，false/未传有主则新子挂最近已保存同组主，无主自动首主；不要求DCC提供上一批次，不仅因同组历史相同而拒绝。同ID同归一后完整内容技术重传返原逐行映射，不新建重交。

- **AC\-012**：DCC推送携带供应商任务ID taskId；自动提交供应商时直接使用，不做本地任务ID映射，不采用统一预设任务。

- **AC\-014**：本地保存线索、本次实际priority和每次接收/新记录批次创建时间；DCC接口保存tenant/原supplierTaskId/leadCode固定phone组、requestId\+行定位、recordId/batchId/rootBatchId及精确供应商/通话映射。DCC用本次输入priority，手工沿提交前统一/逐条最终值；原始导入时间仅审计，不用于平台衰减或决定本次priority。

- **AC\-029**：预外呼“导入客户”入口常驻，按任务已锁DCC接口或手工来源进入对应入口；接口任务不能手工混入，手工任务按既有导入并仅平台查看结果。权限/状态不可导入时保留禁用入口和原因，后端同时校验来源、租户任务归属；不通过按钮改变既有历史任务可补导状态规则。

- **AC\-030**：手工priority统一/逐条填写，仅提交前可改，最终值保存后单手机号独立拆批自动提交；提交后无人工改priority或日龄自动降级。手工不新增DCC requestId/isNewBatch/归组主子接口要求，接口来源任务仍拒绝手工混入。

- **AC\-031**：手工线索导入必需线索编码，R可选且无需字典维护/范围校验；一手机号一批次，缺R不失败；失败沿用成功下载后本次明细/文件删除规则。

- **AC\-036**：创建任务提交后锁定DCC接口导入或手工导入一种来源，不可切换或混用；后端同时校验taskId与方式，任务归租户不绑定应用。

- **AC\-019**：DCC决定是否及何时再次业务导入，新业务用新requestId、可多行，各行本次priority与可选Boolean isNewBatch，未传归一false。平台先鉴权/归一后完整请求幂等，仅新ID逐行按tenant/原supplierTaskId/leadCode固定phone归组；true新独立主root=batch，false/缺省有主新子root=最近已保存同组主，无主自动首主。有效新行始终新record/batch，逐行回执requestId\+行定位/组归属/batch/root，无需DCC previous、不虚构parent。本次priority以DCC输入、不旧继承，原时间审计；DCC汇总真实呼叫计数，平台不建额度。

- **AC\-015**：平台取消每日定时查询当天/历史待跟进号码状态及自然日priority衰减，不因未拨、已拨未接通、跨日或原导入日期计算并改写存量priority；仅服务衰减的状态查询一并退出。既有每次事件/话单/无话单失败的记录与按任务来源回传或查看继续保留。

- **AC\-032**：本次已保存/提交的priority不因北京时间换日、原导入时间、之前批次priority或工作时间自动变化；平台不执行每日状态查询、自然日衰减或存量priority写回，也不保留线路/秒挂30分钟重导调度。

- **AC\-047**：DCC每次业务请求携请求级requestId，可多行/不同线索组；每行明确行定位、leadCode、phone、本次priority和可选Boolean isNewBatch，missing=false。新业务用新ID，所有有效新行均新recordId和独立单手机号batchId并保存rootBatchId；逐行回执同requestId及行定位，主子都不覆盖旧记录。false/缺省复用的是主批关联，不重用旧record/batch编号。

- **AC\-048**：仅DCC新业务有效行进行主子分配：同tenant/原supplierTaskId/leadCode组首次固定phone；true允许同组另开独立主\(rootBatchId=batchId\)。false/缺省有已保存同组主时新子root=最近主batch，无主自动首主root=batch。最近主按本地主批创建顺序/稳定顺序确定，不按最近同号/结果时间/priority/子批，子不挂上一子。DCC previousBatchId和parentBatchId不为本方必需请求/响应，也不暗中虚构parent。

- **AC\-049**：DCC新请求逐行校验tenant/原supplierTaskId/leadCode组归属及固定phone；同组改号、归属冲突、历史组/主关系不明或冲突，明确拒绝或待核不提交，不改旧记录/盲配，其他有效行继续。跨tenant/原任务不混组，相同leadCode在不同合法作用域隔离处理。同号多lead未决关系不自动放开，isNewBatch=true不绕过，也不改DCC计次；isNewBatch提供时必须Boolean、缺省false与显式false有效内容相同，不因缺上一批次字段拒绝。

- **AC\-050**：DCC鉴权及租户/原任务归属后，先将各行missing isNewBatch归一false并按requestId核对完整有效内容。同ID同归一后完整请求技术重传返原逐行接收结果、requestId\+行定位\+recordId/batchId/rootBatchId（含原失败/待核行），不重拆/新增/重交/新增实际呼叫。仅新ID才归组与主子分配；首导自动主或后来新主出现，旧请求重传仍原root，不重新选最近主。供应商证据独立保留，未知提交不因重传重交。

- **AC\-051**：已保存requestId的DCC重复请求，missing isNewBatch=false归一后完整有效内容不同（行数/行定位、tenant/原任务及各行leadCode/phone/priority/归一flag/已给R等业务字段），明确内容冲突并拒整个重复请求，不覆盖原逐行结果、不为任何行新增批次或提交。修改号码/priority/flag不能冒充技术重试；未传与显式false归一相同，true与false不同。

- **AC\-052**：DCC逐行回执携requestId\+行定位、tenant/原supplierTaskId/leadCode/phone及recordId/batchId/rootBatchId；结果由精确vendorfileId/实际批次/原始号码及callID或稳定事件匹配后携保存的相同业务关联回传。leadCode归组不替代实际供应商/call匹配；previous/parent不再必需且不虚构。原逐行幂等结果、固定phone组/主子root/精确供应商通话映射不随失败快照清理或精准删除丢失；重复/晚更新/补送不新增导入或呼叫。手工仅平台查看不新增DCC协议。

- **AC\-059**：预外呼任务列表和任务内保持“导入客户”入口可见；入口按选定任务已锁来源打开DCC接口合成接收或既有手工导入，不能切换或混用来源。当前身份/只读/任务状态不可导入时保留禁用入口及明确原因，不以隐藏替代说明。历史可补导任务仅未启动状态按既有权限/名单规则补导，保留原名单/批次并累计；不藉常驻入口扩展启动后的历史任务导入策略。

- **AC\-060**：手工CSV提交只能使用当前文本对应的有效预览草稿：文本变化立即使旧预览不可提交；新文本预览失败同样清除或冻结旧提交草稿并要求重新预览。提交前复核文本与有效预览一致，未有效预览不提交旧数据；统一/逐条priority修改只作用当前有效预览，成功提交仍沿既有逐行校验/最终priority/单号拆批。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-004。产品：云呼叫中心 DCC 预外呼实际原型方案 / 1\.1\.0。

来源类型：reviewed；来源指纹：1c685199ed5a95789ae12252ec1c767614dc33176dc673815fccbe5647d2c4ec。

- product\-input\.json\#FUNC\-004

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
