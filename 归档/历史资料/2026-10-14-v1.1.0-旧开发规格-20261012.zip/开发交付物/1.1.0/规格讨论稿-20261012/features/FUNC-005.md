# 自动提交导入批次 · FUNC\-005

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

有效行保存后单号自动提交；同任务当前priority高先/同级本地序FIFO，未知/已提交不重交，准确证据和数量不混为逐条成功。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md) — 共用页面，另有 10 个功能

## 局部逻辑

- [自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：新的有效本地单手机号业务记录保存完成

- 是本次尚未提交记录，非请求重放；原任务和来源有效

### 处理步骤

1. **LOCAL\-005\-S01**：同任务按本次priority高先、同级本地接收时间FIFO选择待提交记录；不同任务独立

2. **LOCAL\-005\-S02**：原supplierTaskId直接用于供应商任务；每次仅提交本批手机号和本次priority，不拿root作fileId、不追加旧fileId、不擅改排重配置

3. **LOCAL\-005\-S03**：保存该实际记录返回fileId与taskId及result/description/数量原始证据，原本地记录保留

4. **LOCAL\-005\-S04**：按准确逐条证据登记成功或明确失败；只有汇总或矛盾时不盲定每行，未知暂停待核

### 分支与异常

- **LOCAL\-005\-B01**：当已提交或提交结果未知，不为重排、技术重传自动再提交；保留证据待核。

- **LOCAL\-005\-B02**：当有准确对应成功证据，正常记录该行供应商成功，并保留映射；不直接增加实际呼叫。

- **LOCAL\-005\-B03**：当供应商明确拒绝，保留本地记录与原原因，进入导入失败导出及来源交付。

- **LOCAL\-005\-B04**：当仅汇总或数量/任务/file关联矛盾、超时，显示未知/待核，不能以result=0推全成功或以无推送推零失败。

### 完成后的状态

- 逐批保存实际供应商fileId映射及原同步证据；明确接受/拒绝/未知分开，接受不等于呼叫

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [本批次创建时间 · FIELD\-BATCH\-CREATED\-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [结果来源与可信依据 · FIELD\-EVIDENCE\-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [原始导入时间 · FIELD\-ORIGINAL\-IMPORT\-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [客户手机号 · FIELD\-PHONE](../field-specs.md#FIELD-PHONE)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [本次本地接收时间 · FIELD\-RECEIVED\-AT](../field-specs.md#FIELD-RECEIVED-AT)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [本地保存稳定顺序 · FIELD\-RECEIVED\-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [待核原因 · FIELD\-REVIEW\-REASON](../field-specs.md#FIELD-REVIEW-REASON)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [供应商提交状态 · FIELD\-SUBMISSION\-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [来源渠道R · FLD\-001](../field-specs.md#FLD-001)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [原供应商任务号 · FLD\-004](../field-specs.md#FLD-004)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [线索编码 · FLD\-008](../field-specs.md#FLD-008)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [本次导入优先级 · FLD\-009](../field-specs.md#FLD-009)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [本地本次批次号 · FLD\-010](../field-specs.md#FLD-010)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [本地记录号 · FLD\-011](../field-specs.md#FLD-011)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [关联主批次号 · FLD\-013](../field-specs.md#FLD-013)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [本次供应商批次号 · FLD\-020](../field-specs.md#FLD-020)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [供应商请求号码总数 · FLD\-021](../field-specs.md#FLD-021)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [供应商非法号码数 · FLD\-022](../field-specs.md#FLD-022)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [供应商成功导入数 · FLD\-023](../field-specs.md#FLD-023)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [同步响应描述 · FLD\-025](../field-specs.md#FLD-025)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

- [同步响应结果码 · FLD\-026](../field-specs.md#FLD-026)；依据：[自动提交当前单号批次并登记同步证据 · LOCAL\-005](../local-logic/LOCAL-005.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [坐席实际接听状态 · FIELD\-AGENT\-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地批次归属类型 · FIELD\-BATCH\-KIND](../field-specs.md#FIELD-BATCH-KIND)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前有效预览草稿 · FIELD\-CSV\-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [手工当前CSV文本 · FIELD\-CSV\-TEXT](../field-specs.md#FIELD-CSV-TEXT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户真实接听状态 · FIELD\-CUSTOMER\-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [必要去重与关联留存 · FIELD\-DEDUP\-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前删除操作反馈 · FIELD\-DELETION\-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [精准删除当前目标与样例 · FIELD\-DELETION\-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC逐次交付状态 · FIELD\-DELIVERY\-STATE](../field-specs.md#FIELD-DELIVERY-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败快照下载状态 · FIELD\-DOWNLOAD\-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次失败导出快照 · FIELD\-EXPORT\-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片完整性 · FIELD\-FRAGMENT\-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [呼叫或业务结果原因 · FIELD\-RESULT\-REASON](../field-specs.md#FIELD-RESULT-REASON)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [同一结果更新版本 · FIELD\-RESULT\-VERSION](../field-specs.md#FIELD-RESULT-VERSION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [请求内行定位 · FIELD\-ROW\-ID](../field-specs.md#FIELD-ROW-ID)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [秒挂识别结果 · FIELD\-SHORT\-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单状态描述 · FIELD\-STATUS\-DESC](../field-specs.md#FIELD-STATUS-DESC)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [独立未可信SIP证据 · FIELD\-UNTRUSTED\-SIP](../field-specs.md#FIELD-UNTRUSTED-SIP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [DCC请求标识 · FLD\-002](../field-specs.md#FLD-002)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [业务租户 · FLD\-003](../field-specs.md#FLD-003)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [是否另开主批次 · FLD\-007](../field-specs.md#FLD-007)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原逐行接收回执 · FLD\-015](../field-specs.md#FLD-015)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片序号 · FLD\-028](../field-specs.md#FLD-028)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [导入失败原始原因 · FLD\-030](../field-specs.md#FLD-030)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [声明失败分片总数 · FLD\-035](../field-specs.md#FLD-035)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户实际接听时长原值 · FLD\-043](../field-specs.md#FLD-043)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商最后一条标志 · FLD\-046](../field-specs.md#FLD-046)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [obSipCause原字段 · FLD\-047](../field-specs.md#FLD-047)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [挂断来源原字段 · FLD\-048](../field-specs.md#FLD-048)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [sipCause原字段 · FLD\-049](../field-specs.md#FLD-049)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [SIP异步更新标志 · FLD\-050](../field-specs.md#FLD-050)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [话单原始状态码 · FLD\-051](../field-specs.md#FLD-051)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次精准删除结果 · FLD\-054](../field-specs.md#FLD-054)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [真实通话或稳定事件标识 · FLD\-066](../field-specs.md#FLD-066)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [任务导入来源 · FLD\-078](../field-specs.md#FLD-078)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

## 本功能验收

- **AC\-011**：有效客户完成校验、本地新增独立记录及新批次后，自动提交供应商接口，无需运营手动提交。

- **AC\-012**：DCC推送携带供应商任务ID taskId；自动提交供应商时直接使用，不做本地任务ID映射，不采用统一预设任务。

- **AC\-013**：本地校验保存成功但供应商明确拒绝接收时，纳入导入失败记录，供运营下载并展示供应商返回失败原因。 同步及53异步明确导入失败均适用，未知不误判；导入失败与呼叫失败分开。

- **AC\-035**：关联不明、超时或冲突结果保留待核，不伪造成功/失败/最终状态；重复及SIP晚更新不算新呼叫。回传失败可观察且补送，技术契约由开发核实。

- **AC\-039**：同步返回result=0不代表逐条全成功：分别展示本地校验/保存、供应商导入、呼叫阶段；保留importTotal/successTotal/invalidTotal原始数量与来源。有准确同步证据的成功正常记录；仅汇总数量不能任意指定成功行，未知/矛盾待核，不将同步响应一概降为仅受理。

- **AC\-040**：接收53失败结果分片，按enterpriseId经核实租户映射、taskId、fileId及原始号码数据回查本次本地批次和leadCode；多候选待核，不按最近同号盲配。totalBatchCount/currentBatchCount仅为失败推送分片，不是业务批次；重复不新增、乱序迟到不丢。收齐已声明分片只证明该失败推送组收齐，不证明全导入终态；未收到不推定零失败。

- **AC\-041**：接口来源任务向后台固定DCC接收地址回传导入阶段失败、原始原因和tenant/task/本地批次/leadCode/手机号关联；手工任务只在平台查看。导入失败不计实际呼叫、不触发平台重导；回传失败保持可观察待补送，补送不重做供应商导入。

- **AC\-042**：在既有失败导出入口生成本次失败明细快照并显示已知分片完整性；未收齐或完整性未知显示不完整/待核。可信下载成功仅删除该快照的明细和文件，失败/中断保留；后到的新失败进入后续下载。保留必要业务关联、去重标记、分片及DCC交付状态，已导出事件重复不再生成失败明细；不得清空整个导入或成功客户。

- **AC\-043**：使用显式合成数据验收：同步部分成功并关联异步失败；失败分片乱序、重复及迟到；下载成功后新失败可再次导出、旧重复不再生；DCC回传失败可补送且不新增导入/实际呼叫。映射冲突、分片声明冲突或结果矛盾保持待核；无零失败推送及终态协议不伪造完成。

- **AC\-046**：同一任务的待提交号码按优先级高先提交，同优先级按本地导入时间FIFO；不同任务独立。已提交不撤回重排，提交结果未知不为重排重复提交；一手机号一批次及priority透传保持，不承诺实际拨打顺序。

- **AC\-014**：本地保存线索、本次实际priority和每次接收/新记录批次创建时间；DCC接口保存tenant/原supplierTaskId/leadCode固定phone组、requestId\+行定位、recordId/batchId/rootBatchId及精确供应商/通话映射。DCC用本次输入priority，手工沿提交前统一/逐条最终值；原始导入时间仅审计，不用于平台衰减或决定本次priority。

- **AC\-015**：平台取消每日定时查询当天/历史待跟进号码状态及自然日priority衰减，不因未拨、已拨未接通、跨日或原导入日期计算并改写存量priority；仅服务衰减的状态查询一并退出。既有每次事件/话单/无话单失败的记录与按任务来源回传或查看继续保留。

- **AC\-019**：DCC决定是否及何时再次业务导入，新业务用新requestId、可多行，各行本次priority与可选Boolean isNewBatch，未传归一false。平台先鉴权/归一后完整请求幂等，仅新ID逐行按tenant/原supplierTaskId/leadCode固定phone归组；true新独立主root=batch，false/缺省有主新子root=最近已保存同组主，无主自动首主。有效新行始终新record/batch，逐行回执requestId\+行定位/组归属/batch/root，无需DCC previous、不虚构parent。本次priority以DCC输入、不旧继承，原时间审计；DCC汇总真实呼叫计数，平台不建额度。

- **AC\-032**：本次已保存/提交的priority不因北京时间换日、原导入时间、之前批次priority或工作时间自动变化；平台不执行每日状态查询、自然日衰减或存量priority写回，也不保留线路/秒挂30分钟重导调度。

- **AC\-049**：DCC新请求逐行校验tenant/原supplierTaskId/leadCode组归属及固定phone；同组改号、归属冲突、历史组/主关系不明或冲突，明确拒绝或待核不提交，不改旧记录/盲配，其他有效行继续。跨tenant/原任务不混组，相同leadCode在不同合法作用域隔离处理。同号多lead未决关系不自动放开，isNewBatch=true不绕过，也不改DCC计次；isNewBatch提供时必须Boolean、缺省false与显式false有效内容相同，不因缺上一批次字段拒绝。

- **AC\-050**：DCC鉴权及租户/原任务归属后，先将各行missing isNewBatch归一false并按requestId核对完整有效内容。同ID同归一后完整请求技术重传返原逐行接收结果、requestId\+行定位\+recordId/batchId/rootBatchId（含原失败/待核行），不重拆/新增/重交/新增实际呼叫。仅新ID才归组与主子分配；首导自动主或后来新主出现，旧请求重传仍原root，不重新选最近主。供应商证据独立保留，未知提交不因重传重交。

- **AC\-051**：已保存requestId的DCC重复请求，missing isNewBatch=false归一后完整有效内容不同（行数/行定位、tenant/原任务及各行leadCode/phone/priority/归一flag/已给R等业务字段），明确内容冲突并拒整个重复请求，不覆盖原逐行结果、不为任何行新增批次或提交。修改号码/priority/flag不能冒充技术重试；未传与显式false归一相同，true与false不同。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-005。产品：云呼叫中心 DCC 预外呼实际原型方案 / 1\.1\.0。

来源类型：reviewed；来源指纹：1c685199ed5a95789ae12252ec1c767614dc33176dc673815fccbe5647d2c4ec。

- product\-input\.json\#FUNC\-005

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
