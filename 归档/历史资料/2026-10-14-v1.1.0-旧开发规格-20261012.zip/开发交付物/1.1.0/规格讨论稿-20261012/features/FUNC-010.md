# 回传接口任务每次结果 · FUNC\-010

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

接口来源按实际record/batch/root、call或事件每次结果/失败/删除固定DCC合成交付；晚更新同对象版本，补送不新导入/删除/呼叫，手工仅查看。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md) — 共用页面，另有 10 个功能

## 局部逻辑

- [按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：可信且准确关联的导入失败、通话/无话单结果、秒挂、删除或同对象晚更新到达

- 结果及原record/batch/root/file/call或稳定事件映射已确认；锁定来源可读

### 处理步骤

1. **LOCAL\-010\-S01**：从当前实际记录读取原request和行定位、tenant/原task/lead/phone及已存root；不按最近主或lead单键拼接

2. **LOCAL\-010\-S02**：保留本次阶段、原原因、话单/SIP及finishRetryFlag三态；同对象晚更新作为相应交付版本

3. **LOCAL\-010\-S03**：按锁来源分流：接口每次交付后台固定DCC，手工仅平台查看；不提供前台接收端或发真实回调

4. **LOCAL\-010\-S04**：保存交付结果；失败补送原准确对象版本，不再执行导入/删除或形成新通话

### 分支与异常

- **LOCAL\-010\-B01**：当接口来源且可信精确关联，每次结果及晚更新都可交付，不仅最后一次。

- **LOCAL\-010\-B02**：当手工来源，只保留平台结果查看，不添加DCC请求/归组协议。

- **LOCAL\-010\-B03**：当交付失败或确认未知，显示待补送/待核，补送不重做供应商导入或增加实际呼叫。

- **LOCAL\-010\-B04**：当finishRetryFlag为1、0或未知，分别表达本次供应商最后一条/非最后/未知，不宣整个任务或DCC计划完成。

### 完成后的状态

- 接口来源每次结果固定后台DCC目的地交付，手工仅查看；交付失败可观察及补送，不重导或重算实际呼叫

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [坐席实际接听状态 · FIELD\-AGENT\-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [本地批次归属类型 · FIELD\-BATCH\-KIND](../field-specs.md#FIELD-BATCH-KIND)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [客户真实接听状态 · FIELD\-CUSTOMER\-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [DCC逐次交付状态 · FIELD\-DELIVERY\-STATE](../field-specs.md#FIELD-DELIVERY-STATE)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [结果来源与可信依据 · FIELD\-EVIDENCE\-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [业务结果发生时间 · FIELD\-OCCURRED\-AT](../field-specs.md#FIELD-OCCURRED-AT)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [客户手机号 · FIELD\-PHONE](../field-specs.md#FIELD-PHONE)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [呼叫或业务结果原因 · FIELD\-RESULT\-REASON](../field-specs.md#FIELD-RESULT-REASON)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [业务结果阶段 · FIELD\-RESULT\-STAGE](../field-specs.md#FIELD-RESULT-STAGE)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [同一结果更新版本 · FIELD\-RESULT\-VERSION](../field-specs.md#FIELD-RESULT-VERSION)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [待核原因 · FIELD\-REVIEW\-REASON](../field-specs.md#FIELD-REVIEW-REASON)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [请求内行定位 · FIELD\-ROW\-ID](../field-specs.md#FIELD-ROW-ID)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [秒挂识别结果 · FIELD\-SHORT\-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [话单状态描述 · FIELD\-STATUS\-DESC](../field-specs.md#FIELD-STATUS-DESC)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [DCC请求标识 · FLD\-002](../field-specs.md#FLD-002)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [业务租户 · FLD\-003](../field-specs.md#FLD-003)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [原供应商任务号 · FLD\-004](../field-specs.md#FLD-004)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [是否另开主批次 · FLD\-007](../field-specs.md#FLD-007)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [线索编码 · FLD\-008](../field-specs.md#FLD-008)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [本地本次批次号 · FLD\-010](../field-specs.md#FLD-010)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [本地记录号 · FLD\-011](../field-specs.md#FLD-011)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [关联主批次号 · FLD\-013](../field-specs.md#FLD-013)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [原逐行接收回执 · FLD\-015](../field-specs.md#FLD-015)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [本次供应商批次号 · FLD\-020](../field-specs.md#FLD-020)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [供应商最后一条标志 · FLD\-046](../field-specs.md#FLD-046)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [obSipCause原字段 · FLD\-047](../field-specs.md#FLD-047)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [sipCause原字段 · FLD\-049](../field-specs.md#FLD-049)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [话单原始状态码 · FLD\-051](../field-specs.md#FLD-051)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [真实通话或稳定事件标识 · FLD\-066](../field-specs.md#FLD-066)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [DCC接收确认 · FLD\-068](../field-specs.md#FLD-068)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

- [任务导入来源 · FLD\-078](../field-specs.md#FLD-078)；依据：[按任务来源交付每次结果及补送 · LOCAL\-010](../local-logic/LOCAL-010.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [本批次创建时间 · FIELD\-BATCH\-CREATED\-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前有效预览草稿 · FIELD\-CSV\-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [手工当前CSV文本 · FIELD\-CSV\-TEXT](../field-specs.md#FIELD-CSV-TEXT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [必要去重与关联留存 · FIELD\-DEDUP\-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前删除操作反馈 · FIELD\-DELETION\-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [精准删除当前目标与样例 · FIELD\-DELETION\-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败快照下载状态 · FIELD\-DOWNLOAD\-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次失败导出快照 · FIELD\-EXPORT\-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片完整性 · FIELD\-FRAGMENT\-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [原始导入时间 · FIELD\-ORIGINAL\-IMPORT\-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次本地接收时间 · FIELD\-RECEIVED\-AT](../field-specs.md#FIELD-RECEIVED-AT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本地保存稳定顺序 · FIELD\-RECEIVED\-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商提交状态 · FIELD\-SUBMISSION\-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [独立未可信SIP证据 · FIELD\-UNTRUSTED\-SIP](../field-specs.md#FIELD-UNTRUSTED-SIP)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [来源渠道R · FLD\-001](../field-specs.md#FLD-001)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次导入优先级 · FLD\-009](../field-specs.md#FLD-009)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商请求号码总数 · FLD\-021](../field-specs.md#FLD-021)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商非法号码数 · FLD\-022](../field-specs.md#FLD-022)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [供应商成功导入数 · FLD\-023](../field-specs.md#FLD-023)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [失败分片序号 · FLD\-028](../field-specs.md#FLD-028)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [导入失败原始原因 · FLD\-030](../field-specs.md#FLD-030)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [声明失败分片总数 · FLD\-035](../field-specs.md#FLD-035)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户实际接听时长原值 · FLD\-043](../field-specs.md#FLD-043)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [挂断来源原字段 · FLD\-048](../field-specs.md#FLD-048)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [SIP异步更新标志 · FLD\-050](../field-specs.md#FLD-050)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [本次精准删除结果 · FLD\-054](../field-specs.md#FLD-054)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

## 本功能验收

- **AC\-002**：关联线路侧风控的每次话单/SIP及结果；接口任务回传DCC，由DCC决定是否再次导入。供应商导航可能自动降级，不承诺绝对换主叫，不叠加平台重导。

- **AC\-018**：平台每次回传接口任务的风控失败原因、秒挂识别、话单状态、SIP状态及finishRetryFlag；后台配置固定DCC接收地址，无前台配置或任务应用绑定。

- **AC\-026**：三天五呼及重导次数由DCC管理，单任务范围，初呼及秒挂同计5次目标，首次导入当日第1天；普通双方接通停止但秒挂例外。平台不重复调度计数。

- **AC\-027**：初呼与秒挂共用单任务5次目标，由DCC按真实尝试汇总；重新导入请求或重复通知不直接计实际呼叫，平台不新增业务额度。

- **AC\-037**：接口任务每次结果向后台配置文件固定地址回传DCC；手工任务不回传仅平台查看，不新增前台或租户接收端设置，不设置实际URL或发送真实回调。

- **AC\-038**：finishRetryFlag Integer1最后一条/0否，未知或未返回独立表示；与SIP异步更新分开，不能据其宣布整个任务或DCC计划完成；每次结果回传，不只最终一次。

- **AC\-039**：同步返回result=0不代表逐条全成功：分别展示本地校验/保存、供应商导入、呼叫阶段；保留importTotal/successTotal/invalidTotal原始数量与来源。有准确同步证据的成功正常记录；仅汇总数量不能任意指定成功行，未知/矛盾待核，不将同步响应一概降为仅受理。

- **AC\-040**：接收53失败结果分片，按enterpriseId经核实租户映射、taskId、fileId及原始号码数据回查本次本地批次和leadCode；多候选待核，不按最近同号盲配。totalBatchCount/currentBatchCount仅为失败推送分片，不是业务批次；重复不新增、乱序迟到不丢。收齐已声明分片只证明该失败推送组收齐，不证明全导入终态；未收到不推定零失败。

- **AC\-041**：接口来源任务向后台固定DCC接收地址回传导入阶段失败、原始原因和tenant/task/本地批次/leadCode/手机号关联；手工任务只在平台查看。导入失败不计实际呼叫、不触发平台重导；回传失败保持可观察待补送，补送不重做供应商导入。

- **AC\-042**：在既有失败导出入口生成本次失败明细快照并显示已知分片完整性；未收齐或完整性未知显示不完整/待核。可信下载成功仅删除该快照的明细和文件，失败/中断保留；后到的新失败进入后续下载。保留必要业务关联、去重标记、分片及DCC交付状态，已导出事件重复不再生成失败明细；不得清空整个导入或成功客户。

- **AC\-043**：使用显式合成数据验收：同步部分成功并关联异步失败；失败分片乱序、重复及迟到；下载成功后新失败可再次导出、旧重复不再生；DCC回传失败可补送且不新增导入/实际呼叫。映射冲突、分片声明冲突或结果矛盾保持待核；无零失败推送及终态协议不伪造完成。

- **AC\-052**：DCC逐行回执携requestId\+行定位、tenant/原supplierTaskId/leadCode/phone及recordId/batchId/rootBatchId；结果由精确vendorfileId/实际批次/原始号码及callID或稳定事件匹配后携保存的相同业务关联回传。leadCode归组不替代实际供应商/call匹配；previous/parent不再必需且不虚构。原逐行幂等结果、固定phone组/主子root/精确供应商通话映射不随失败快照清理或精准删除丢失；重复/晚更新/补送不新增导入或呼叫。手工仅平台查看不新增DCC协议。

- **AC\-062**：未可信的纯SIP包保留独立待核来源证据，不改写已确认呼叫业务结果、不冒充已确认非SIP冲突，也不阻止随后准确关联且可信的call/SIP更新。分别验证“未可信SIP→可信call→可信SIP”和“可信call→未可信SIP→可信SIP”：无其他真实非SIP矛盾时均更新同一原call的SIP字段及相应交付版本，不新增实际呼叫；真正可信的关联或非SIP结果冲突仍待核。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-010。产品：云呼叫中心 DCC 预外呼实际原型方案 / 1\.1\.0。

来源类型：reviewed；来源指纹：1c685199ed5a95789ae12252ec1c767614dc33176dc673815fccbe5647d2c4ec。

- product\-input\.json\#FUNC\-010

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
