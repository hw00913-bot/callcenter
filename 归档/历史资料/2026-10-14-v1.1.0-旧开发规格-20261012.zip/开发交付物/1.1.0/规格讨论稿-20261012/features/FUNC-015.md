# 查询任务业务记录 · FUNC\-015

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

任务级记录/失败/结果/交付/删除查询，显示当前record/batch/root及主子，固定phone组不替代精确file/call；原时间审计、每日衰减退出。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md) — 共用页面，另有 10 个功能

## 局部逻辑

- [查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：用户进入具体预外呼任务记录页并切换明细视图

- 用户沿既有权限能访问该租户任务；任务来源锁定

### 处理步骤

1. **LOCAL\-015\-S01**：在任务范围读取锁来源和记录，不把业务记录页另设顶级运营入口；必要的既有查询只读、不恢复每日轮询

2. **LOCAL\-015\-S02**：按实际记录显示batch/root及接口主子组，显示本次priority与仅审计时间；手工不出现DCC协议输入

3. **LOCAL\-015\-S03**：分开展示本地校验保存、供应商同步数量/异步分片、呼叫结果及交付/下载/删除状态和待核证据

4. **LOCAL\-015\-S04**：显示同任务待提交priority/FIFO次序及常驻导入入口；不可导入显示原因不改变来源或原补导规则

### 分支与异常

- **LOCAL\-015\-B01**：当接口同lead有多个主及各自子，按保存root显示，不因新主改变旧记录或晚结果归属。

- **LOCAL\-015\-B02**：当只有汇总、分片不全或结果待核，保留原数量/未知状态，不以列表展示推成全成功。

- **LOCAL\-015\-B03**：当手工任务或权限/状态不能导入，手工只看原记录单号批次；常驻入口不可用时保留原因，无DCC回传/归组表单。

### 完成后的状态

- 准确显示该任务本地/供应商/呼叫/交付分阶段事实和主子追溯；不新增顶级运营入口或每日策略

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [坐席实际接听状态 · FIELD\-AGENT\-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本批次创建时间 · FIELD\-BATCH\-CREATED\-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本地批次归属类型 · FIELD\-BATCH\-KIND](../field-specs.md#FIELD-BATCH-KIND)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [客户真实接听状态 · FIELD\-CUSTOMER\-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [必要去重与关联留存 · FIELD\-DEDUP\-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [DCC逐次交付状态 · FIELD\-DELIVERY\-STATE](../field-specs.md#FIELD-DELIVERY-STATE)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [失败快照下载状态 · FIELD\-DOWNLOAD\-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [结果来源与可信依据 · FIELD\-EVIDENCE\-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本次失败导出快照 · FIELD\-EXPORT\-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [失败分片完整性 · FIELD\-FRAGMENT\-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [原始导入时间 · FIELD\-ORIGINAL\-IMPORT\-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [客户手机号 · FIELD\-PHONE](../field-specs.md#FIELD-PHONE)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本次本地接收时间 · FIELD\-RECEIVED\-AT](../field-specs.md#FIELD-RECEIVED-AT)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本地保存稳定顺序 · FIELD\-RECEIVED\-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [呼叫或业务结果原因 · FIELD\-RESULT\-REASON](../field-specs.md#FIELD-RESULT-REASON)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [同一结果更新版本 · FIELD\-RESULT\-VERSION](../field-specs.md#FIELD-RESULT-VERSION)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [待核原因 · FIELD\-REVIEW\-REASON](../field-specs.md#FIELD-REVIEW-REASON)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [请求内行定位 · FIELD\-ROW\-ID](../field-specs.md#FIELD-ROW-ID)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [秒挂识别结果 · FIELD\-SHORT\-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [话单状态描述 · FIELD\-STATUS\-DESC](../field-specs.md#FIELD-STATUS-DESC)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [供应商提交状态 · FIELD\-SUBMISSION\-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [独立未可信SIP证据 · FIELD\-UNTRUSTED\-SIP](../field-specs.md#FIELD-UNTRUSTED-SIP)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [来源渠道R · FLD\-001](../field-specs.md#FLD-001)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [DCC请求标识 · FLD\-002](../field-specs.md#FLD-002)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [业务租户 · FLD\-003](../field-specs.md#FLD-003)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [原供应商任务号 · FLD\-004](../field-specs.md#FLD-004)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [是否另开主批次 · FLD\-007](../field-specs.md#FLD-007)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [线索编码 · FLD\-008](../field-specs.md#FLD-008)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本次导入优先级 · FLD\-009](../field-specs.md#FLD-009)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本地本次批次号 · FLD\-010](../field-specs.md#FLD-010)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本地记录号 · FLD\-011](../field-specs.md#FLD-011)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [关联主批次号 · FLD\-013](../field-specs.md#FLD-013)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [原逐行接收回执 · FLD\-015](../field-specs.md#FLD-015)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本次供应商批次号 · FLD\-020](../field-specs.md#FLD-020)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [供应商请求号码总数 · FLD\-021](../field-specs.md#FLD-021)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [供应商非法号码数 · FLD\-022](../field-specs.md#FLD-022)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [供应商成功导入数 · FLD\-023](../field-specs.md#FLD-023)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [失败分片序号 · FLD\-028](../field-specs.md#FLD-028)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [导入失败原始原因 · FLD\-030](../field-specs.md#FLD-030)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [声明失败分片总数 · FLD\-035](../field-specs.md#FLD-035)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [话单查询开始时间 · FLD\-040](../field-specs.md#FLD-040)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [话单查询结束时间 · FLD\-041](../field-specs.md#FLD-041)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [供应商最后一条标志 · FLD\-046](../field-specs.md#FLD-046)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [obSipCause原字段 · FLD\-047](../field-specs.md#FLD-047)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [sipCause原字段 · FLD\-049](../field-specs.md#FLD-049)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [SIP异步更新标志 · FLD\-050](../field-specs.md#FLD-050)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [话单原始状态码 · FLD\-051](../field-specs.md#FLD-051)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [本次精准删除结果 · FLD\-054](../field-specs.md#FLD-054)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [真实通话或稳定事件标识 · FLD\-066](../field-specs.md#FLD-066)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

- [任务导入来源 · FLD\-078](../field-specs.md#FLD-078)；依据：[查询任务级导入、结果与交付记录 · LOCAL\-015](../local-logic/LOCAL-015.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [当前有效预览草稿 · FIELD\-CSV\-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [手工当前CSV文本 · FIELD\-CSV\-TEXT](../field-specs.md#FIELD-CSV-TEXT)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [当前删除操作反馈 · FIELD\-DELETION\-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [精准删除当前目标与样例 · FIELD\-DELETION\-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [客户实际接听时长原值 · FLD\-043](../field-specs.md#FLD-043)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

- [挂断来源原字段 · FLD\-048](../field-specs.md#FLD-048)；依据：[预外呼任务记录页 · UI\-PAGE\-002](../ui-pages/UI-PAGE-002.md)

## 本功能验收

- **AC\-028**：系统设置新增应用接入管理菜单，承载列表、新增、详情、修改、删除各独立操作；预外呼导入/重呼记录仍为任务级独立记录页，不建独立顶级运营入口，预外呼保留常驻导入客户入口。

- **AC\-029**：预外呼“导入客户”入口常驻，按任务已锁DCC接口或手工来源进入对应入口；接口任务不能手工混入，手工任务按既有导入并仅平台查看结果。权限/状态不可导入时保留禁用入口和原因，后端同时校验来源、租户任务归属；不通过按钮改变既有历史任务可补导状态规则。

- **AC\-037**：接口任务每次结果向后台配置文件固定地址回传DCC；手工任务不回传仅平台查看，不新增前台或租户接收端设置，不设置实际URL或发送真实回调。

- **AC\-038**：finishRetryFlag Integer1最后一条/0否，未知或未返回独立表示；与SIP异步更新分开，不能据其宣布整个任务或DCC计划完成；每次结果回传，不只最终一次。

- **AC\-039**：同步返回result=0不代表逐条全成功：分别展示本地校验/保存、供应商导入、呼叫阶段；保留importTotal/successTotal/invalidTotal原始数量与来源。有准确同步证据的成功正常记录；仅汇总数量不能任意指定成功行，未知/矛盾待核，不将同步响应一概降为仅受理。

- **AC\-040**：接收53失败结果分片，按enterpriseId经核实租户映射、taskId、fileId及原始号码数据回查本次本地批次和leadCode；多候选待核，不按最近同号盲配。totalBatchCount/currentBatchCount仅为失败推送分片，不是业务批次；重复不新增、乱序迟到不丢。收齐已声明分片只证明该失败推送组收齐，不证明全导入终态；未收到不推定零失败。

- **AC\-041**：接口来源任务向后台固定DCC接收地址回传导入阶段失败、原始原因和tenant/task/本地批次/leadCode/手机号关联；手工任务只在平台查看。导入失败不计实际呼叫、不触发平台重导；回传失败保持可观察待补送，补送不重做供应商导入。

- **AC\-042**：在既有失败导出入口生成本次失败明细快照并显示已知分片完整性；未收齐或完整性未知显示不完整/待核。可信下载成功仅删除该快照的明细和文件，失败/中断保留；后到的新失败进入后续下载。保留必要业务关联、去重标记、分片及DCC交付状态，已导出事件重复不再生成失败明细；不得清空整个导入或成功客户。

- **AC\-043**：使用显式合成数据验收：同步部分成功并关联异步失败；失败分片乱序、重复及迟到；下载成功后新失败可再次导出、旧重复不再生；DCC回传失败可补送且不新增导入/实际呼叫。映射冲突、分片声明冲突或结果矛盾保持待核；无零失败推送及终态协议不伪造完成。

- **AC\-014**：本地保存线索、本次实际priority和每次接收/新记录批次创建时间；DCC接口保存tenant/原supplierTaskId/leadCode固定phone组、requestId\+行定位、recordId/batchId/rootBatchId及精确供应商/通话映射。DCC用本次输入priority，手工沿提交前统一/逐条最终值；原始导入时间仅审计，不用于平台衰减或决定本次priority。

- **AC\-015**：平台取消每日定时查询当天/历史待跟进号码状态及自然日priority衰减，不因未拨、已拨未接通、跨日或原导入日期计算并改写存量priority；仅服务衰减的状态查询一并退出。既有每次事件/话单/无话单失败的记录与按任务来源回传或查看继续保留。

- **AC\-019**：DCC决定是否及何时再次业务导入，新业务用新requestId、可多行，各行本次priority与可选Boolean isNewBatch，未传归一false。平台先鉴权/归一后完整请求幂等，仅新ID逐行按tenant/原supplierTaskId/leadCode固定phone归组；true新独立主root=batch，false/缺省有主新子root=最近已保存同组主，无主自动首主。有效新行始终新record/batch，逐行回执requestId\+行定位/组归属/batch/root，无需DCC previous、不虚构parent。本次priority以DCC输入、不旧继承，原时间审计；DCC汇总真实呼叫计数，平台不建额度。

- **AC\-032**：本次已保存/提交的priority不因北京时间换日、原导入时间、之前批次priority或工作时间自动变化；平台不执行每日状态查询、自然日衰减或存量priority写回，也不保留线路/秒挂30分钟重导调度。

- **AC\-047**：DCC每次业务请求携请求级requestId，可多行/不同线索组；每行明确行定位、leadCode、phone、本次priority和可选Boolean isNewBatch，missing=false。新业务用新ID，所有有效新行均新recordId和独立单手机号batchId并保存rootBatchId；逐行回执同requestId及行定位，主子都不覆盖旧记录。false/缺省复用的是主批关联，不重用旧record/batch编号。

- **AC\-048**：仅DCC新业务有效行进行主子分配：同tenant/原supplierTaskId/leadCode组首次固定phone；true允许同组另开独立主\(rootBatchId=batchId\)。false/缺省有已保存同组主时新子root=最近主batch，无主自动首主root=batch。最近主按本地主批创建顺序/稳定顺序确定，不按最近同号/结果时间/priority/子批，子不挂上一子。DCC previousBatchId和parentBatchId不为本方必需请求/响应，也不暗中虚构parent。

- **AC\-049**：DCC新请求逐行校验tenant/原supplierTaskId/leadCode组归属及固定phone；同组改号、归属冲突、历史组/主关系不明或冲突，明确拒绝或待核不提交，不改旧记录/盲配，其他有效行继续。跨tenant/原任务不混组，相同leadCode在不同合法作用域隔离处理。同号多lead未决关系不自动放开，isNewBatch=true不绕过，也不改DCC计次；isNewBatch提供时必须Boolean、缺省false与显式false有效内容相同，不因缺上一批次字段拒绝。

- **AC\-050**：DCC鉴权及租户/原任务归属后，先将各行missing isNewBatch归一false并按requestId核对完整有效内容。同ID同归一后完整请求技术重传返原逐行接收结果、requestId\+行定位\+recordId/batchId/rootBatchId（含原失败/待核行），不重拆/新增/重交/新增实际呼叫。仅新ID才归组与主子分配；首导自动主或后来新主出现，旧请求重传仍原root，不重新选最近主。供应商证据独立保留，未知提交不因重传重交。

- **AC\-051**：已保存requestId的DCC重复请求，missing isNewBatch=false归一后完整有效内容不同（行数/行定位、tenant/原任务及各行leadCode/phone/priority/归一flag/已给R等业务字段），明确内容冲突并拒整个重复请求，不覆盖原逐行结果、不为任何行新增批次或提交。修改号码/priority/flag不能冒充技术重试；未传与显式false归一相同，true与false不同。

- **AC\-052**：DCC逐行回执携requestId\+行定位、tenant/原supplierTaskId/leadCode/phone及recordId/batchId/rootBatchId；结果由精确vendorfileId/实际批次/原始号码及callID或稳定事件匹配后携保存的相同业务关联回传。leadCode归组不替代实际供应商/call匹配；previous/parent不再必需且不虚构。原逐行幂等结果、固定phone组/主子root/精确供应商通话映射不随失败快照清理或精准删除丢失；重复/晚更新/补送不新增导入或呼叫。手工仅平台查看不新增DCC协议。

- **AC\-059**：预外呼任务列表和任务内保持“导入客户”入口可见；入口按选定任务已锁来源打开DCC接口合成接收或既有手工导入，不能切换或混用来源。当前身份/只读/任务状态不可导入时保留禁用入口及明确原因，不以隐藏替代说明。历史可补导任务仅未启动状态按既有权限/名单规则补导，保留原名单/批次并累计；不藉常驻入口扩展启动后的历史任务导入策略。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-015。产品：云呼叫中心 DCC 预外呼实际原型方案 / 1\.1\.0。

来源类型：reviewed；来源指纹：1c685199ed5a95789ae12252ec1c767614dc33176dc673815fccbe5647d2c4ec。

- product\-input\.json\#FUNC\-015

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
