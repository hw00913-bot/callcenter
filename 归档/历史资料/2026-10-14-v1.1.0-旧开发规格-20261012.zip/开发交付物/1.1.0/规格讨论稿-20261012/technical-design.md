# 技术方案

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](README.md) · [按功能阅读](features/README.md)

本次交付为产品说明。开发人员应先阅读 [开发补充清单](developer-supplement.md)，补齐当前范围的工程方案，再通过开发开工门禁。允许先进行脚手架搭建和技术验证。

## 方案说明

未填写

## 工程约束

目标类型：None

技术栈：
- 未填写

未填写

编码规则：
- 未填写

测试策略：
- 未填写

其他约束：
- 未填写

## 模块与复用

## 接口与能力依据

见[接口与事件清单](interface-list.md)。这是本轮补充的接口契约讨论稿：包含已确认业务边界与带来源的供应商文档事实；未验证的协议仍明确列为缺口，不表示其余工程设计已完成。

## 数据变更

- 未填写

## 权限

- 未填写

## 异常与一致性

- 未填写

## 非功能要求

- 未填写

## 迁移与回退

需要迁移：None

未填写

## 未决项处置

- ISSUE-001 / resolved：旧9月30日基线已被新批准方案替代，旧原件真实性缺口仍保留审计；规划只用当前已批准输入。；依据 product-input.json#ISSUE-001
- ISSUE-002 / deferred：业务主子批和请求重试规则已确认；生产事务原子性、并发创建顺序、同号再次导入的供应商排重和独立fileId接收证据仍缺。保留待核，不以合成验证证明实际接收。；依据 product-input.json#ISSUE-002
- ISSUE-003 / resolved：平台换主叫接口已退出范围；线路侧结果回传由当前FUNC010承接，不承诺供应商一定更换主叫。其他真实事件协议按deferred问题保留。；依据 product-input.json#BR-008, product-input.json#API-007
- ISSUE-004 / out_of_scope：本平台解除、恢复及自动重导已明确退出范围；供应商解除由DCC对接方负责。当前仍实现可信无话单失败回传，不因缺解除信号延迟；此项排除不声称供应商机制已核实。；依据 product-input.json#ISSUE-004
- ISSUE-005 / deferred：客户真实接听且主动挂断、0至2秒含边界规则明确；供应商接通字段、主动挂断枚举、真实时长单位尚未形成可执行映射。保留待核，不能以坐席桥接时长代替。；依据 product-input.json#ISSUE-005
- ISSUE-006 / resolved：当前范围不含平台换主叫及解除接口；结果原值、精确关联和可靠交付仍由对应deferred问题约束。本条关闭只针对已取消能力争议，不宣称供应商能力已核实。；依据 product-input.json#API-007, product-input.json#API-008, product-input.json#BR-008, product-input.json#BR-015
- ISSUE-007 / resolved：R字段可选、不维护字典、不做字典范围校验；缺R不失败，提供时保存来源。通用技术长度等仍由实际工程约束。；依据 product-input.json#BR-003, product-input.json#AC-001, product-input.json#AC-005
- ISSUE-008 / deferred：只有可信的本次下载成功才清理该快照明细文件；真实成功信号和中断区分仍未确定，不能以点击、链接生成或服务器开始响应作为成功。；依据 product-input.json#ISSUE-008
- ISSUE-009 / resolved：未成功下载的失败明细持续保留，用户从既有任务失败入口生成本次快照并下载；没有新建独立历史检索页面范围。；依据 product-input.json#BR-005, product-input.json#BR-019, product-input.json#AC-008
- ISSUE-010 / resolved：失败结果由运营人员在云呼叫中心下载；早期3天期限已被后续无固定到期规则替代。两种来源共用成功下载才清本快照明细/文件的生命周期。；依据 product-input.json#ISSUE-010, product-input.json#ISSUE-011, product-input.json#BR-005, product-input.json#BR-019
- ISSUE-011 / resolved：已取消3天/72小时固定到期，失败未成功下载持续保留；成功清理范围按当前导出快照界定。；依据 product-input.json#BR-005, product-input.json#BR-019, product-input.json#AC-008
- ISSUE-012 / resolved：仅在可信成功下载后清除本次快照失败明细及对应文件；成功客户、必要幂等/组/root/供应商映射、事件分片交付依据保留，后到失败另行导出。真实成功判据仍在ISSUE008。；依据 product-input.json#BR-019, product-input.json#AC-042, product-input.json#AC-043, product-input.json#AC-052
- ISSUE-013 / resolved：priority用于本次供应商提交，并按最新确认BR021在同任务待提交队列高值先、同级本地时间FIFO；不保证供应商实际拨打次序，不从R映射或跨日衰减。早期未引入本地排序的措辞不再作为现行限制。；依据 product-input.json#BR-003, product-input.json#BR-006, product-input.json#BR-021, product-input.json#AC-046
- ISSUE-014 / resolved：priority每有效行必填，无缺省值；缺失仅该条失败，其他有效条继续；不得用R或旧批值补齐。真实供应商类型/范围仍按字段及接口缺口保留。；依据 product-input.json#BR-003, product-input.json#AC-009
- ISSUE-015 / resolved：DCC按租户/原供应商任务/线索固定同号归组；true新主、false或缺省有主新子挂最近已保存主，无主首主。每有效新行独立记录批次，本次priority不继承旧值；同request重传原回执，不重新选主。；依据 product-input.json#BR-012, product-input.json#AC-047, product-input.json#AC-048, product-input.json#AC-049, product-input.json#AC-050, product-input.json#AC-051
- ISSUE-016 / resolved：每次有效新业务导入新增独立本地记录与本次单号批次，不覆盖旧记录；技术请求重试返回原映射。；依据 product-input.json#BR-002, product-input.json#BR-012, product-input.json#AC-007, product-input.json#AC-050
- ISSUE-017 / resolved：有效新业务保存后自动进入本任务待提交队列并提交供应商，无额外运营手工提交门槛；未知提交不重交，明确拒绝进入失败记录。；依据 product-input.json#BR-004, product-input.json#BR-021, product-input.json#AC-011
- ISSUE-018 / resolved：DCC携带原供应商taskId直接提交；平台校验租户与任务归属，不用本地任务ID替换、不采用统一预配置目标。命名空间已由后续ISSUE019明确。；依据 product-input.json#ISSUE-019, product-input.json#BR-004, product-input.json#AC-012
- ISSUE-019 / resolved：taskId属于供应商任务命名空间并原值提交；本地任务标识可用于界面定位，但不冒充供应商接口taskId。；依据 product-input.json#BR-004, product-input.json#AC-012
- ISSUE-020 / resolved：本地保存成功后供应商明确拒绝仍保留该业务记录，失败明细记录原始原因供下载；超时、汇总矛盾或关联不明保持待核，不伪造成明确拒绝。；依据 product-input.json#BR-004, product-input.json#BR-018, product-input.json#AC-013, product-input.json#AC-039
- ISSUE-021 / out_of_scope：历史消息原件及时间追溯缺口仅保留审计。本轮按已批准产品快照与现行业务正文规划，不尝试重建原件或作为新增功能；真实性缺口保持未恢复。；依据 product-input.json#ISSUE-021
- ISSUE-022 / deferred：删除目标必须精确到本次实际供应商批次号码，其他同号批次及本地关联保留；供应商执行中删除、并发、幂等和可信成功确认未实测。；依据 product-input.json#ISSUE-022
- ISSUE-023 / resolved：业务重导与次数由DCC决策，平台不实现旧30分钟计时、额外次数配额或换主叫接口；可信每次结果按当前规则回传。供应商内部实际尝试证据仍需核实。；依据 product-input.json#BR-008, product-input.json#BR-011, product-input.json#BR-013
- ISSUE-024 / out_of_scope：本平台解除、恢复及自动重导已明确退出范围；供应商解除由DCC对接方负责。当前仍实现可信无话单失败回传，不因缺解除信号延迟；此项排除不声称供应商机制已核实。；依据 product-input.json#ISSUE-024
- ISSUE-025 / resolved：业务重导计数由DCC管理，平台不新增预算；导入请求、技术重试或重复通知不直接视作新实际呼叫；0秒秒挂须真实客户接通及客户主动挂断证据。；依据 product-input.json#BR-010, product-input.json#BR-011, product-input.json#BR-013, product-input.json#AC-027, product-input.json#AC-034
- ISSUE-026 / deferred：逐行回执及每次结果的当前batch/root映射已明确；固定地址认证、ACK、去重晚更新与补送可靠性仍待正式接口协议和联调。补送不能变成业务重导。；依据 product-input.json#ISSUE-026
- ISSUE-027 / deferred：53通知的精确fileId、原始号码、分片完整性保留；认证、稳定事件ID、零失败通知、迟到更正、failedTelList实际编码与可关联证据未核。；依据 product-input.json#ISSUE-027
- ISSUE-028 / resolved：同任务待提交队列按本次priority高先、同级本地导入时间FIFO；不同任务独立，已提交不撤回重排，未知提交不因排序重复提交。；依据 product-input.json#BR-021, product-input.json#AC-046
- ISSUE-029 / deferred：自动启动不得突破禁呼与呼叫时间，但全部时间覆盖、时区跨日、任务各状态接收行为仍缺供应商实证；不增平台放行定时器。；依据 product-input.json#ISSUE-029
- ISSUE-030 / resolved：旧反馈的重复转交与来源追溯已纠正，不构成本轮新采购或业务决定；供应商实际接口缺口仍保留在现行API与8个deferred问题。；依据 product-input.json#ISSUE-030, product-input.json#API-003, product-input.json#API-007
- ISSUE-031 / deferred：应用五项操作与密钥获取token目的已批准；真实密钥生成和安全存储、CRUD持久化、删除后的既有token撤销时效仍未定义。合成立即失效和当前名称长度不升级为生产事实。；依据 product-input.json#ISSUE-031

## 开放问题

无记录中的开放问题。

## 评审说明

- 业务、运营于2026-10-12明确批准原型快照5b0319787ae95a3a0fa49e214cbe460b1283fab1ab6433922a8f0b988d41768c并进入05。来源内旧pending字样作为批准前原始正文保留；当前批准权威为project-handoff和共享台账，未改写已批准原型。
- 保留唯一prototype；采用既有兼容两JSON产品交接，保存于开发交付物/1.1.0/产品输入-5b0319787ae9，不生成按版本的原型副本。兼容包未声明额外只读静态原型快照。
- 05产品规格按已确认业务语义展开。接口联调未完成，8项deferred问题真实保留，故当前交付为讨论稿，不标READY_FOR_ENGINEERING_DESIGN或READY_FOR_DEVELOPMENT。
- 输入中的decision_history/review_history/scope_history与before旧树仅追溯；本轮覆盖中明确排除，不复活每日衰减、previousBatchId或平台自动重导。
- 主/子两层均是一条号码的一次业务导入；root只归组，每次供应商导入映射本次fileId。供应商查询用该记录的原taskId和实际fileId，不能用root冒充；相同requestId重试返回原记录。
- 本轮编写验收方法，尚未运行生产业务验收；现有合成原型的验证不替代真实API、并发或安全验证。
- 05语义交叉复核修正：任务tenant/原supplierTaskId创建后锁定；后台鉴权只按校验用途读应用材料；每个DCC请求含技术重传先归一flag；完成逐行接收判定时保存含失败行的原回执；空应用列表仍保留查询与0总数。均为已批准规则的明确化，未更改原型或提升真实接口状态。
