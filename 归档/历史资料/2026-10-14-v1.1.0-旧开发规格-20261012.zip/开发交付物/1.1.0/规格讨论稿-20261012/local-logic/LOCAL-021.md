# LOCAL-021 确认删除指定应用

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [删除应用 · FUNC\-021](../features/FUNC-021.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-021

触发：超管从列表或详情对具体应用发起并确认删除

## 前置条件

- 当前身份和精确目标再次校验；删除需明确确认

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-020](../global-logic.md#GR-020)

## 输入与输出

输入：[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FLD-093](../field-specs.md#FLD-093)、[FLD-006](../field-specs.md#FLD-006)、[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-089](../field-specs.md#FLD-089)

输出：[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)

## 处理步骤

### LOCAL-021-S01

显示当前目标删除确认；提交时再次核对权限和对象

读取：FLD-089, FIELD-APP-CREATED, FLD-090, FIELD-APP-ID；写入：无

规则：GR-001, GR-020

### LOCAL-021-S02

保存删除成功后从列表移除并使该应用合成凭证/已发身份无效

读取：FIELD-APP-ID, FLD-093, FLD-006, FLD-090, FIELD-APP-CREATED；写入：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED

规则：GR-001, GR-020

### LOCAL-021-S03

保留业务任务/导入/结果与必要来源审计；只展示当前删除结果，不修改供应商删除或DCC交付状态

读取：FLD-090, FIELD-APP-ID；写入：无

规则：GR-001, GR-020

## 分支与异常

### LOCAL-021-B01

条件：取消或保存失败

结果：不删除、不提前撤销身份，不显示删除成功

涉及字段：FIELD-APP-ID, FLD-093, FLD-006, FLD-090, FIELD-APP-CREATED

验证：CHECK-057

### LOCAL-021-B02

条件：确认且精确删除成功

结果：该应用不能再查看/修改或申请身份，其他应用/身份与业务历史不变；真实token撤销机制仍待核

涉及字段：FIELD-APP-ID, FLD-093, FLD-006, FLD-090, FIELD-APP-CREATED

验证：CHECK-057

### LOCAL-021-B03

条件：非超管或目标已变

结果：拒绝当前操作，不改其他应用

涉及字段：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED

验证：CHECK-044, CHECK-057

## 完成后的状态

- 成功只删除当前应用并使其合成凭证/已发身份失效；业务历史与其他应用保持

## 字段定义

- [FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)
- [FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)
- [FLD-006](../field-specs.md#FLD-006)
- [FLD-089](../field-specs.md#FLD-089)
- [FLD-090](../field-specs.md#FLD-090)
- [FLD-093](../field-specs.md#FLD-093)

## 来源与验证

来源条目：acceptance:AC-044, acceptance:AC-045, acceptance:AC-057, acceptance:AC-058, features:FUNC-021, features:FUNC-021/boundary/business_rules/0, features:FUNC-021/boundary/business_rules/1, features:FUNC-021/boundary/exception_paths/0, features:FUNC-021/boundary/exception_paths/1, features:FUNC-021/boundary/exception_paths/2, interfaces:API-001, open_items:ISSUE-002, open_items:ISSUE-022, open_items:ISSUE-031, pages:PAGE-001, pages:PAGE-001/actions/0, pages:PAGE-001/actions/1, pages:PAGE-001/actions/2, pages:PAGE-001/actions/3, pages:PAGE-001/actions/4, pages:PAGE-004, pages:PAGE-004/actions/0, pages:PAGE-004/actions/1, pages:PAGE-004/actions/2, scenarios:SC-005, scenarios:SC-005/alternate_flows/0, scenarios:SC-005/alternate_flows/0/steps/0, scenarios:SC-005/alternate_flows/1, scenarios:SC-005/alternate_flows/1/steps/0, scenarios:SC-005/alternate_flows/2, scenarios:SC-005/alternate_flows/2/steps/0, scenarios:SC-005/alternate_flows/3, scenarios:SC-005/alternate_flows/3/steps/0, scenarios:SC-005/alternate_flows/4, scenarios:SC-005/alternate_flows/4/steps/0, scenarios:SC-005/main_flow/0, scenarios:SC-005/main_flow/1, scenarios:SC-005/main_flow/2, scenarios:SC-005/main_flow/3, scenarios:SC-005/main_flow/4, scenarios:SC-005/postconditions/0, scenarios:SC-005/postconditions/1, scenarios:SC-005/postconditions/2, scenarios:SC-005/preconditions/0, scenarios:SC-005/preconditions/1, scenarios:SC-005/preconditions/2, sequences:SEQ-005, sequences:SEQ-005/messages/0, sequences:SEQ-005/messages/1, sequences:SEQ-005/messages/10, sequences:SEQ-005/messages/11, sequences:SEQ-005/messages/12, sequences:SEQ-005/messages/13, sequences:SEQ-005/messages/14, sequences:SEQ-005/messages/2, sequences:SEQ-005/messages/3, sequences:SEQ-005/messages/4, sequences:SEQ-005/messages/5, sequences:SEQ-005/messages/6, sequences:SEQ-005/messages/7, sequences:SEQ-005/messages/8, sequences:SEQ-005/messages/9

验证：CHECK-044, CHECK-045, CHECK-057, CHECK-058

## 实施任务

未声明；请结合范围说明核对。
