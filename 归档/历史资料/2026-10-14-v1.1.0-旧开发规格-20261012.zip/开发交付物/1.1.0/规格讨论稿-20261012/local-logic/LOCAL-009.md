# LOCAL-009 精确删除指定供应商批次号码

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [删除指定供应商号码 · FUNC\-009](../features/FUNC-009.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-009

触发：DCC请求删除指定租户原任务中的当前记录/批次号码

## 前置条件

- 租户身份有效；record/batch/fileId/phone精确映射明确，root仅追溯

## 必须遵守的全局规则

- [GR-007](../global-logic.md#GR-007)
- [GR-012](../global-logic.md#GR-012)
- [GR-015](../global-logic.md#GR-015)
- [GR-017](../global-logic.md#GR-017)
- [GR-019](../global-logic.md#GR-019)

## 输入与输出

输入：[FLD-003](../field-specs.md#FLD-003)、[FLD-004](../field-specs.md#FLD-004)、[FLD-006](../field-specs.md#FLD-006)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-010](../field-specs.md#FLD-010)、[FLD-011](../field-specs.md#FLD-011)、[FLD-013](../field-specs.md#FLD-013)、[FLD-020](../field-specs.md#FLD-020)、[FLD-054](../field-specs.md#FLD-054)、[FIELD-DELETION-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)、[FIELD-DELETION-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)

输出：[FLD-054](../field-specs.md#FLD-054)、[FLD-011](../field-specs.md#FLD-011)、[FLD-010](../field-specs.md#FLD-010)、[FLD-020](../field-specs.md#FLD-020)、[FIELD-DELETION-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)、[FIELD-DELETION-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)、[FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)、[FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)

## 处理步骤

### LOCAL-009-S01

重核租户/原任务和精确record/batch/fileId/phone，拒绝root或lead单键整组定位

读取：FLD-003, FLD-004, FLD-006, FLD-008, FIELD-PHONE, FLD-010, FLD-011, FLD-013, FLD-020；写入：无

规则：GR-007, GR-012, GR-015

### LOCAL-009-S02

切换目标或合成结果样例即清旧界面反馈，旧对象保存证据保持

读取：FLD-011, FLD-010, FLD-020, FIELD-DELETION-SELECTION, FIELD-DELETION-FEEDBACK, FLD-054；写入：FLD-011, FLD-010, FLD-020, FIELD-DELETION-SELECTION, FIELD-DELETION-FEEDBACK, FLD-054

规则：GR-007, GR-015

### LOCAL-009-S03

发起对应精确目标合成删除并登记明确成功/失败/未知；真实参数作用域及并发仍待核

读取：FLD-004, FLD-020, FIELD-PHONE, FLD-054, FLD-011, FLD-010, FIELD-DELETION-SELECTION, FIELD-DELETION-FEEDBACK；写入：FLD-054, FLD-011, FLD-010, FLD-020, FIELD-DELETION-SELECTION, FIELD-DELETION-FEEDBACK, FIELD-REVIEW-REASON, FIELD-DELIVERY-STATE

规则：GR-007, GR-015

### LOCAL-009-S04

明确成功仅标该供应商目标，保留原本地record/batch/root/request/file映射并按来源交付状态

读取：FLD-010, FLD-011, FLD-013, FLD-020, FLD-054；写入：FLD-054, FIELD-DELETION-FEEDBACK, FIELD-REVIEW-REASON, FIELD-DELIVERY-STATE

规则：GR-007, GR-017, GR-019

## 分支与异常

### LOCAL-009-B01

条件：映射缺失、多候选、越界或实际返回未知

结果：拒绝或待核，不能显示已删除，不承诺撤销已执行呼叫

涉及字段：FLD-003, FLD-004, FLD-020, FIELD-PHONE, FLD-054

验证：CHECK-016, CHECK-025

### LOCAL-009-B02

条件：精准目标明确成功

结果：只标该目标已删，主删不删子、子删不删主，不清业务历史

涉及字段：FLD-010, FLD-011, FLD-013, FLD-054, FIELD-DELETION-FEEDBACK, FIELD-REVIEW-REASON, FIELD-DELIVERY-STATE

验证：CHECK-016, CHECK-024, CHECK-025, CHECK-052

### LOCAL-009-B03

条件：切换目标/样例但未执行新操作

结果：当前反馈为空，旧目标已保存证据仍可查

涉及字段：FLD-011, FLD-010, FLD-020, FIELD-DELETION-SELECTION, FIELD-DELETION-FEEDBACK, FLD-054, FIELD-REVIEW-REASON, FIELD-DELIVERY-STATE

验证：CHECK-061

## 完成后的状态

- 只在明确成功时标本目标供应商已删除；所有必要本地记录/关联保留，其他同号主子不受影响

## 字段定义

- [FIELD-DELETION-FEEDBACK](../field-specs.md#FIELD-DELETION-FEEDBACK)
- [FIELD-DELETION-SELECTION](../field-specs.md#FIELD-DELETION-SELECTION)
- [FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)
- [FIELD-PHONE](../field-specs.md#FIELD-PHONE)
- [FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)
- [FLD-003](../field-specs.md#FLD-003)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-006](../field-specs.md#FLD-006)
- [FLD-008](../field-specs.md#FLD-008)
- [FLD-010](../field-specs.md#FLD-010)
- [FLD-011](../field-specs.md#FLD-011)
- [FLD-013](../field-specs.md#FLD-013)
- [FLD-020](../field-specs.md#FLD-020)
- [FLD-054](../field-specs.md#FLD-054)

## 来源与验证

来源条目：acceptance:AC-016, acceptance:AC-024, acceptance:AC-025, acceptance:AC-052, acceptance:AC-061, features:FUNC-009, features:FUNC-009/boundary/business_rules/0, features:FUNC-009/boundary/business_rules/1, features:FUNC-009/boundary/exception_paths/0, features:FUNC-009/boundary/exception_paths/1, features:FUNC-009/boundary/exception_paths/2, interfaces:API-006, open_items:ISSUE-006, open_items:ISSUE-022, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-004, scenarios:SC-004/alternate_flows/0, scenarios:SC-004/alternate_flows/0/steps/0, scenarios:SC-004/alternate_flows/1, scenarios:SC-004/alternate_flows/1/steps/0, scenarios:SC-004/alternate_flows/2, scenarios:SC-004/alternate_flows/2/steps/0, scenarios:SC-004/alternate_flows/3, scenarios:SC-004/alternate_flows/3/steps/0, scenarios:SC-004/alternate_flows/4, scenarios:SC-004/alternate_flows/4/steps/0, scenarios:SC-004/alternate_flows/5, scenarios:SC-004/alternate_flows/5/steps/0, scenarios:SC-004/main_flow/0, scenarios:SC-004/main_flow/1, scenarios:SC-004/main_flow/2, scenarios:SC-004/main_flow/3, scenarios:SC-004/main_flow/4, scenarios:SC-004/main_flow/5, scenarios:SC-004/postconditions/0, scenarios:SC-004/postconditions/1, scenarios:SC-004/postconditions/2, scenarios:SC-004/postconditions/3, scenarios:SC-004/preconditions/0, scenarios:SC-004/preconditions/1, scenarios:SC-004/preconditions/2, sequences:SEQ-009, sequences:SEQ-009/messages/0, sequences:SEQ-009/messages/1, sequences:SEQ-009/messages/2, sequences:SEQ-009/messages/3, sequences:SEQ-009/messages/4, sequences:SEQ-009/messages/5, sequences:SEQ-009/messages/6, stories:US-004, stories:US-004/preconditions/0

验证：CHECK-016, CHECK-024, CHECK-025, CHECK-052, CHECK-061

## 实施任务

未声明；请结合范围说明核对。
