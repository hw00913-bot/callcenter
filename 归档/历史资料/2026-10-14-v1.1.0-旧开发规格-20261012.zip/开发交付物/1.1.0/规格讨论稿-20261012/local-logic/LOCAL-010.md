# LOCAL-010 按任务来源交付每次结果及补送

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [回传接口任务每次结果 · FUNC\-010](../features/FUNC-010.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-010

触发：可信且准确关联的导入失败、通话/无话单结果、秒挂、删除或同对象晚更新到达

## 前置条件

- 结果及原record/batch/root/file/call或稳定事件映射已确认；锁定来源可读

## 必须遵守的全局规则

- [GR-008](../global-logic.md#GR-008)
- [GR-012](../global-logic.md#GR-012)
- [GR-013](../global-logic.md#GR-013)
- [GR-015](../global-logic.md#GR-015)
- [GR-017](../global-logic.md#GR-017)
- [GR-018](../global-logic.md#GR-018)
- [GR-019](../global-logic.md#GR-019)

## 输入与输出

输入：[FLD-010](../field-specs.md#FLD-010)、[FLD-011](../field-specs.md#FLD-011)、[FLD-002](../field-specs.md#FLD-002)、[FLD-013](../field-specs.md#FLD-013)、[FLD-003](../field-specs.md#FLD-003)、[FLD-004](../field-specs.md#FLD-004)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-007](../field-specs.md#FLD-007)、[FIELD-BATCH-KIND](../field-specs.md#FIELD-BATCH-KIND)、[FLD-015](../field-specs.md#FLD-015)、[FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)、[FLD-020](../field-specs.md#FLD-020)、[FLD-046](../field-specs.md#FLD-046)、[FIELD-OCCURRED-AT](../field-specs.md#FIELD-OCCURRED-AT)、[FIELD-RESULT-STAGE](../field-specs.md#FIELD-RESULT-STAGE)、[FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)、[FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)、[FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)、[FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)、[FLD-066](../field-specs.md#FLD-066)、[FLD-051](../field-specs.md#FLD-051)、[FIELD-STATUS-DESC](../field-specs.md#FIELD-STATUS-DESC)、[FLD-047](../field-specs.md#FLD-047)、[FLD-049](../field-specs.md#FLD-049)、[FIELD-EVIDENCE-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)、[FLD-068](../field-specs.md#FLD-068)、[FLD-078](../field-specs.md#FLD-078)、[FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)、[FIELD-RESULT-VERSION](../field-specs.md#FIELD-RESULT-VERSION)、[FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)

输出：[FLD-046](../field-specs.md#FLD-046)、[FLD-011](../field-specs.md#FLD-011)、[FLD-002](../field-specs.md#FLD-002)、[FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)、[FLD-003](../field-specs.md#FLD-003)、[FLD-004](../field-specs.md#FLD-004)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FIELD-OCCURRED-AT](../field-specs.md#FIELD-OCCURRED-AT)、[FIELD-RESULT-STAGE](../field-specs.md#FIELD-RESULT-STAGE)、[FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)、[FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)、[FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)、[FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)、[FLD-013](../field-specs.md#FLD-013)、[FLD-010](../field-specs.md#FLD-010)、[FLD-066](../field-specs.md#FLD-066)、[FLD-051](../field-specs.md#FLD-051)、[FIELD-STATUS-DESC](../field-specs.md#FIELD-STATUS-DESC)、[FLD-047](../field-specs.md#FLD-047)、[FLD-049](../field-specs.md#FLD-049)、[FIELD-EVIDENCE-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)、[FLD-068](../field-specs.md#FLD-068)、[FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)、[FIELD-RESULT-VERSION](../field-specs.md#FIELD-RESULT-VERSION)、[FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)

## 处理步骤

### LOCAL-010-S01

从当前实际记录读取原request和行定位、tenant/原task/lead/phone及已存root；不按最近主或lead单键拼接

读取：FLD-010, FLD-011, FLD-002, FLD-013, FLD-003, FLD-004, FLD-008, FIELD-PHONE, FLD-007, FIELD-BATCH-KIND, FLD-015, FIELD-ROW-ID, FLD-020, FLD-066；写入：FLD-011, FLD-002, FIELD-ROW-ID, FLD-003, FLD-004, FLD-008, FIELD-PHONE, FLD-013, FLD-010, FLD-066

规则：GR-012, GR-017

### LOCAL-010-S02

保留本次阶段、原原因、话单/SIP及finishRetryFlag三态；同对象晚更新作为相应交付版本

读取：FLD-046, FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP, FLD-066, FLD-051, FIELD-STATUS-DESC, FLD-047, FLD-049, FIELD-EVIDENCE-SOURCE；写入：FLD-046, FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP, FLD-051, FIELD-STATUS-DESC, FLD-047, FLD-049, FIELD-EVIDENCE-SOURCE

规则：GR-008, GR-015, GR-017, GR-018

### LOCAL-010-S03

按锁来源分流：接口每次交付后台固定DCC，手工仅平台查看；不提供前台接收端或发真实回调

读取：FLD-078, FLD-046, FLD-011, FLD-002, FIELD-ROW-ID, FLD-003, FLD-004, FLD-008, FIELD-PHONE, FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP, FLD-013, FLD-010, FLD-066, FLD-051, FIELD-STATUS-DESC, FLD-047, FLD-049, FIELD-EVIDENCE-SOURCE；写入：FLD-068, FIELD-DELIVERY-STATE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON

规则：GR-017

### LOCAL-010-S04

保存交付结果；失败补送原准确对象版本，不再执行导入/删除或形成新通话

读取：FLD-068, FIELD-DELIVERY-STATE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON；写入：FLD-068, FIELD-DELIVERY-STATE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON

规则：GR-013, GR-015, GR-017, GR-019

## 分支与异常

### LOCAL-010-B01

条件：接口来源且可信精确关联

结果：每次结果及晚更新都可交付，不仅最后一次

涉及字段：FLD-078, FLD-046, FLD-066, FIELD-DELIVERY-STATE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON

验证：CHECK-018, CHECK-037, CHECK-038

### LOCAL-010-B02

条件：手工来源

结果：只保留平台结果查看，不添加DCC请求/归组协议

涉及字段：FLD-078, FIELD-DELIVERY-STATE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON

验证：CHECK-037, CHECK-052

### LOCAL-010-B03

条件：交付失败或确认未知

结果：显示待补送/待核，补送不重做供应商导入或增加实际呼叫

涉及字段：FLD-068, FIELD-DELIVERY-STATE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON

验证：CHECK-035, CHECK-041, CHECK-043, CHECK-052

### LOCAL-010-B04

条件：finishRetryFlag为1、0或未知

结果：分别表达本次供应商最后一条/非最后/未知，不宣整个任务或DCC计划完成

涉及字段：FLD-046

验证：CHECK-038

## 完成后的状态

- 接口来源每次结果固定后台DCC目的地交付，手工仅查看；交付失败可观察及补送，不重导或重算实际呼叫

## 字段定义

- [FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)
- [FIELD-BATCH-KIND](../field-specs.md#FIELD-BATCH-KIND)
- [FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)
- [FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)
- [FIELD-EVIDENCE-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)
- [FIELD-OCCURRED-AT](../field-specs.md#FIELD-OCCURRED-AT)
- [FIELD-PHONE](../field-specs.md#FIELD-PHONE)
- [FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)
- [FIELD-RESULT-STAGE](../field-specs.md#FIELD-RESULT-STAGE)
- [FIELD-RESULT-VERSION](../field-specs.md#FIELD-RESULT-VERSION)
- [FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)
- [FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)
- [FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)
- [FIELD-STATUS-DESC](../field-specs.md#FIELD-STATUS-DESC)
- [FLD-002](../field-specs.md#FLD-002)
- [FLD-003](../field-specs.md#FLD-003)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-007](../field-specs.md#FLD-007)
- [FLD-008](../field-specs.md#FLD-008)
- [FLD-010](../field-specs.md#FLD-010)
- [FLD-011](../field-specs.md#FLD-011)
- [FLD-013](../field-specs.md#FLD-013)
- [FLD-015](../field-specs.md#FLD-015)
- [FLD-020](../field-specs.md#FLD-020)
- [FLD-046](../field-specs.md#FLD-046)
- [FLD-047](../field-specs.md#FLD-047)
- [FLD-049](../field-specs.md#FLD-049)
- [FLD-051](../field-specs.md#FLD-051)
- [FLD-066](../field-specs.md#FLD-066)
- [FLD-068](../field-specs.md#FLD-068)
- [FLD-078](../field-specs.md#FLD-078)

## 来源与验证

来源条目：acceptance:AC-002, acceptance:AC-018, acceptance:AC-023, acceptance:AC-026, acceptance:AC-027, acceptance:AC-035, acceptance:AC-037, acceptance:AC-038, acceptance:AC-039, acceptance:AC-040, acceptance:AC-041, acceptance:AC-042, acceptance:AC-043, acceptance:AC-052, acceptance:AC-062, features:FUNC-010, features:FUNC-010/boundary/business_rules/0, features:FUNC-010/boundary/business_rules/1, features:FUNC-010/boundary/business_rules/2, features:FUNC-010/boundary/business_rules/3, features:FUNC-010/boundary/business_rules/4, features:FUNC-010/boundary/exception_paths/0, features:FUNC-010/boundary/exception_paths/1, features:FUNC-010/boundary/exception_paths/2, interfaces:API-003, interfaces:API-004, interfaces:API-006, interfaces:API-010, open_items:ISSUE-005, open_items:ISSUE-006, open_items:ISSUE-022, open_items:ISSUE-023, open_items:ISSUE-025, open_items:ISSUE-026, open_items:ISSUE-027, open_items:ISSUE-030, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-002, scenarios:SC-002/alternate_flows/0, scenarios:SC-002/alternate_flows/0/steps/0, scenarios:SC-002/alternate_flows/1, scenarios:SC-002/alternate_flows/1/steps/0, scenarios:SC-002/alternate_flows/2, scenarios:SC-002/alternate_flows/2/steps/0, scenarios:SC-002/alternate_flows/3, scenarios:SC-002/alternate_flows/3/steps/0, scenarios:SC-002/alternate_flows/4, scenarios:SC-002/alternate_flows/4/steps/0, scenarios:SC-002/alternate_flows/5, scenarios:SC-002/alternate_flows/5/steps/0, scenarios:SC-002/main_flow/0, scenarios:SC-002/main_flow/1, scenarios:SC-002/main_flow/2, scenarios:SC-002/main_flow/3, scenarios:SC-002/main_flow/4, scenarios:SC-002/main_flow/5, scenarios:SC-002/postconditions/0, scenarios:SC-002/postconditions/1, scenarios:SC-002/postconditions/2, scenarios:SC-002/postconditions/3, scenarios:SC-002/preconditions/0, scenarios:SC-002/preconditions/1, scenarios:SC-002/preconditions/2, scenarios:SC-003, scenarios:SC-003/alternate_flows/0, scenarios:SC-003/alternate_flows/0/steps/0, scenarios:SC-003/alternate_flows/1, scenarios:SC-003/alternate_flows/1/steps/0, scenarios:SC-003/alternate_flows/2, scenarios:SC-003/alternate_flows/2/steps/0, scenarios:SC-003/alternate_flows/3, scenarios:SC-003/alternate_flows/3/steps/0, scenarios:SC-003/alternate_flows/4, scenarios:SC-003/alternate_flows/4/steps/0, scenarios:SC-003/alternate_flows/5, scenarios:SC-003/alternate_flows/5/steps/0, scenarios:SC-003/main_flow/0, scenarios:SC-003/main_flow/1, scenarios:SC-003/main_flow/2, scenarios:SC-003/main_flow/3, scenarios:SC-003/main_flow/4, scenarios:SC-003/main_flow/5, scenarios:SC-003/postconditions/0, scenarios:SC-003/postconditions/1, scenarios:SC-003/postconditions/2, scenarios:SC-003/postconditions/3, scenarios:SC-003/preconditions/0, scenarios:SC-003/preconditions/1, scenarios:SC-003/preconditions/2, scenarios:SC-004, scenarios:SC-004/alternate_flows/0, scenarios:SC-004/alternate_flows/0/steps/0, scenarios:SC-004/alternate_flows/1, scenarios:SC-004/alternate_flows/1/steps/0, scenarios:SC-004/alternate_flows/2, scenarios:SC-004/alternate_flows/2/steps/0, scenarios:SC-004/alternate_flows/3, scenarios:SC-004/alternate_flows/3/steps/0, scenarios:SC-004/alternate_flows/4, scenarios:SC-004/alternate_flows/4/steps/0, scenarios:SC-004/alternate_flows/5, scenarios:SC-004/alternate_flows/5/steps/0, scenarios:SC-004/main_flow/0, scenarios:SC-004/main_flow/1, scenarios:SC-004/main_flow/2, scenarios:SC-004/main_flow/3, scenarios:SC-004/main_flow/4, scenarios:SC-004/main_flow/5, scenarios:SC-004/postconditions/0, scenarios:SC-004/postconditions/1, scenarios:SC-004/postconditions/2, scenarios:SC-004/postconditions/3, scenarios:SC-004/preconditions/0, scenarios:SC-004/preconditions/1, scenarios:SC-004/preconditions/2, sequences:SEQ-002, sequences:SEQ-002/messages/0, sequences:SEQ-002/messages/1, sequences:SEQ-002/messages/2, sequences:SEQ-002/messages/3, sequences:SEQ-002/messages/4, sequences:SEQ-002/messages/5, sequences:SEQ-002/messages/6, sequences:SEQ-002/messages/7, sequences:SEQ-003, sequences:SEQ-003/messages/0, sequences:SEQ-003/messages/1, sequences:SEQ-003/messages/2, sequences:SEQ-003/messages/3, sequences:SEQ-003/messages/4, sequences:SEQ-003/messages/5, sequences:SEQ-003/messages/6, sequences:SEQ-003/messages/7, sequences:SEQ-004, sequences:SEQ-004/messages/0, sequences:SEQ-004/messages/1, sequences:SEQ-004/messages/2, sequences:SEQ-004/messages/3, sequences:SEQ-004/messages/4, sequences:SEQ-004/messages/5, sequences:SEQ-004/messages/6, sequences:SEQ-004/messages/7, sequences:SEQ-009, sequences:SEQ-009/messages/0, sequences:SEQ-009/messages/1, sequences:SEQ-009/messages/2, sequences:SEQ-009/messages/3, sequences:SEQ-009/messages/4, sequences:SEQ-009/messages/5, sequences:SEQ-009/messages/6, stories:US-002, stories:US-002/preconditions/0, stories:US-003, stories:US-003/preconditions/0, stories:US-004, stories:US-004/preconditions/0

验证：CHECK-002, CHECK-018, CHECK-023, CHECK-026, CHECK-027, CHECK-035, CHECK-037, CHECK-038, CHECK-039, CHECK-040, CHECK-041, CHECK-042, CHECK-043, CHECK-052, CHECK-062

## 实施任务

未声明；请结合范围说明核对。
