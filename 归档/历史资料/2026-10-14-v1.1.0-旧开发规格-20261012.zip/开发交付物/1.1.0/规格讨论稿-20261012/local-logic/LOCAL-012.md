# LOCAL-012 独立记录无话单失败原因

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [记录无话单失败原因 · FUNC\-012](../features/FUNC-012.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-012

触发：可信且稳定关联的预测呼叫失败事件到达

## 前置条件

- 失败事件来源与原批次关联可确认；无需等待callID或话单

## 必须遵守的全局规则

- [GR-009](../global-logic.md#GR-009)
- [GR-012](../global-logic.md#GR-012)
- [GR-013](../global-logic.md#GR-013)
- [GR-015](../global-logic.md#GR-015)
- [GR-017](../global-logic.md#GR-017)

## 输入与输出

输入：[FLD-020](../field-specs.md#FLD-020)、[FIELD-EVENT-TYPE](../field-specs.md#FIELD-EVENT-TYPE)、[FIELD-EVENT-PAYLOAD](../field-specs.md#FIELD-EVENT-PAYLOAD)、[FIELD-OCCURRED-AT](../field-specs.md#FIELD-OCCURRED-AT)、[FIELD-RESULT-STAGE](../field-specs.md#FIELD-RESULT-STAGE)、[FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)、[FLD-066](../field-specs.md#FLD-066)、[FLD-078](../field-specs.md#FLD-078)

输出：[FIELD-OCCURRED-AT](../field-specs.md#FIELD-OCCURRED-AT)、[FIELD-RESULT-STAGE](../field-specs.md#FIELD-RESULT-STAGE)、[FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)、[FLD-066](../field-specs.md#FLD-066)、[FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)、[FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)、[FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)

## 处理步骤

### LOCAL-012-S01

核对稳定事件及精确原批次映射，保留无话单失败原始原因

读取：FLD-020, FIELD-EVENT-TYPE, FIELD-EVENT-PAYLOAD, FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FLD-066；写入：FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FLD-066

规则：GR-009, GR-012, GR-015

### LOCAL-012-S02

形成独立结果，callID可无，不伪造话单或默认finishRetryFlag

读取：FIELD-EVENT-TYPE, FIELD-EVENT-PAYLOAD, FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FLD-066；写入：FIELD-RESULT-REASON, FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP

规则：GR-009, GR-017

### LOCAL-012-S03

按来源交LOCAL-010，不绕过禁呼/限呼、不做平台恢复和重导预算

读取：FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FLD-066, FLD-078；写入：无

规则：GR-009, GR-013, GR-017

## 分支与异常

### LOCAL-012-B01

条件：禁呼未解禁、限呼未到期或无可用中继且原因可信

结果：按真实原因保存并回传，不等话单

涉及字段：FIELD-EVENT-TYPE, FIELD-EVENT-PAYLOAD, FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FLD-066

验证：CHECK-003, CHECK-020, CHECK-033

### LOCAL-012-B02

条件：事件缺稳定关联或原因未核实

结果：保留原证据待核，不造callID/话单或最后一通

涉及字段：FIELD-EVENT-TYPE, FIELD-EVENT-PAYLOAD, FIELD-OCCURRED-AT, FIELD-RESULT-STAGE, FIELD-RESULT-REASON, FLD-066

验证：CHECK-003, CHECK-033

## 完成后的状态

- 独立保留本次原始原因及事件标识；接口回传、手工查看，由DCC决定恢复与重导

## 字段定义

- [FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)
- [FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)
- [FIELD-EVENT-PAYLOAD](../field-specs.md#FIELD-EVENT-PAYLOAD)
- [FIELD-EVENT-TYPE](../field-specs.md#FIELD-EVENT-TYPE)
- [FIELD-OCCURRED-AT](../field-specs.md#FIELD-OCCURRED-AT)
- [FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)
- [FIELD-RESULT-STAGE](../field-specs.md#FIELD-RESULT-STAGE)
- [FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)
- [FLD-020](../field-specs.md#FLD-020)
- [FLD-066](../field-specs.md#FLD-066)
- [FLD-078](../field-specs.md#FLD-078)

## 来源与验证

来源条目：acceptance:AC-003, acceptance:AC-020, acceptance:AC-033, features:FUNC-012, features:FUNC-012/boundary/business_rules/0, features:FUNC-012/boundary/business_rules/1, features:FUNC-012/boundary/exception_paths/0, features:FUNC-012/boundary/exception_paths/1, interfaces:API-003, interfaces:API-010, open_items:ISSUE-006, open_items:ISSUE-023, open_items:ISSUE-026, open_items:ISSUE-027, open_items:ISSUE-030, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-003, scenarios:SC-003/alternate_flows/0, scenarios:SC-003/alternate_flows/0/steps/0, scenarios:SC-003/alternate_flows/1, scenarios:SC-003/alternate_flows/1/steps/0, scenarios:SC-003/alternate_flows/2, scenarios:SC-003/alternate_flows/2/steps/0, scenarios:SC-003/alternate_flows/3, scenarios:SC-003/alternate_flows/3/steps/0, scenarios:SC-003/alternate_flows/4, scenarios:SC-003/alternate_flows/4/steps/0, scenarios:SC-003/alternate_flows/5, scenarios:SC-003/alternate_flows/5/steps/0, scenarios:SC-003/main_flow/0, scenarios:SC-003/main_flow/1, scenarios:SC-003/main_flow/2, scenarios:SC-003/main_flow/3, scenarios:SC-003/main_flow/4, scenarios:SC-003/main_flow/5, scenarios:SC-003/postconditions/0, scenarios:SC-003/postconditions/1, scenarios:SC-003/postconditions/2, scenarios:SC-003/postconditions/3, scenarios:SC-003/preconditions/0, scenarios:SC-003/preconditions/1, scenarios:SC-003/preconditions/2, sequences:SEQ-003, sequences:SEQ-003/messages/0, sequences:SEQ-003/messages/1, sequences:SEQ-003/messages/2, sequences:SEQ-003/messages/3, sequences:SEQ-003/messages/4, sequences:SEQ-003/messages/5, sequences:SEQ-003/messages/6, sequences:SEQ-003/messages/7, stories:US-003, stories:US-003/preconditions/0

验证：CHECK-003, CHECK-020, CHECK-033

## 实施任务

未声明；请结合范围说明核对。
