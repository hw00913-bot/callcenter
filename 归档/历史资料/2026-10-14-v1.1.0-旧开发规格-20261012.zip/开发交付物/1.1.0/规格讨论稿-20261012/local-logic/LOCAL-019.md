# LOCAL-019 创建应用并提供接入凭证

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [创建应用 · FUNC\-019](../features/FUNC-019.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-019

触发：超管从应用列表进入新增并提交名称和授权业务租户

## 前置条件

- 当前管理权限有效；名称与授权租户满足已明确必填要求

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-020](../global-logic.md#GR-020)

## 输入与输出

输入：[FLD-089](../field-specs.md#FLD-089)、[FLD-090](../field-specs.md#FLD-090)

输出：[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-093](../field-specs.md#FLD-093)、[FLD-089](../field-specs.md#FLD-089)

## 处理步骤

### LOCAL-019-S01

输入应用名称和可访问业务租户，提交前核验权限与必填

读取：FLD-089, FLD-090；写入：无

规则：GR-001, GR-020

### LOCAL-019-S02

保存成功后形成独立应用及演示appId/secret，进入该应用详情

读取：FLD-089, FLD-090；写入：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED, FLD-093, FLD-089

规则：GR-001, GR-020

## 分支与异常

### LOCAL-019-B01

条件：有效保存成功

结果：展示已保存对象及必要合成凭证提示；用途为获取授权租户token

涉及字段：FIELD-APP-ID, FLD-093, FLD-089, FLD-090

验证：CHECK-017, CHECK-055, CHECK-058

### LOCAL-019-B02

条件：取消、无权、缺必填或保存失败

结果：不生成虚假已保存应用/凭证，明确反馈

涉及字段：FLD-089, FLD-090

验证：CHECK-044, CHECK-055

## 完成后的状态

- 有效保存生成一个独立应用及不可用合成appId/密钥，成功后列表和详情可见

## 字段定义

- [FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)
- [FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)
- [FLD-089](../field-specs.md#FLD-089)
- [FLD-090](../field-specs.md#FLD-090)
- [FLD-093](../field-specs.md#FLD-093)

## 来源与验证

来源条目：acceptance:AC-017, acceptance:AC-044, acceptance:AC-045, acceptance:AC-055, acceptance:AC-058, features:FUNC-019, features:FUNC-019/boundary/business_rules/0, features:FUNC-019/boundary/business_rules/1, features:FUNC-019/boundary/exception_paths/0, features:FUNC-019/boundary/exception_paths/1, features:FUNC-019/boundary/exception_paths/2, interfaces:API-001, open_items:ISSUE-002, open_items:ISSUE-022, open_items:ISSUE-031, pages:PAGE-001, pages:PAGE-001/actions/0, pages:PAGE-001/actions/1, pages:PAGE-001/actions/2, pages:PAGE-001/actions/3, pages:PAGE-001/actions/4, pages:PAGE-003, pages:PAGE-003/actions/0, scenarios:SC-005, scenarios:SC-005/alternate_flows/0, scenarios:SC-005/alternate_flows/0/steps/0, scenarios:SC-005/alternate_flows/1, scenarios:SC-005/alternate_flows/1/steps/0, scenarios:SC-005/alternate_flows/2, scenarios:SC-005/alternate_flows/2/steps/0, scenarios:SC-005/alternate_flows/3, scenarios:SC-005/alternate_flows/3/steps/0, scenarios:SC-005/alternate_flows/4, scenarios:SC-005/alternate_flows/4/steps/0, scenarios:SC-005/main_flow/0, scenarios:SC-005/main_flow/1, scenarios:SC-005/main_flow/2, scenarios:SC-005/main_flow/3, scenarios:SC-005/main_flow/4, scenarios:SC-005/postconditions/0, scenarios:SC-005/postconditions/1, scenarios:SC-005/postconditions/2, scenarios:SC-005/preconditions/0, scenarios:SC-005/preconditions/1, scenarios:SC-005/preconditions/2, sequences:SEQ-005, sequences:SEQ-005/messages/0, sequences:SEQ-005/messages/1, sequences:SEQ-005/messages/10, sequences:SEQ-005/messages/11, sequences:SEQ-005/messages/12, sequences:SEQ-005/messages/13, sequences:SEQ-005/messages/14, sequences:SEQ-005/messages/2, sequences:SEQ-005/messages/3, sequences:SEQ-005/messages/4, sequences:SEQ-005/messages/5, sequences:SEQ-005/messages/6, sequences:SEQ-005/messages/7, sequences:SEQ-005/messages/8, sequences:SEQ-005/messages/9

验证：CHECK-017, CHECK-044, CHECK-045, CHECK-055, CHECK-058

## 实施任务

未声明；请结合范围说明核对。
