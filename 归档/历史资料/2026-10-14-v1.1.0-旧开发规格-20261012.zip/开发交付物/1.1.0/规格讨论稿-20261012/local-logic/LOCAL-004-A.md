# LOCAL-004-A 预览并提交手工线索

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [接收预外呼线索 · FUNC\-004](../features/FUNC-004.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-004

触发：用户从已锁手工来源任务的常驻导入客户入口粘贴/读取CSV、预览并提交

## 前置条件

- 沿既有权限/任务可导入状态核验；不授予DCC任务手工导入能力

## 必须遵守的全局规则

- [GR-002](../global-logic.md#GR-002)
- [GR-003](../global-logic.md#GR-003)
- [GR-004](../global-logic.md#GR-004)
- [GR-006](../global-logic.md#GR-006)
- [GR-014](../global-logic.md#GR-014)
- [GR-016](../global-logic.md#GR-016)

## 输入与输出

输入：[FLD-001](../field-specs.md#FLD-001)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-009](../field-specs.md#FLD-009)、[FLD-004](../field-specs.md#FLD-004)、[FLD-003](../field-specs.md#FLD-003)、[FLD-078](../field-specs.md#FLD-078)、[FIELD-CSV-TEXT](../field-specs.md#FIELD-CSV-TEXT)、[FIELD-CSV-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)

输出：[FLD-010](../field-specs.md#FLD-010)、[FLD-011](../field-specs.md#FLD-011)、[FLD-015](../field-specs.md#FLD-015)、[FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)、[FIELD-ORIGINAL-IMPORT-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)、[FIELD-RECEIVED-AT](../field-specs.md#FIELD-RECEIVED-AT)、[FIELD-BATCH-CREATED-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)、[FLD-009](../field-specs.md#FLD-009)、[FLD-001](../field-specs.md#FLD-001)、[FIELD-CSV-TEXT](../field-specs.md#FIELD-CSV-TEXT)、[FIELD-CSV-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)

## 处理步骤

### LOCAL-004-A-S01

按锁来源、当前身份及历史任务可补导状态核验入口；不可操作仍显示入口及原因

读取：FLD-004, FLD-003, FLD-078；写入：无

规则：GR-014, GR-016

### LOCAL-004-A-S02

解析当前CSV预览；文本变化或新预览失败立即使旧稿不可提交

读取：FIELD-CSV-TEXT, FIELD-CSV-PREVIEW, FLD-009；写入：FIELD-CSV-TEXT, FIELD-CSV-PREVIEW, FLD-009

规则：GR-014

### LOCAL-004-A-S03

统一priority后允许逐行覆盖，仅作用当前有效预览，提交前复核文本和身份未变化

读取：FLD-009, FIELD-CSV-TEXT, FIELD-CSV-PREVIEW；写入：FIELD-CSV-TEXT, FIELD-CSV-PREVIEW, FLD-009

规则：GR-003, GR-014

### LOCAL-004-A-S04

逐行校验leadCode/phone/最终priority和可选R；有效行新record/单号batch保存审计时间后自动提交

读取：FLD-001, FLD-008, FIELD-PHONE, FLD-009, FIELD-CSV-TEXT, FIELD-CSV-PREVIEW；写入：FLD-010, FLD-011, FLD-015, FIELD-ROW-ID, FIELD-ORIGINAL-IMPORT-AT, FIELD-RECEIVED-AT, FIELD-BATCH-CREATED-AT, FLD-009, FLD-001

规则：GR-002, GR-003, GR-004, GR-006, GR-014

## 分支与异常

### LOCAL-004-A-B01

条件：无有效当前预览、文本已变、预览失败或提交前身份/任务状态变化

结果：拒绝提交旧草稿并提示重新预览或无权限原因

涉及字段：FLD-004, FLD-003, FLD-078, FIELD-CSV-TEXT, FIELD-CSV-PREVIEW, FLD-009

验证：CHECK-059, CHECK-060

### LOCAL-004-A-B02

条件：手工来源当前任务允许导入且预览有效

结果：有效行逐行保存；失败行进入失败下载，不要求DCCrequest/flag/root输入

涉及字段：FLD-001, FLD-008, FIELD-PHONE, FLD-009, FLD-010, FLD-011, FIELD-CSV-TEXT, FIELD-CSV-PREVIEW

验证：CHECK-030, CHECK-031

### LOCAL-004-A-B03

条件：任务锁定DCC来源或已启动历史任务不符合原补导规则

结果：不能以常驻按钮绕过来源或状态守卫

涉及字段：FLD-004, FLD-003, FLD-078

验证：CHECK-029, CHECK-059

## 完成后的状态

- 仅当前文本的有效预览可提交；有效行独立记录/单号批次，以提交前最终priority自动提交

## 字段定义

- [FIELD-BATCH-CREATED-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)
- [FIELD-CSV-PREVIEW](../field-specs.md#FIELD-CSV-PREVIEW)
- [FIELD-CSV-TEXT](../field-specs.md#FIELD-CSV-TEXT)
- [FIELD-ORIGINAL-IMPORT-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)
- [FIELD-PHONE](../field-specs.md#FIELD-PHONE)
- [FIELD-RECEIVED-AT](../field-specs.md#FIELD-RECEIVED-AT)
- [FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)
- [FLD-001](../field-specs.md#FLD-001)
- [FLD-003](../field-specs.md#FLD-003)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-008](../field-specs.md#FLD-008)
- [FLD-009](../field-specs.md#FLD-009)
- [FLD-010](../field-specs.md#FLD-010)
- [FLD-011](../field-specs.md#FLD-011)
- [FLD-015](../field-specs.md#FLD-015)
- [FLD-078](../field-specs.md#FLD-078)

## 来源与验证

来源条目：acceptance:AC-001, acceptance:AC-005, acceptance:AC-007, acceptance:AC-014, acceptance:AC-015, acceptance:AC-029, acceptance:AC-030, acceptance:AC-031, acceptance:AC-032, acceptance:AC-059, acceptance:AC-060, features:FUNC-004, features:FUNC-004/boundary/business_rules/0, features:FUNC-004/boundary/business_rules/1, features:FUNC-004/boundary/business_rules/2, features:FUNC-004/boundary/business_rules/3, features:FUNC-004/boundary/business_rules/4, features:FUNC-004/boundary/business_rules/5, features:FUNC-004/boundary/business_rules/6, features:FUNC-004/boundary/business_rules/7, features:FUNC-004/boundary/business_rules/8, features:FUNC-004/boundary/business_rules/9, features:FUNC-004/boundary/exception_paths/0, features:FUNC-004/boundary/exception_paths/1, features:FUNC-004/boundary/exception_paths/2, features:FUNC-004/boundary/exception_paths/3, features:FUNC-004/boundary/exception_paths/4, features:FUNC-004/boundary/exception_paths/5, interfaces:API-001, interfaces:API-002, open_items:ISSUE-002, open_items:ISSUE-008, open_items:ISSUE-022, open_items:ISSUE-023, open_items:ISSUE-025, open_items:ISSUE-027, open_items:ISSUE-028, open_items:ISSUE-029, open_items:ISSUE-031, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, sequences:SEQ-001, sequences:SEQ-001/messages/0, sequences:SEQ-001/messages/1, sequences:SEQ-001/messages/10, sequences:SEQ-001/messages/11, sequences:SEQ-001/messages/12, sequences:SEQ-001/messages/13, sequences:SEQ-001/messages/14, sequences:SEQ-001/messages/2, sequences:SEQ-001/messages/3, sequences:SEQ-001/messages/4, sequences:SEQ-001/messages/5, sequences:SEQ-001/messages/6, sequences:SEQ-001/messages/7, sequences:SEQ-001/messages/8, sequences:SEQ-001/messages/9, sequences:SEQ-006, sequences:SEQ-006/messages/0, sequences:SEQ-006/messages/1, sequences:SEQ-006/messages/2, sequences:SEQ-006/messages/3, sequences:SEQ-006/messages/4, sequences:SEQ-006/messages/5, sequences:SEQ-006/messages/6, sequences:SEQ-006/messages/7, sequences:SEQ-006/messages/8, stories:US-001

验证：CHECK-001, CHECK-005, CHECK-007, CHECK-014, CHECK-015, CHECK-029, CHECK-030, CHECK-031, CHECK-032, CHECK-059, CHECK-060

## 实施任务

未声明；请结合范围说明核对。
