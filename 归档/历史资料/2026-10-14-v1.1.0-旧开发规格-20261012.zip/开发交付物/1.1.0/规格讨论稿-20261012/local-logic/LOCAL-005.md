# LOCAL-005 自动提交当前单号批次并登记同步证据

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [自动提交导入批次 · FUNC\-005](../features/FUNC-005.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-005

触发：新的有效本地单手机号业务记录保存完成

## 前置条件

- 是本次尚未提交记录，非请求重放；原任务和来源有效

## 必须遵守的全局规则

- [GR-002](../global-logic.md#GR-002)
- [GR-003](../global-logic.md#GR-003)
- [GR-004](../global-logic.md#GR-004)
- [GR-006](../global-logic.md#GR-006)
- [GR-012](../global-logic.md#GR-012)
- [GR-015](../global-logic.md#GR-015)
- [GR-018](../global-logic.md#GR-018)
- [GR-021](../global-logic.md#GR-021)

## 输入与输出

输入：[FLD-004](../field-specs.md#FLD-004)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-009](../field-specs.md#FLD-009)、[FLD-010](../field-specs.md#FLD-010)、[FLD-011](../field-specs.md#FLD-011)、[FLD-013](../field-specs.md#FLD-013)、[FLD-020](../field-specs.md#FLD-020)、[FLD-021](../field-specs.md#FLD-021)、[FLD-022](../field-specs.md#FLD-022)、[FLD-023](../field-specs.md#FLD-023)、[FLD-025](../field-specs.md#FLD-025)、[FLD-026](../field-specs.md#FLD-026)、[FIELD-ORIGINAL-IMPORT-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)、[FIELD-RECEIVED-AT](../field-specs.md#FIELD-RECEIVED-AT)、[FIELD-BATCH-CREATED-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)、[FLD-001](../field-specs.md#FLD-001)、[FIELD-RECEIVED-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)、[FIELD-SUBMISSION-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)

输出：[FLD-004](../field-specs.md#FLD-004)、[FLD-009](../field-specs.md#FLD-009)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-020](../field-specs.md#FLD-020)、[FLD-021](../field-specs.md#FLD-021)、[FLD-022](../field-specs.md#FLD-022)、[FLD-023](../field-specs.md#FLD-023)、[FLD-025](../field-specs.md#FLD-025)、[FLD-026](../field-specs.md#FLD-026)、[FIELD-EVIDENCE-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)、[FIELD-RECEIVED-AT](../field-specs.md#FIELD-RECEIVED-AT)、[FIELD-RECEIVED-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)、[FIELD-SUBMISSION-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)、[FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)

## 处理步骤

### LOCAL-005-S01

同任务按本次priority高先、同级本地接收时间FIFO选择待提交记录；不同任务独立

读取：FLD-004, FLD-009, FIELD-ORIGINAL-IMPORT-AT, FIELD-RECEIVED-AT, FIELD-BATCH-CREATED-AT, FLD-001, FIELD-RECEIVED-SEQUENCE, FIELD-SUBMISSION-STATE；写入：无

规则：GR-003, GR-006, GR-021

### LOCAL-005-S02

原supplierTaskId直接用于供应商任务；每次仅提交本批手机号和本次priority，不拿root作fileId、不追加旧fileId、不擅改排重配置

读取：FLD-004, FLD-008, FIELD-PHONE, FLD-009, FLD-010, FLD-011, FLD-013, FLD-020；写入：FIELD-SUBMISSION-STATE

规则：GR-002, GR-004, GR-012, GR-021

### LOCAL-005-S03

保存该实际记录返回fileId与taskId及result/description/数量原始证据，原本地记录保留

读取：FLD-010, FLD-011, FLD-020, FLD-021, FLD-022, FLD-023, FLD-004, FLD-025, FLD-026；写入：FLD-020, FLD-021, FLD-022, FLD-023, FLD-004, FLD-025, FLD-026, FIELD-EVIDENCE-SOURCE

规则：GR-004, GR-018

### LOCAL-005-S04

按准确逐条证据登记成功或明确失败；只有汇总或矛盾时不盲定每行，未知暂停待核

读取：FLD-020, FLD-021, FLD-022, FLD-023, FLD-004, FLD-025, FLD-026；写入：FIELD-SUBMISSION-STATE, FIELD-REVIEW-REASON

规则：GR-004, GR-015, GR-018

## 分支与异常

### LOCAL-005-B01

条件：已提交或提交结果未知

结果：不为重排、技术重传自动再提交；保留证据待核

涉及字段：FLD-010, FLD-020, FIELD-SUBMISSION-STATE, FIELD-REVIEW-REASON

验证：CHECK-035, CHECK-046, CHECK-050

### LOCAL-005-B02

条件：有准确对应成功证据

结果：正常记录该行供应商成功，并保留映射；不直接增加实际呼叫

涉及字段：FLD-020, FLD-021, FLD-022, FLD-023, FLD-026, FIELD-SUBMISSION-STATE, FIELD-REVIEW-REASON

验证：CHECK-011, CHECK-039

### LOCAL-005-B03

条件：供应商明确拒绝

结果：保留本地记录与原原因，进入导入失败导出及来源交付

涉及字段：FLD-025, FLD-026, FIELD-SUBMISSION-STATE, FIELD-REVIEW-REASON

验证：CHECK-013, CHECK-041

### LOCAL-005-B04

条件：仅汇总或数量/任务/file关联矛盾、超时

结果：显示未知/待核，不能以result=0推全成功或以无推送推零失败

涉及字段：FLD-020, FLD-021, FLD-022, FLD-023, FLD-004, FLD-026, FIELD-SUBMISSION-STATE, FIELD-REVIEW-REASON

验证：CHECK-035, CHECK-039, CHECK-043

## 完成后的状态

- 逐批保存实际供应商fileId映射及原同步证据；明确接受/拒绝/未知分开，接受不等于呼叫

## 字段定义

- [FIELD-BATCH-CREATED-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)
- [FIELD-EVIDENCE-SOURCE](../field-specs.md#FIELD-EVIDENCE-SOURCE)
- [FIELD-ORIGINAL-IMPORT-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)
- [FIELD-PHONE](../field-specs.md#FIELD-PHONE)
- [FIELD-RECEIVED-AT](../field-specs.md#FIELD-RECEIVED-AT)
- [FIELD-RECEIVED-SEQUENCE](../field-specs.md#FIELD-RECEIVED-SEQUENCE)
- [FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)
- [FIELD-SUBMISSION-STATE](../field-specs.md#FIELD-SUBMISSION-STATE)
- [FLD-001](../field-specs.md#FLD-001)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-008](../field-specs.md#FLD-008)
- [FLD-009](../field-specs.md#FLD-009)
- [FLD-010](../field-specs.md#FLD-010)
- [FLD-011](../field-specs.md#FLD-011)
- [FLD-013](../field-specs.md#FLD-013)
- [FLD-020](../field-specs.md#FLD-020)
- [FLD-021](../field-specs.md#FLD-021)
- [FLD-022](../field-specs.md#FLD-022)
- [FLD-023](../field-specs.md#FLD-023)
- [FLD-025](../field-specs.md#FLD-025)
- [FLD-026](../field-specs.md#FLD-026)

## 来源与验证

来源条目：acceptance:AC-011, acceptance:AC-012, acceptance:AC-013, acceptance:AC-014, acceptance:AC-015, acceptance:AC-019, acceptance:AC-032, acceptance:AC-035, acceptance:AC-039, acceptance:AC-041, acceptance:AC-043, acceptance:AC-046, acceptance:AC-049, acceptance:AC-050, acceptance:AC-051, features:FUNC-005, features:FUNC-005/boundary/business_rules/0, features:FUNC-005/boundary/business_rules/1, features:FUNC-005/boundary/business_rules/10, features:FUNC-005/boundary/business_rules/11, features:FUNC-005/boundary/business_rules/2, features:FUNC-005/boundary/business_rules/3, features:FUNC-005/boundary/business_rules/4, features:FUNC-005/boundary/business_rules/5, features:FUNC-005/boundary/business_rules/6, features:FUNC-005/boundary/business_rules/7, features:FUNC-005/boundary/business_rules/8, features:FUNC-005/boundary/business_rules/9, features:FUNC-005/boundary/exception_paths/0, features:FUNC-005/boundary/exception_paths/1, features:FUNC-005/boundary/exception_paths/2, interfaces:API-002, open_items:ISSUE-002, open_items:ISSUE-023, open_items:ISSUE-025, open_items:ISSUE-027, open_items:ISSUE-028, open_items:ISSUE-029, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, sequences:SEQ-001, sequences:SEQ-001/messages/0, sequences:SEQ-001/messages/1, sequences:SEQ-001/messages/10, sequences:SEQ-001/messages/11, sequences:SEQ-001/messages/12, sequences:SEQ-001/messages/13, sequences:SEQ-001/messages/14, sequences:SEQ-001/messages/2, sequences:SEQ-001/messages/3, sequences:SEQ-001/messages/4, sequences:SEQ-001/messages/5, sequences:SEQ-001/messages/6, sequences:SEQ-001/messages/7, sequences:SEQ-001/messages/8, sequences:SEQ-001/messages/9, sequences:SEQ-006, sequences:SEQ-006/messages/0, sequences:SEQ-006/messages/1, sequences:SEQ-006/messages/2, sequences:SEQ-006/messages/3, sequences:SEQ-006/messages/4, sequences:SEQ-006/messages/5, sequences:SEQ-006/messages/6, sequences:SEQ-006/messages/7, sequences:SEQ-006/messages/8, stories:US-001

验证：CHECK-011, CHECK-012, CHECK-013, CHECK-014, CHECK-015, CHECK-019, CHECK-032, CHECK-035, CHECK-039, CHECK-041, CHECK-043, CHECK-046, CHECK-049, CHECK-050, CHECK-051

## 实施任务

未声明；请结合范围说明核对。
