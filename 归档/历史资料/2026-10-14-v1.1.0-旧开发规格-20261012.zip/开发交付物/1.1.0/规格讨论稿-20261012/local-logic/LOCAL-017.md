# LOCAL-017 接收并合并53异步导入失败分片

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [接收并关联异步导入失败 · FUNC\-017](../features/FUNC-017.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-017

触发：AliCti 53导入号码失败分片到达

## 前置条件

- 保留原始事件与enterprise映射证据；未核来源或关联不明不能确认业务失败

## 必须遵守的全局规则

- [GR-012](../global-logic.md#GR-012)
- [GR-013](../global-logic.md#GR-013)
- [GR-015](../global-logic.md#GR-015)
- [GR-017](../global-logic.md#GR-017)
- [GR-018](../global-logic.md#GR-018)
- [GR-019](../global-logic.md#GR-019)

## 输入与输出

输入：[FLD-020](../field-specs.md#FLD-020)、[FLD-027](../field-specs.md#FLD-027)、[FLD-028](../field-specs.md#FLD-028)、[FLD-029](../field-specs.md#FLD-029)、[FLD-030](../field-specs.md#FLD-030)、[FLD-031](../field-specs.md#FLD-031)、[FLD-033](../field-specs.md#FLD-033)、[FLD-004](../field-specs.md#FLD-004)、[FLD-035](../field-specs.md#FLD-035)、[FLD-036](../field-specs.md#FLD-036)、[FIELD-EVENT-TYPE](../field-specs.md#FIELD-EVENT-TYPE)、[FIELD-EVENT-PAYLOAD](../field-specs.md#FIELD-EVENT-PAYLOAD)、[FIELD-DEDUP-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)、[FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)、[FIELD-FRAGMENT-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)

输出：[FLD-030](../field-specs.md#FLD-030)、[FIELD-EXPORT-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)、[FLD-020](../field-specs.md#FLD-020)、[FLD-028](../field-specs.md#FLD-028)、[FLD-035](../field-specs.md#FLD-035)、[FIELD-FRAGMENT-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)、[FIELD-DEDUP-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)、[FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)、[FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)

## 处理步骤

### LOCAL-017-S01

保存原始53事件、企业/任务/file、失败原始号码与原因，以及声明分片数/片号/总失败数

读取：FLD-027, FLD-028, FLD-029, FLD-030, FLD-031, FLD-020, FLD-033, FLD-004, FLD-035, FLD-036, FIELD-EVENT-TYPE, FIELD-EVENT-PAYLOAD；写入：FLD-020, FLD-028, FLD-035, FIELD-FRAGMENT-COMPLETENESS

规则：GR-018

### LOCAL-017-S02

用经核实enterprise到tenant、原task、精确fileId与原始号码回查实际记录；不按lead或最近同号

读取：FLD-020, FLD-029, FLD-031, FLD-004；写入：FLD-030, FIELD-EXPORT-SNAPSHOT, FIELD-DELIVERY-STATE, FIELD-REVIEW-REASON

规则：GR-012, GR-015, GR-018

### LOCAL-017-S03

合并可信失败及已知分片状态；重复不再新增，迟到新失败保留，矛盾待核

读取：FLD-028, FLD-030, FLD-035, FLD-036, FLD-020, FIELD-FRAGMENT-COMPLETENESS, FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE；写入：FLD-030, FIELD-EXPORT-SNAPSHOT, FLD-020, FLD-028, FLD-035, FIELD-FRAGMENT-COMPLETENESS, FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-REVIEW-REASON

规则：GR-015, GR-018, GR-019

### LOCAL-017-S04

接口失败交LOCAL-010、手工只查看；导入失败不计呼叫，供LOCAL-006按快照导出

读取：FLD-030, FIELD-EXPORT-SNAPSHOT, FLD-020, FLD-028, FLD-035, FIELD-FRAGMENT-COMPLETENESS；写入：FIELD-DELIVERY-STATE, FIELD-REVIEW-REASON

规则：GR-013, GR-017, GR-018, GR-019

## 分支与异常

### LOCAL-017-B01

条件：精确唯一关联且未见过该失败事件

结果：保存本次导入失败原因为独立明细并按来源处理

涉及字段：FLD-020, FLD-030, FLD-031, FLD-004, FIELD-EXPORT-SNAPSHOT

验证：CHECK-040, CHECK-041

### LOCAL-017-B02

条件：重复、乱序或成功下载后迟到

结果：重复不新增且已导出旧事件不再生；新失败进入下次快照

涉及字段：FLD-028, FLD-035, FLD-030, FIELD-EXPORT-SNAPSHOT, FLD-020, FIELD-FRAGMENT-COMPLETENESS, FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE

验证：CHECK-040, CHECK-042, CHECK-043

### LOCAL-017-B03

条件：企业映射/候选/分片声明/结果矛盾

结果：保留原证据待核，不任指某行、不推零失败或全导入终态

涉及字段：FLD-029, FLD-031, FLD-020, FLD-004, FLD-035, FLD-036, FLD-028, FIELD-FRAGMENT-COMPLETENESS, FIELD-DELIVERY-STATE, FIELD-REVIEW-REASON

验证：CHECK-039, CHECK-040, CHECK-043

## 完成后的状态

- 可信失败准确落实际本次batch，重复去重、乱序迟到不丢；片齐不等全导入终态

## 字段定义

- [FIELD-DEDUP-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)
- [FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)
- [FIELD-EVENT-PAYLOAD](../field-specs.md#FIELD-EVENT-PAYLOAD)
- [FIELD-EVENT-TYPE](../field-specs.md#FIELD-EVENT-TYPE)
- [FIELD-EXPORT-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)
- [FIELD-FRAGMENT-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)
- [FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-020](../field-specs.md#FLD-020)
- [FLD-027](../field-specs.md#FLD-027)
- [FLD-028](../field-specs.md#FLD-028)
- [FLD-029](../field-specs.md#FLD-029)
- [FLD-030](../field-specs.md#FLD-030)
- [FLD-031](../field-specs.md#FLD-031)
- [FLD-033](../field-specs.md#FLD-033)
- [FLD-035](../field-specs.md#FLD-035)
- [FLD-036](../field-specs.md#FLD-036)

## 来源与验证

来源条目：acceptance:AC-039, acceptance:AC-040, acceptance:AC-041, acceptance:AC-042, acceptance:AC-043, features:FUNC-017, features:FUNC-017/boundary/business_rules/0, features:FUNC-017/boundary/business_rules/1, features:FUNC-017/boundary/exception_paths/0, features:FUNC-017/boundary/exception_paths/1, interfaces:API-003, interfaces:API-010, open_items:ISSUE-006, open_items:ISSUE-023, open_items:ISSUE-026, open_items:ISSUE-027, open_items:ISSUE-030, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, sequences:SEQ-001, sequences:SEQ-001/messages/0, sequences:SEQ-001/messages/1, sequences:SEQ-001/messages/10, sequences:SEQ-001/messages/11, sequences:SEQ-001/messages/12, sequences:SEQ-001/messages/13, sequences:SEQ-001/messages/14, sequences:SEQ-001/messages/2, sequences:SEQ-001/messages/3, sequences:SEQ-001/messages/4, sequences:SEQ-001/messages/5, sequences:SEQ-001/messages/6, sequences:SEQ-001/messages/7, sequences:SEQ-001/messages/8, sequences:SEQ-001/messages/9, sequences:SEQ-007, sequences:SEQ-007/messages/0, sequences:SEQ-007/messages/1, sequences:SEQ-007/messages/2, sequences:SEQ-007/messages/3, sequences:SEQ-007/messages/4, sequences:SEQ-007/messages/5, sequences:SEQ-007/messages/6, sequences:SEQ-007/messages/7, stories:US-001

验证：CHECK-039, CHECK-040, CHECK-041, CHECK-042, CHECK-043

## 实施任务

未声明；请结合范围说明核对。
