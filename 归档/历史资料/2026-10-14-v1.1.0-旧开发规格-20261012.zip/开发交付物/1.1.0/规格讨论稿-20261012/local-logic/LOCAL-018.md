# LOCAL-018 查询应用列表

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [查询应用列表 · FUNC\-018](../features/FUNC-018.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-018

触发：超管进入应用接入或提交名称/appId筛选与分页

## 前置条件

- 每次读取确认应用管理权限

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-020](../global-logic.md#GR-020)

## 输入与输出

输入：[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-070](../field-specs.md#FLD-070)、[FLD-071](../field-specs.md#FLD-071)、[FIELD-APP-PAGE](../field-specs.md#FIELD-APP-PAGE)

输出：[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-071](../field-specs.md#FLD-071)、[FIELD-APP-PAGE](../field-specs.md#FIELD-APP-PAGE)

## 处理步骤

### LOCAL-018-S01

校验当前超管管理权限后读取应用名称/appId/创建时间

读取：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED；写入：无

规则：GR-001, GR-020

### LOCAL-018-S02

应用查询条件及分页，返回匹配对象和操作入口

读取：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED, FLD-070, FLD-071, FIELD-APP-PAGE；写入：无

规则：GR-020

## 分支与异常

### LOCAL-018-B01

条件：有匹配应用

结果：只读显示当前应用及详情/修改/删除入口，可发起新增

涉及字段：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED, FLD-070, FLD-071, FIELD-APP-PAGE

验证：CHECK-053

### LOCAL-018-B02

条件：无应用或无匹配

结果：显示空态与新增入口，不伪造应用

涉及字段：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED, FLD-070, FLD-071, FIELD-APP-PAGE

验证：CHECK-053

### LOCAL-018-B03

条件：非超管菜单、直达或管理调用

结果：拒绝读取管理列表且无写入

涉及字段：FLD-090, FIELD-APP-ID, FIELD-APP-CREATED

验证：CHECK-044, CHECK-053

## 完成后的状态

- 返回相应列表或明确空结果；读取不创建、修改或删除应用

## 字段定义

- [FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)
- [FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)
- [FIELD-APP-PAGE](../field-specs.md#FIELD-APP-PAGE)
- [FLD-070](../field-specs.md#FLD-070)
- [FLD-071](../field-specs.md#FLD-071)
- [FLD-090](../field-specs.md#FLD-090)

## 来源与验证

来源条目：acceptance:AC-028, acceptance:AC-044, acceptance:AC-045, acceptance:AC-053, acceptance:AC-058, features:FUNC-018, features:FUNC-018/boundary/business_rules/0, features:FUNC-018/boundary/business_rules/1, features:FUNC-018/boundary/exception_paths/0, features:FUNC-018/boundary/exception_paths/1, features:FUNC-018/boundary/exception_paths/2, interfaces:API-001, open_items:ISSUE-002, open_items:ISSUE-022, open_items:ISSUE-031, pages:PAGE-001, pages:PAGE-001/actions/0, pages:PAGE-001/actions/1, pages:PAGE-001/actions/2, pages:PAGE-001/actions/3, pages:PAGE-001/actions/4, scenarios:SC-005, scenarios:SC-005/alternate_flows/0, scenarios:SC-005/alternate_flows/0/steps/0, scenarios:SC-005/alternate_flows/1, scenarios:SC-005/alternate_flows/1/steps/0, scenarios:SC-005/alternate_flows/2, scenarios:SC-005/alternate_flows/2/steps/0, scenarios:SC-005/alternate_flows/3, scenarios:SC-005/alternate_flows/3/steps/0, scenarios:SC-005/alternate_flows/4, scenarios:SC-005/alternate_flows/4/steps/0, scenarios:SC-005/main_flow/0, scenarios:SC-005/main_flow/1, scenarios:SC-005/main_flow/2, scenarios:SC-005/main_flow/3, scenarios:SC-005/main_flow/4, scenarios:SC-005/postconditions/0, scenarios:SC-005/postconditions/1, scenarios:SC-005/postconditions/2, scenarios:SC-005/preconditions/0, scenarios:SC-005/preconditions/1, scenarios:SC-005/preconditions/2, sequences:SEQ-005, sequences:SEQ-005/messages/0, sequences:SEQ-005/messages/1, sequences:SEQ-005/messages/10, sequences:SEQ-005/messages/11, sequences:SEQ-005/messages/12, sequences:SEQ-005/messages/13, sequences:SEQ-005/messages/14, sequences:SEQ-005/messages/2, sequences:SEQ-005/messages/3, sequences:SEQ-005/messages/4, sequences:SEQ-005/messages/5, sequences:SEQ-005/messages/6, sequences:SEQ-005/messages/7, sequences:SEQ-005/messages/8, sequences:SEQ-005/messages/9

验证：CHECK-028, CHECK-044, CHECK-045, CHECK-053, CHECK-058

## 实施任务

未声明；请结合范围说明核对。
