# LOCAL-004-B 核验DCC身份与请求级幂等

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [接收预外呼线索 · FUNC\-004](../features/FUNC-004.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-004

触发：锁定DCC来源任务接到requestId及逐行导入内容

## 前置条件

- 租户业务身份已解析；task归属和锁定DCC来源需本次再次核验

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-002](../global-logic.md#GR-002)
- [GR-003](../global-logic.md#GR-003)
- [GR-004](../global-logic.md#GR-004)
- [GR-012](../global-logic.md#GR-012)
- [GR-015](../global-logic.md#GR-015)
- [GR-016](../global-logic.md#GR-016)

## 输入与输出

输入：[FLD-001](../field-specs.md#FLD-001)、[FLD-002](../field-specs.md#FLD-002)、[FLD-003](../field-specs.md#FLD-003)、[FLD-004](../field-specs.md#FLD-004)、[FLD-006](../field-specs.md#FLD-006)、[FLD-007](../field-specs.md#FLD-007)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-009](../field-specs.md#FLD-009)、[FLD-015](../field-specs.md#FLD-015)、[FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)、[FLD-078](../field-specs.md#FLD-078)

输出：[FLD-007](../field-specs.md#FLD-007)、[FLD-002](../field-specs.md#FLD-002)、[FLD-015](../field-specs.md#FLD-015)、[FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)

## 处理步骤

### LOCAL-004-B-S01

校验当前租户身份、原供应商任务归属及来源

读取：FLD-003, FLD-004, FLD-006, FLD-078；写入：无

规则：GR-001, GR-016

### LOCAL-004-B-S02

仅将缺省isNewBatch归一false；保留完整行数/定位/已给R/priority等有效业务内容

读取：FLD-001, FLD-002, FLD-007, FLD-008, FIELD-PHONE, FLD-009；写入：FLD-007

规则：GR-002, GR-003, GR-012, GR-015

### LOCAL-004-B-S03

按requestId比较已保存的完整请求内容及逐行结果，重复不重新分配主子

读取：FLD-001, FLD-002, FLD-003, FLD-004, FLD-007, FLD-008, FIELD-PHONE, FLD-009, FLD-015, FIELD-ROW-ID；写入：FLD-002, FLD-015, FIELD-ROW-ID

规则：GR-002, GR-004, GR-012, GR-015

## 分支与异常

### LOCAL-004-B-B01

条件：身份、来源或原任务归属不满足

结果：拒绝本请求，不创建或提交记录

涉及字段：FLD-003, FLD-004, FLD-006, FLD-078

验证：CHECK-012, CHECK-029, CHECK-036

### LOCAL-004-B-B02

条件：同requestId且归一后完整内容相同

结果：返回原成功/失败/待核逐行结果及原record/batch/root，后来新主不改变原映射

涉及字段：FLD-002, FLD-007, FLD-010, FLD-011, FLD-013, FLD-015, FIELD-ROW-ID

验证：CHECK-050

### LOCAL-004-B-B03

条件：同requestId但完整内容不同

结果：拒绝整个重复请求且不覆盖原结果，不为任一行新建或提交

涉及字段：FLD-001, FLD-002, FLD-007, FLD-008, FIELD-PHONE, FLD-009, FLD-015, FIELD-ROW-ID

验证：CHECK-051

### LOCAL-004-B-B04

条件：新requestId

结果：交LOCAL-004逐行校验；具体技术key/规范化/原子性/保留期仍待工程设计

涉及字段：FLD-002, FLD-007, FLD-015, FIELD-ROW-ID

验证：CHECK-047, CHECK-050

## 完成后的状态

- 同ID同内容返原逐行映射；同ID异内容整个重复请求拒绝；仅新request进入逐行归组

## 字段定义

- [FIELD-PHONE](../field-specs.md#FIELD-PHONE)
- [FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)
- [FLD-001](../field-specs.md#FLD-001)
- [FLD-002](../field-specs.md#FLD-002)
- [FLD-003](../field-specs.md#FLD-003)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-006](../field-specs.md#FLD-006)
- [FLD-007](../field-specs.md#FLD-007)
- [FLD-008](../field-specs.md#FLD-008)
- [FLD-009](../field-specs.md#FLD-009)
- [FLD-010](../field-specs.md#FLD-010)
- [FLD-011](../field-specs.md#FLD-011)
- [FLD-013](../field-specs.md#FLD-013)
- [FLD-015](../field-specs.md#FLD-015)
- [FLD-078](../field-specs.md#FLD-078)

## 来源与验证

来源条目：acceptance:AC-006, acceptance:AC-010, acceptance:AC-012, acceptance:AC-019, acceptance:AC-029, acceptance:AC-036, acceptance:AC-047, acceptance:AC-050, acceptance:AC-051, acceptance:AC-052, features:FUNC-004, features:FUNC-004/boundary/business_rules/0, features:FUNC-004/boundary/business_rules/1, features:FUNC-004/boundary/business_rules/2, features:FUNC-004/boundary/business_rules/3, features:FUNC-004/boundary/business_rules/4, features:FUNC-004/boundary/business_rules/5, features:FUNC-004/boundary/business_rules/6, features:FUNC-004/boundary/business_rules/7, features:FUNC-004/boundary/business_rules/8, features:FUNC-004/boundary/business_rules/9, features:FUNC-004/boundary/exception_paths/0, features:FUNC-004/boundary/exception_paths/1, features:FUNC-004/boundary/exception_paths/2, features:FUNC-004/boundary/exception_paths/3, features:FUNC-004/boundary/exception_paths/4, features:FUNC-004/boundary/exception_paths/5, interfaces:API-001, interfaces:API-002, open_items:ISSUE-002, open_items:ISSUE-008, open_items:ISSUE-022, open_items:ISSUE-023, open_items:ISSUE-025, open_items:ISSUE-027, open_items:ISSUE-028, open_items:ISSUE-029, open_items:ISSUE-031, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, sequences:SEQ-001, sequences:SEQ-001/messages/0, sequences:SEQ-001/messages/1, sequences:SEQ-001/messages/10, sequences:SEQ-001/messages/11, sequences:SEQ-001/messages/12, sequences:SEQ-001/messages/13, sequences:SEQ-001/messages/14, sequences:SEQ-001/messages/2, sequences:SEQ-001/messages/3, sequences:SEQ-001/messages/4, sequences:SEQ-001/messages/5, sequences:SEQ-001/messages/6, sequences:SEQ-001/messages/7, sequences:SEQ-001/messages/8, sequences:SEQ-001/messages/9, sequences:SEQ-006, sequences:SEQ-006/messages/0, sequences:SEQ-006/messages/1, sequences:SEQ-006/messages/2, sequences:SEQ-006/messages/3, sequences:SEQ-006/messages/4, sequences:SEQ-006/messages/5, sequences:SEQ-006/messages/6, sequences:SEQ-006/messages/7, sequences:SEQ-006/messages/8, stories:US-001

验证：CHECK-006, CHECK-010, CHECK-012, CHECK-019, CHECK-029, CHECK-036, CHECK-047, CHECK-050, CHECK-051, CHECK-052

## 实施任务

未声明；请结合范围说明核对。
