# LOCAL-020 查看指定应用详情与密钥

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [查看应用详情 · FUNC\-020](../features/FUNC-020.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-020

触发：超管选定应用查看详情或从保存成功页进入详情

## 前置条件

- 当前超管权限有效，精确目标仍存在

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-020](../global-logic.md#GR-020)

## 输入与输出

输入：[FLD-089](../field-specs.md#FLD-089)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FLD-093](../field-specs.md#FLD-093)

输出：[FLD-089](../field-specs.md#FLD-089)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FLD-093](../field-specs.md#FLD-093)

## 处理步骤

### LOCAL-020-S01

根据当前目标读取应用及权限，不存在或已删时明确反馈

读取：FLD-089, FIELD-APP-CREATED, FLD-090, FIELD-APP-ID, FLD-093；写入：无

规则：GR-001, GR-020

### LOCAL-020-S02

默认掩码显示演示密钥，按需显示/复制并保留不可用提示

读取：FLD-093；写入：无

规则：GR-020

### LOCAL-020-S03

显示该应用名称、appId、授权租户与创建时间，可返回列表

读取：FLD-089, FIELD-APP-CREATED, FLD-090, FIELD-APP-ID；写入：无

规则：GR-020

## 分支与异常

### LOCAL-020-B01

条件：目标有效且权限满足

结果：展示当前目标；查看/复制不保存或重置凭证

涉及字段：FLD-089, FIELD-APP-CREATED, FLD-090, FIELD-APP-ID, FLD-093

验证：CHECK-054, CHECK-058

### LOCAL-020-B02

条件：无权、目标不存在或已删除

结果：拒绝或显示不存在，不用其他应用替代详情

涉及字段：FLD-089, FIELD-APP-CREATED, FLD-090, FIELD-APP-ID, FLD-093

验证：CHECK-044, CHECK-054

## 完成后的状态

- 只读显示目标名称/appId/密钥/授权租户/创建时间；显示复制不改变凭据或授权

## 字段定义

- [FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)
- [FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)
- [FLD-089](../field-specs.md#FLD-089)
- [FLD-090](../field-specs.md#FLD-090)
- [FLD-093](../field-specs.md#FLD-093)

## 来源与验证

来源条目：acceptance:AC-017, acceptance:AC-044, acceptance:AC-045, acceptance:AC-054, acceptance:AC-058, features:FUNC-020, features:FUNC-020/boundary/business_rules/0, features:FUNC-020/boundary/business_rules/1, features:FUNC-020/boundary/exception_paths/0, features:FUNC-020/boundary/exception_paths/1, features:FUNC-020/boundary/exception_paths/2, interfaces:API-001, open_items:ISSUE-002, open_items:ISSUE-022, open_items:ISSUE-031, pages:PAGE-001, pages:PAGE-001/actions/0, pages:PAGE-001/actions/1, pages:PAGE-001/actions/2, pages:PAGE-001/actions/3, pages:PAGE-001/actions/4, pages:PAGE-004, pages:PAGE-004/actions/0, pages:PAGE-004/actions/1, pages:PAGE-004/actions/2, scenarios:SC-005, scenarios:SC-005/alternate_flows/0, scenarios:SC-005/alternate_flows/0/steps/0, scenarios:SC-005/alternate_flows/1, scenarios:SC-005/alternate_flows/1/steps/0, scenarios:SC-005/alternate_flows/2, scenarios:SC-005/alternate_flows/2/steps/0, scenarios:SC-005/alternate_flows/3, scenarios:SC-005/alternate_flows/3/steps/0, scenarios:SC-005/alternate_flows/4, scenarios:SC-005/alternate_flows/4/steps/0, scenarios:SC-005/main_flow/0, scenarios:SC-005/main_flow/1, scenarios:SC-005/main_flow/2, scenarios:SC-005/main_flow/3, scenarios:SC-005/main_flow/4, scenarios:SC-005/postconditions/0, scenarios:SC-005/postconditions/1, scenarios:SC-005/postconditions/2, scenarios:SC-005/preconditions/0, scenarios:SC-005/preconditions/1, scenarios:SC-005/preconditions/2, sequences:SEQ-005, sequences:SEQ-005/messages/0, sequences:SEQ-005/messages/1, sequences:SEQ-005/messages/10, sequences:SEQ-005/messages/11, sequences:SEQ-005/messages/12, sequences:SEQ-005/messages/13, sequences:SEQ-005/messages/14, sequences:SEQ-005/messages/2, sequences:SEQ-005/messages/3, sequences:SEQ-005/messages/4, sequences:SEQ-005/messages/5, sequences:SEQ-005/messages/6, sequences:SEQ-005/messages/7, sequences:SEQ-005/messages/8, sequences:SEQ-005/messages/9

验证：CHECK-017, CHECK-044, CHECK-045, CHECK-054, CHECK-058

## 实施任务

未声明；请结合范围说明核对。
