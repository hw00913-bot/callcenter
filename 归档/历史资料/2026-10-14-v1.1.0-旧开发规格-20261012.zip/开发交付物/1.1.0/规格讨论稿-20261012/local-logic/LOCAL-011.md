# LOCAL-011 识别客户秒挂结果

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [识别客户秒挂结果 · FUNC\-011](../features/FUNC-011.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-011

触发：收到可精确关联且可信的客户接听与挂断结果

## 前置条件

- 实际记录及call或稳定事件关联已确认；客户真实接听语义可确认

## 必须遵守的全局规则

- [GR-010](../global-logic.md#GR-010)
- [GR-011](../global-logic.md#GR-011)
- [GR-013](../global-logic.md#GR-013)
- [GR-015](../global-logic.md#GR-015)
- [GR-017](../global-logic.md#GR-017)

## 输入与输出

输入：[FLD-043](../field-specs.md#FLD-043)、[FLD-045](../field-specs.md#FLD-045)、[FLD-048](../field-specs.md#FLD-048)、[FLD-051](../field-specs.md#FLD-051)、[FIELD-STATUS-DESC](../field-specs.md#FIELD-STATUS-DESC)、[FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)、[FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)、[FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)、[FLD-066](../field-specs.md#FLD-066)、[FLD-078](../field-specs.md#FLD-078)

输出：[FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)、[FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)、[FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)、[FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)

## 处理步骤

### LOCAL-011-S01

核实客户真实接通、客户主动挂断及客户实际接听时长来源；不拿坐席时长替代

读取：FLD-043, FLD-048, FLD-051, FIELD-STATUS-DESC, FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP, FLD-066；写入：无

规则：GR-010, GR-015

### LOCAL-011-S02

对可信时长0到2秒含端点识别秒挂并保存到实际call对象

读取：FLD-043, FLD-045, FLD-048, FLD-051, FIELD-STATUS-DESC, FLD-066；写入：FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP, FIELD-RESULT-REASON

规则：GR-010, GR-011

### LOCAL-011-S03

将识别结果交LOCAL-010按任务来源处理；无平台30分钟重导或额外额度

读取：FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP, FLD-066, FLD-078；写入：无

规则：GR-011, GR-013, GR-017

## 分支与异常

### LOCAL-011-B01

条件：真实接通、客户挂断且客户实际时长为0、1、2秒

结果：标记本次秒挂；真实0秒不能当缺失

涉及字段：FLD-043, FLD-048, FLD-051, FIELD-STATUS-DESC, FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP

验证：CHECK-021, CHECK-034

### LOCAL-011-B02

条件：未接通、时长null/异常或不是客户挂断

结果：不纳入秒挂；缺证据不伪造条件成立

涉及字段：FLD-043, FLD-048, FLD-051, FIELD-STATUS-DESC, FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP

验证：CHECK-021, CHECK-034

### LOCAL-011-B03

条件：已识别秒挂结果重复或时间经过30分钟

结果：保留原结果且不新增呼叫、重导计划或额外4次

涉及字段：FIELD-CUSTOMER-ANSWERED, FIELD-AGENT-ANSWERED, FIELD-SHORT-HANGUP, FLD-066

验证：CHECK-004, CHECK-022, CHECK-024

## 完成后的状态

- 仅真实客户接通且客户主动挂断、有效客户时长0～2秒识别秒挂，结果按来源交付/查看

## 字段定义

- [FIELD-AGENT-ANSWERED](../field-specs.md#FIELD-AGENT-ANSWERED)
- [FIELD-CUSTOMER-ANSWERED](../field-specs.md#FIELD-CUSTOMER-ANSWERED)
- [FIELD-RESULT-REASON](../field-specs.md#FIELD-RESULT-REASON)
- [FIELD-SHORT-HANGUP](../field-specs.md#FIELD-SHORT-HANGUP)
- [FIELD-STATUS-DESC](../field-specs.md#FIELD-STATUS-DESC)
- [FLD-043](../field-specs.md#FLD-043)
- [FLD-045](../field-specs.md#FLD-045)
- [FLD-048](../field-specs.md#FLD-048)
- [FLD-051](../field-specs.md#FLD-051)
- [FLD-066](../field-specs.md#FLD-066)
- [FLD-078](../field-specs.md#FLD-078)

## 来源与验证

来源条目：acceptance:AC-004, acceptance:AC-021, acceptance:AC-022, acceptance:AC-023, acceptance:AC-024, acceptance:AC-034, features:FUNC-011, features:FUNC-011/boundary/business_rules/0, features:FUNC-011/boundary/business_rules/1, features:FUNC-011/boundary/exception_paths/0, features:FUNC-011/boundary/exception_paths/1, interfaces:API-004, open_items:ISSUE-005, open_items:ISSUE-006, open_items:ISSUE-022, open_items:ISSUE-025, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-004, scenarios:SC-004/alternate_flows/0, scenarios:SC-004/alternate_flows/0/steps/0, scenarios:SC-004/alternate_flows/1, scenarios:SC-004/alternate_flows/1/steps/0, scenarios:SC-004/alternate_flows/2, scenarios:SC-004/alternate_flows/2/steps/0, scenarios:SC-004/alternate_flows/3, scenarios:SC-004/alternate_flows/3/steps/0, scenarios:SC-004/alternate_flows/4, scenarios:SC-004/alternate_flows/4/steps/0, scenarios:SC-004/alternate_flows/5, scenarios:SC-004/alternate_flows/5/steps/0, scenarios:SC-004/main_flow/0, scenarios:SC-004/main_flow/1, scenarios:SC-004/main_flow/2, scenarios:SC-004/main_flow/3, scenarios:SC-004/main_flow/4, scenarios:SC-004/main_flow/5, scenarios:SC-004/postconditions/0, scenarios:SC-004/postconditions/1, scenarios:SC-004/postconditions/2, scenarios:SC-004/postconditions/3, scenarios:SC-004/preconditions/0, scenarios:SC-004/preconditions/1, scenarios:SC-004/preconditions/2, sequences:SEQ-004, sequences:SEQ-004/messages/0, sequences:SEQ-004/messages/1, sequences:SEQ-004/messages/2, sequences:SEQ-004/messages/3, sequences:SEQ-004/messages/4, sequences:SEQ-004/messages/5, sequences:SEQ-004/messages/6, sequences:SEQ-004/messages/7, stories:US-004, stories:US-004/preconditions/0

验证：CHECK-004, CHECK-021, CHECK-022, CHECK-023, CHECK-024, CHECK-034

## 实施任务

未声明；请结合范围说明核对。
