# LOCAL-001 修改具体应用

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [修改应用 · FUNC\-001](../features/FUNC-001.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-001

触发：超管从列表或详情打开指定应用修改并提交

## 前置条件

- 当前身份具备应用管理权限；目标应用存在

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-020](../global-logic.md#GR-020)

## 输入与输出

输入：[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-093](../field-specs.md#FLD-093)、[FLD-089](../field-specs.md#FLD-089)、[FLD-090](../field-specs.md#FLD-090)

输出：[FLD-089](../field-specs.md#FLD-089)、[FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)、[FLD-090](../field-specs.md#FLD-090)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FLD-093](../field-specs.md#FLD-093)

## 处理步骤

### LOCAL-001-S01

读取目标及当前权限，加载原名称和授权租户

读取：FIELD-APP-ID, FIELD-APP-CREATED, FLD-093, FLD-089, FLD-090；写入：FLD-089, FLD-090

规则：GR-001, GR-020

### LOCAL-001-S02

提交时复核身份、目标及必填名称/授权；保存成功才应用变更

读取：FIELD-APP-ID, FIELD-APP-CREATED, FLD-093, FLD-089, FLD-090；写入：FLD-089, FIELD-APP-CREATED, FLD-090, FIELD-APP-ID

规则：GR-001, GR-020

### LOCAL-001-S03

成功后按当前租户授权解析已发合成业务身份；不自动重置密钥

读取：FLD-003, FLD-006, FIELD-APP-ID, FIELD-APP-CREATED, FLD-093, FLD-089；写入：FLD-006

规则：GR-001, GR-020

## 分支与异常

### LOCAL-001-B01

条件：取消、无权、目标不存在或保存失败

结果：明确反馈，原配置及原授权身份不先失效

涉及字段：FIELD-APP-ID, FIELD-APP-CREATED, FLD-093, FLD-089, FLD-090

验证：CHECK-044, CHECK-056

### LOCAL-001-B02

条件：保存成功移除部分租户授权

结果：被移除租户旧合成身份拒绝；仍授权租户和其他应用身份保持

涉及字段：FLD-003, FLD-006, FLD-089

验证：CHECK-056

## 完成后的状态

- 成功仅更新该应用名称/授权；普通修改保留appId和原密钥；取消/失败保留原配置

## 字段定义

- [FIELD-APP-CREATED](../field-specs.md#FIELD-APP-CREATED)
- [FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)
- [FLD-003](../field-specs.md#FLD-003)
- [FLD-006](../field-specs.md#FLD-006)
- [FLD-089](../field-specs.md#FLD-089)
- [FLD-090](../field-specs.md#FLD-090)
- [FLD-093](../field-specs.md#FLD-093)

## 来源与验证

来源条目：acceptance:AC-017, acceptance:AC-044, acceptance:AC-045, acceptance:AC-056, acceptance:AC-058, features:FUNC-001, features:FUNC-001/boundary/business_rules/0, features:FUNC-001/boundary/business_rules/1, features:FUNC-001/boundary/exception_paths/0, features:FUNC-001/boundary/exception_paths/1, features:FUNC-001/boundary/exception_paths/2, interfaces:API-001, open_items:ISSUE-002, open_items:ISSUE-022, open_items:ISSUE-031, pages:PAGE-001, pages:PAGE-001/actions/0, pages:PAGE-001/actions/1, pages:PAGE-001/actions/2, pages:PAGE-001/actions/3, pages:PAGE-001/actions/4, pages:PAGE-004, pages:PAGE-004/actions/0, pages:PAGE-004/actions/1, pages:PAGE-004/actions/2, pages:PAGE-005, pages:PAGE-005/actions/0, scenarios:SC-005, scenarios:SC-005/alternate_flows/0, scenarios:SC-005/alternate_flows/0/steps/0, scenarios:SC-005/alternate_flows/1, scenarios:SC-005/alternate_flows/1/steps/0, scenarios:SC-005/alternate_flows/2, scenarios:SC-005/alternate_flows/2/steps/0, scenarios:SC-005/alternate_flows/3, scenarios:SC-005/alternate_flows/3/steps/0, scenarios:SC-005/alternate_flows/4, scenarios:SC-005/alternate_flows/4/steps/0, scenarios:SC-005/main_flow/0, scenarios:SC-005/main_flow/1, scenarios:SC-005/main_flow/2, scenarios:SC-005/main_flow/3, scenarios:SC-005/main_flow/4, scenarios:SC-005/postconditions/0, scenarios:SC-005/postconditions/1, scenarios:SC-005/postconditions/2, scenarios:SC-005/preconditions/0, scenarios:SC-005/preconditions/1, scenarios:SC-005/preconditions/2, sequences:SEQ-005, sequences:SEQ-005/messages/0, sequences:SEQ-005/messages/1, sequences:SEQ-005/messages/10, sequences:SEQ-005/messages/11, sequences:SEQ-005/messages/12, sequences:SEQ-005/messages/13, sequences:SEQ-005/messages/14, sequences:SEQ-005/messages/2, sequences:SEQ-005/messages/3, sequences:SEQ-005/messages/4, sequences:SEQ-005/messages/5, sequences:SEQ-005/messages/6, sequences:SEQ-005/messages/7, sequences:SEQ-005/messages/8, sequences:SEQ-005/messages/9

验证：CHECK-017, CHECK-044, CHECK-045, CHECK-056, CHECK-058

## 实施任务

未声明；请结合范围说明核对。
