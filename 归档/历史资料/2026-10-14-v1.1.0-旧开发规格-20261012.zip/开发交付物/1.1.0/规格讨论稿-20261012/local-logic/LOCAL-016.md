# LOCAL-016 创建任务并锁定单一导入来源

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [创建任务并锁定导入方式 · FUNC\-016](../features/FUNC-016.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-016

触发：用户在创建任务时选择DCC接口或手工来源并确认提交

## 前置条件

- 沿原任务创建权限及供应商任务归属校验；任务属于租户而非应用

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-014](../global-logic.md#GR-014)
- [GR-016](../global-logic.md#GR-016)

## 输入与输出

输入：[FLD-003](../field-specs.md#FLD-003)、[FLD-004](../field-specs.md#FLD-004)、[FLD-078](../field-specs.md#FLD-078)

输出：[FLD-004](../field-specs.md#FLD-004)、[FLD-003](../field-specs.md#FLD-003)、[FLD-078](../field-specs.md#FLD-078)

## 处理步骤

### LOCAL-016-S01

创建确认前选择且仅选择一种来源，并核验tenant和原supplierTaskId

读取：FLD-003, FLD-004, FLD-078；写入：FLD-004, FLD-003, FLD-078

规则：GR-001, GR-016

### LOCAL-016-S02

成功创建时保存锁定来源及归属，任务不绑定应用

读取：FLD-003, FLD-004, FLD-078；写入：FLD-004, FLD-003, FLD-078

规则：GR-001, GR-016

### LOCAL-016-S03

后续页面与业务调用均复核锁来源/归属；历史任务补导只沿未启动等原条件且累计原名单批次

读取：FLD-004, FLD-003, FLD-078；写入：无

规则：GR-014, GR-016

## 分支与异常

### LOCAL-016-B01

条件：确认创建前合法选择DCC或手工

结果：保存对应单一来源，不自动额外授予权限

涉及字段：FLD-004, FLD-003, FLD-078

验证：CHECK-036

### LOCAL-016-B02

条件：提交后试图切换来源、归属或混入另一方式

结果：拒绝且保留原任务/名单；常驻入口不能绕过

涉及字段：FLD-004, FLD-003, FLD-078

验证：CHECK-029, CHECK-036, CHECK-059

## 完成后的状态

- 提交成功后租户、原供应商任务和来源锁定；既有名单/修改/导入入口不允许切换或混用

## 字段定义

- [FLD-003](../field-specs.md#FLD-003)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-078](../field-specs.md#FLD-078)

## 来源与验证

来源条目：acceptance:AC-029, acceptance:AC-036, acceptance:AC-059, features:FUNC-016, features:FUNC-016/boundary/business_rules/0, features:FUNC-016/boundary/exception_paths/0, features:FUNC-016/boundary/exception_paths/1, interfaces:API-002, open_items:ISSUE-002, open_items:ISSUE-023, open_items:ISSUE-025, open_items:ISSUE-027, open_items:ISSUE-028, open_items:ISSUE-029, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, sequences:SEQ-001, sequences:SEQ-006, sequences:SEQ-006/messages/0, sequences:SEQ-006/messages/1, sequences:SEQ-006/messages/2, sequences:SEQ-006/messages/3, sequences:SEQ-006/messages/4, sequences:SEQ-006/messages/5, sequences:SEQ-006/messages/6, sequences:SEQ-006/messages/7, sequences:SEQ-006/messages/8, stories:US-001

验证：CHECK-029, CHECK-036, CHECK-059

## 实施任务

未声明；请结合范围说明核对。
