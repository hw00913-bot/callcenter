# LOCAL-006 生成失败快照并按成功下载清理

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [下载导入失败记录 · FUNC\-006](../features/FUNC-006.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-006

触发：运营在任务失败记录入口下载本次失败明细

## 前置条件

- 沿原运营权限校验；已有本地校验或供应商明确导入失败

## 必须遵守的全局规则

- [GR-005](../global-logic.md#GR-005)
- [GR-018](../global-logic.md#GR-018)
- [GR-019](../global-logic.md#GR-019)

## 输入与输出

输入：[FLD-030](../field-specs.md#FLD-030)、[FIELD-EXPORT-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)、[FLD-020](../field-specs.md#FLD-020)、[FLD-028](../field-specs.md#FLD-028)、[FLD-035](../field-specs.md#FLD-035)、[FIELD-FRAGMENT-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)、[FIELD-DEDUP-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)、[FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)、[FIELD-DOWNLOAD-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)、[FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)

输出：[FLD-030](../field-specs.md#FLD-030)、[FIELD-EXPORT-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)、[FIELD-DEDUP-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)、[FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)、[FIELD-FRAGMENT-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)、[FIELD-DOWNLOAD-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)、[FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)

## 处理步骤

### LOCAL-006-S01

收集当前未导出失败，冻结本次明细及分片完整性说明，后到事件不加入旧快照

读取：FLD-030, FIELD-EXPORT-SNAPSHOT, FLD-020, FLD-028, FLD-035, FIELD-FRAGMENT-COMPLETENESS；写入：FLD-030, FIELD-EXPORT-SNAPSHOT

规则：GR-005, GR-018, GR-019

### LOCAL-006-S02

生成下载结果；生成、点击、开始均不视为成功下载

读取：FLD-030, FIELD-EXPORT-SNAPSHOT；写入：FIELD-DOWNLOAD-STATE, FIELD-REVIEW-REASON

规则：GR-005, GR-019

### LOCAL-006-S03

可信成功后只清快照覆盖明细及文件；保持客户/批次/root/file、请求回执、事件去重与交付状态

读取：FLD-030, FIELD-EXPORT-SNAPSHOT, FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-FRAGMENT-COMPLETENESS, FIELD-DOWNLOAD-STATE, FIELD-REVIEW-REASON；写入：FLD-030, FIELD-EXPORT-SNAPSHOT, FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-FRAGMENT-COMPLETENESS, FIELD-DOWNLOAD-STATE, FIELD-REVIEW-REASON

规则：GR-005, GR-019

## 分支与异常

### LOCAL-006-B01

条件：失败、中断或缺可信成功信号

结果：保留明细及文件，不设固定到期；真实下载信号待工程核实

涉及字段：FLD-030, FIELD-EXPORT-SNAPSHOT, FIELD-DOWNLOAD-STATE, FIELD-REVIEW-REASON

验证：CHECK-008, CHECK-042

### LOCAL-006-B02

条件：可信合成成功且有后到新失败

结果：只清本快照，后到新失败下次导出；已导出旧事件重复不再生

涉及字段：FLD-030, FIELD-EXPORT-SNAPSHOT, FLD-020, FLD-028, FLD-035, FIELD-FRAGMENT-COMPLETENESS, FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-DOWNLOAD-STATE, FIELD-REVIEW-REASON

验证：CHECK-008, CHECK-042, CHECK-043, CHECK-052

### LOCAL-006-B03

条件：分片未收齐或完整性未知

结果：快照明示不完整/待核，不能宣全导入终态

涉及字段：FLD-030, FIELD-EXPORT-SNAPSHOT, FLD-020, FLD-028, FLD-035, FIELD-FRAGMENT-COMPLETENESS

验证：CHECK-040, CHECK-042

## 完成后的状态

- 未成功下载持续保留；可信成功只清本快照明细/文件，必要业务和去重交付状态保留

## 字段定义

- [FIELD-DEDUP-EVIDENCE](../field-specs.md#FIELD-DEDUP-EVIDENCE)
- [FIELD-DELIVERY-STATE](../field-specs.md#FIELD-DELIVERY-STATE)
- [FIELD-DOWNLOAD-STATE](../field-specs.md#FIELD-DOWNLOAD-STATE)
- [FIELD-EXPORT-SNAPSHOT](../field-specs.md#FIELD-EXPORT-SNAPSHOT)
- [FIELD-FRAGMENT-COMPLETENESS](../field-specs.md#FIELD-FRAGMENT-COMPLETENESS)
- [FIELD-REVIEW-REASON](../field-specs.md#FIELD-REVIEW-REASON)
- [FLD-020](../field-specs.md#FLD-020)
- [FLD-028](../field-specs.md#FLD-028)
- [FLD-030](../field-specs.md#FLD-030)
- [FLD-035](../field-specs.md#FLD-035)

## 来源与验证

来源条目：acceptance:AC-008, acceptance:AC-013, acceptance:AC-029, acceptance:AC-031, acceptance:AC-039, acceptance:AC-040, acceptance:AC-041, acceptance:AC-042, acceptance:AC-043, acceptance:AC-052, features:FUNC-006, features:FUNC-006/boundary/business_rules/0, features:FUNC-006/boundary/business_rules/1, features:FUNC-006/boundary/business_rules/10, features:FUNC-006/boundary/business_rules/2, features:FUNC-006/boundary/business_rules/3, features:FUNC-006/boundary/business_rules/4, features:FUNC-006/boundary/business_rules/5, features:FUNC-006/boundary/business_rules/6, features:FUNC-006/boundary/business_rules/7, features:FUNC-006/boundary/business_rules/8, features:FUNC-006/boundary/business_rules/9, features:FUNC-006/boundary/exception_paths/0, features:FUNC-006/boundary/exception_paths/1, flows:FLOW-002, open_items:ISSUE-008, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, sequences:SEQ-007, sequences:SEQ-007/messages/0, sequences:SEQ-007/messages/1, sequences:SEQ-007/messages/2, sequences:SEQ-007/messages/3, sequences:SEQ-007/messages/4, sequences:SEQ-007/messages/5, sequences:SEQ-007/messages/6, sequences:SEQ-007/messages/7, stories:US-001

验证：CHECK-008, CHECK-013, CHECK-029, CHECK-031, CHECK-039, CHECK-040, CHECK-041, CHECK-042, CHECK-043, CHECK-052

## 实施任务

未声明；请结合范围说明核对。
