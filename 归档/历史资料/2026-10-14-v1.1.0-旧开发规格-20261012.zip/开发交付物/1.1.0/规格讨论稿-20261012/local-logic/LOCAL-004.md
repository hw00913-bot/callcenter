# LOCAL-004 接收DCC新行并分配主子批次

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [接收预外呼线索 · FUNC\-004](../features/FUNC-004.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-004

触发：LOCAL-004-B确认是新的有效DCC业务请求

## 前置条件

- 身份/任务/来源通过且request未重放；各行保留独立行定位

## 必须遵守的全局规则

- [GR-002](../global-logic.md#GR-002)
- [GR-003](../global-logic.md#GR-003)
- [GR-004](../global-logic.md#GR-004)
- [GR-006](../global-logic.md#GR-006)
- [GR-012](../global-logic.md#GR-012)
- [GR-015](../global-logic.md#GR-015)

## 输入与输出

输入：[FLD-001](../field-specs.md#FLD-001)、[FLD-002](../field-specs.md#FLD-002)、[FLD-003](../field-specs.md#FLD-003)、[FLD-004](../field-specs.md#FLD-004)、[FLD-007](../field-specs.md#FLD-007)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-009](../field-specs.md#FLD-009)、[FIELD-BATCH-KIND](../field-specs.md#FIELD-BATCH-KIND)、[FLD-015](../field-specs.md#FLD-015)、[FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)

输出：[FLD-010](../field-specs.md#FLD-010)、[FLD-011](../field-specs.md#FLD-011)、[FLD-002](../field-specs.md#FLD-002)、[FLD-013](../field-specs.md#FLD-013)、[FLD-003](../field-specs.md#FLD-003)、[FLD-004](../field-specs.md#FLD-004)、[FLD-008](../field-specs.md#FLD-008)、[FIELD-PHONE](../field-specs.md#FIELD-PHONE)、[FLD-007](../field-specs.md#FLD-007)、[FIELD-BATCH-KIND](../field-specs.md#FIELD-BATCH-KIND)、[FLD-015](../field-specs.md#FLD-015)、[FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)、[FIELD-ORIGINAL-IMPORT-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)、[FIELD-RECEIVED-AT](../field-specs.md#FIELD-RECEIVED-AT)、[FIELD-BATCH-CREATED-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)、[FLD-009](../field-specs.md#FLD-009)、[FLD-001](../field-specs.md#FLD-001)

## 处理步骤

### LOCAL-004-S01

逐行校验leadCode/phone/priority及isNewBatch Boolean；R可选来源元数据，不做字典范围校验

读取：FLD-001, FLD-007, FLD-008, FIELD-PHONE, FLD-009；写入：FLD-015, FIELD-ROW-ID

规则：GR-002, GR-003

### LOCAL-004-S02

按tenant/原supplierTaskId/leadCode定位固定phone组，冲突或历史关联不明不猜配

读取：FLD-003, FLD-004, FLD-008, FIELD-PHONE, FLD-007, FIELD-BATCH-KIND；写入：FLD-003, FLD-004, FLD-008, FIELD-PHONE, FLD-007, FIELD-BATCH-KIND, FLD-015, FIELD-ROW-ID

规则：GR-012, GR-015

### LOCAL-004-S03

每有效新行创建新recordId和batchId；true新主，false/缺省有主挂最近已保存主，无主自动首主

读取：FLD-002, FLD-007, FLD-008, FIELD-PHONE, FLD-003, FLD-004, FIELD-BATCH-KIND；写入：FLD-010, FLD-011, FLD-013, FLD-003, FLD-004, FLD-008, FIELD-PHONE, FLD-007, FIELD-BATCH-KIND

规则：GR-002, GR-012

### LOCAL-004-S04

保存本次priority和审计时间及request行到record/batch/root映射，形成逐行回执后触发自动提交

读取：FLD-001, FLD-002, FLD-003, FLD-004, FLD-007, FLD-008, FIELD-PHONE, FLD-009, FLD-010, FLD-011, FLD-013, FIELD-BATCH-KIND；写入：FLD-002, FLD-015, FIELD-ROW-ID, FIELD-ORIGINAL-IMPORT-AT, FIELD-RECEIVED-AT, FIELD-BATCH-CREATED-AT, FLD-009, FLD-001, FLD-007, FLD-013, FIELD-BATCH-KIND

规则：GR-002, GR-004, GR-006, GR-012

## 分支与异常

### LOCAL-004-B01

条件：缺必要字段或flag不是Boolean

结果：仅该行明确失败；不将非Boolean当false，其他有效行继续

涉及字段：FLD-007, FLD-008, FIELD-PHONE, FLD-009, FLD-015, FIELD-ROW-ID

验证：CHECK-007, CHECK-009, CHECK-049

### LOCAL-004-B02

条件：同组固定phone改变或归属/历史主关系冲突、多lead同号仍未决

结果：该行拒绝或待核且不提交，不修改旧记录；isNewBatch=true不能绕过

涉及字段：FLD-003, FLD-004, FLD-008, FIELD-PHONE, FLD-007, FIELD-BATCH-KIND

验证：CHECK-049

### LOCAL-004-B03

条件：true，或false/缺省但同组无主

结果：新批次为独立主，rootBatchId等于本次batchId

涉及字段：FLD-007, FLD-010, FLD-013, FLD-003, FLD-004, FLD-008, FIELD-PHONE, FIELD-BATCH-KIND

验证：CHECK-010, CHECK-048

### LOCAL-004-B04

条件：false/缺省且已有同组主

结果：创建新的子批次，root指保存创建顺序最近主，不挂上一子，不复用旧record/batch

涉及字段：FLD-007, FLD-010, FLD-011, FLD-013, FLD-003, FLD-004, FLD-008, FIELD-PHONE, FIELD-BATCH-KIND

验证：CHECK-010, CHECK-047, CHECK-048

## 完成后的状态

- 每有效新行新record和单手机号batch并保存root及原回执；无效行不提交且不回滚其他有效行

## 字段定义

- [FIELD-BATCH-CREATED-AT](../field-specs.md#FIELD-BATCH-CREATED-AT)
- [FIELD-BATCH-KIND](../field-specs.md#FIELD-BATCH-KIND)
- [FIELD-ORIGINAL-IMPORT-AT](../field-specs.md#FIELD-ORIGINAL-IMPORT-AT)
- [FIELD-PHONE](../field-specs.md#FIELD-PHONE)
- [FIELD-RECEIVED-AT](../field-specs.md#FIELD-RECEIVED-AT)
- [FIELD-ROW-ID](../field-specs.md#FIELD-ROW-ID)
- [FLD-001](../field-specs.md#FLD-001)
- [FLD-002](../field-specs.md#FLD-002)
- [FLD-003](../field-specs.md#FLD-003)
- [FLD-004](../field-specs.md#FLD-004)
- [FLD-007](../field-specs.md#FLD-007)
- [FLD-008](../field-specs.md#FLD-008)
- [FLD-009](../field-specs.md#FLD-009)
- [FLD-010](../field-specs.md#FLD-010)
- [FLD-011](../field-specs.md#FLD-011)
- [FLD-013](../field-specs.md#FLD-013)
- [FLD-015](../field-specs.md#FLD-015)

## 来源与验证

来源条目：acceptance:AC-001, acceptance:AC-005, acceptance:AC-006, acceptance:AC-007, acceptance:AC-009, acceptance:AC-010, acceptance:AC-014, acceptance:AC-015, acceptance:AC-019, acceptance:AC-032, acceptance:AC-047, acceptance:AC-048, acceptance:AC-049, acceptance:AC-052, features:FUNC-004, features:FUNC-004/boundary/business_rules/0, features:FUNC-004/boundary/business_rules/1, features:FUNC-004/boundary/business_rules/2, features:FUNC-004/boundary/business_rules/3, features:FUNC-004/boundary/business_rules/4, features:FUNC-004/boundary/business_rules/5, features:FUNC-004/boundary/business_rules/6, features:FUNC-004/boundary/business_rules/7, features:FUNC-004/boundary/business_rules/8, features:FUNC-004/boundary/business_rules/9, features:FUNC-004/boundary/exception_paths/0, features:FUNC-004/boundary/exception_paths/1, features:FUNC-004/boundary/exception_paths/2, features:FUNC-004/boundary/exception_paths/3, features:FUNC-004/boundary/exception_paths/4, features:FUNC-004/boundary/exception_paths/5, interfaces:API-001, interfaces:API-002, open_items:ISSUE-002, open_items:ISSUE-008, open_items:ISSUE-022, open_items:ISSUE-023, open_items:ISSUE-025, open_items:ISSUE-027, open_items:ISSUE-028, open_items:ISSUE-029, open_items:ISSUE-031, pages:PAGE-002, pages:PAGE-002/actions/0, pages:PAGE-002/actions/1, pages:PAGE-002/actions/2, pages:PAGE-002/actions/3, pages:PAGE-002/actions/4, pages:PAGE-002/actions/5, pages:PAGE-002/actions/6, pages:PAGE-002/actions/7, pages:PAGE-002/actions/8, pages:PAGE-002/actions/9, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, sequences:SEQ-001, sequences:SEQ-001/messages/0, sequences:SEQ-001/messages/1, sequences:SEQ-001/messages/10, sequences:SEQ-001/messages/11, sequences:SEQ-001/messages/12, sequences:SEQ-001/messages/13, sequences:SEQ-001/messages/14, sequences:SEQ-001/messages/2, sequences:SEQ-001/messages/3, sequences:SEQ-001/messages/4, sequences:SEQ-001/messages/5, sequences:SEQ-001/messages/6, sequences:SEQ-001/messages/7, sequences:SEQ-001/messages/8, sequences:SEQ-001/messages/9, sequences:SEQ-006, sequences:SEQ-006/messages/0, sequences:SEQ-006/messages/1, sequences:SEQ-006/messages/2, sequences:SEQ-006/messages/3, sequences:SEQ-006/messages/4, sequences:SEQ-006/messages/5, sequences:SEQ-006/messages/6, sequences:SEQ-006/messages/7, sequences:SEQ-006/messages/8, stories:US-001

验证：CHECK-001, CHECK-005, CHECK-006, CHECK-007, CHECK-009, CHECK-010, CHECK-014, CHECK-015, CHECK-019, CHECK-032, CHECK-047, CHECK-048, CHECK-049, CHECK-052

## 实施任务

未声明；请结合范围说明核对。
