# LOCAL-002 交换和解析指定租户业务身份

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [交换指定租户身份 · FUNC\-002](../features/FUNC-002.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-002

触发：DCC在后台携应用凭证和指定tenantId申请业务身份，或发起携身份的业务请求

## 前置条件

- 应用已存在且授权范围可确认；原型仅使用合成凭证

## 必须遵守的全局规则

- [GR-001](../global-logic.md#GR-001)
- [GR-020](../global-logic.md#GR-020)

## 输入与输出

输入：[FLD-003](../field-specs.md#FLD-003)、[FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)、[FLD-093](../field-specs.md#FLD-093)、[FLD-006](../field-specs.md#FLD-006)、[FLD-089](../field-specs.md#FLD-089)

输出：[FLD-006](../field-specs.md#FLD-006)

## 处理步骤

### LOCAL-002-S01

按凭证定位有效应用并核对指定租户当前授权

读取：FLD-003, FIELD-APP-ID, FLD-093, FLD-089；写入：无

规则：GR-001, GR-020

### LOCAL-002-S02

有效授权返回租户合成身份，后续业务请求每次解析范围

读取：FLD-003, FIELD-APP-ID, FLD-093；写入：FLD-006

规则：GR-001

### LOCAL-002-S03

删除或撤权后再次解析身份时拒绝失效范围

读取：FLD-003, FLD-006, FLD-089；写入：无

规则：GR-001, GR-020

## 分支与异常

### LOCAL-002-B01

条件：凭证无效、应用已删除或tenant未授权

结果：拒绝交换或业务请求；不创建可用身份

涉及字段：FLD-003, FIELD-APP-ID, FLD-093, FLD-006, FLD-089

验证：CHECK-017, CHECK-056, CHECK-057

### LOCAL-002-B02

条件：租户业务身份尝试应用管理

结果：拒绝管理调用，不改变配置

涉及字段：FLD-006

验证：CHECK-044, CHECK-045

### LOCAL-002-B03

条件：有效合成凭证且当前租户授权成立

结果：返回该租户合成业务身份，真实token时效/撤销仍待工程核验

涉及字段：FLD-003, FIELD-APP-ID, FLD-093, FLD-006

验证：CHECK-017, CHECK-045

## 完成后的状态

- 合法请求仅获得指定租户业务身份，不具有应用管理权限；无效请求不产生业务记录

## 字段定义

- [FIELD-APP-ID](../field-specs.md#FIELD-APP-ID)
- [FLD-003](../field-specs.md#FLD-003)
- [FLD-006](../field-specs.md#FLD-006)
- [FLD-089](../field-specs.md#FLD-089)
- [FLD-093](../field-specs.md#FLD-093)

## 来源与验证

来源条目：acceptance:AC-017, acceptance:AC-044, acceptance:AC-045, acceptance:AC-056, acceptance:AC-057, acceptance:AC-058, features:FUNC-002, features:FUNC-002/boundary/business_rules/0, features:FUNC-002/boundary/business_rules/1, features:FUNC-002/boundary/business_rules/2, features:FUNC-002/boundary/business_rules/3, features:FUNC-002/boundary/business_rules/4, features:FUNC-002/boundary/business_rules/5, features:FUNC-002/boundary/business_rules/6, features:FUNC-002/boundary/business_rules/7, features:FUNC-002/boundary/business_rules/8, features:FUNC-002/boundary/exception_paths/0, features:FUNC-002/boundary/exception_paths/1, interfaces:API-001, open_items:ISSUE-002, open_items:ISSUE-022, open_items:ISSUE-031, pages:PAGE-004, pages:PAGE-004/actions/0, pages:PAGE-004/actions/1, pages:PAGE-004/actions/2, scenarios:SC-001, scenarios:SC-001/alternate_flows/0, scenarios:SC-001/alternate_flows/0/steps/0, scenarios:SC-001/alternate_flows/1, scenarios:SC-001/alternate_flows/1/steps/0, scenarios:SC-001/alternate_flows/1/steps/1, scenarios:SC-001/alternate_flows/10, scenarios:SC-001/alternate_flows/10/steps/0, scenarios:SC-001/alternate_flows/10/steps/1, scenarios:SC-001/alternate_flows/2, scenarios:SC-001/alternate_flows/2/steps/0, scenarios:SC-001/alternate_flows/2/steps/1, scenarios:SC-001/alternate_flows/3, scenarios:SC-001/alternate_flows/3/steps/0, scenarios:SC-001/alternate_flows/3/steps/1, scenarios:SC-001/alternate_flows/4, scenarios:SC-001/alternate_flows/4/steps/0, scenarios:SC-001/alternate_flows/4/steps/1, scenarios:SC-001/alternate_flows/5, scenarios:SC-001/alternate_flows/5/steps/0, scenarios:SC-001/alternate_flows/5/steps/1, scenarios:SC-001/alternate_flows/6, scenarios:SC-001/alternate_flows/6/steps/0, scenarios:SC-001/alternate_flows/6/steps/1, scenarios:SC-001/alternate_flows/6/steps/2, scenarios:SC-001/alternate_flows/6/steps/3, scenarios:SC-001/alternate_flows/6/steps/4, scenarios:SC-001/alternate_flows/7, scenarios:SC-001/alternate_flows/7/steps/0, scenarios:SC-001/alternate_flows/7/steps/1, scenarios:SC-001/alternate_flows/7/steps/2, scenarios:SC-001/alternate_flows/8, scenarios:SC-001/alternate_flows/8/steps/0, scenarios:SC-001/alternate_flows/8/steps/1, scenarios:SC-001/alternate_flows/9, scenarios:SC-001/alternate_flows/9/steps/0, scenarios:SC-001/main_flow/0, scenarios:SC-001/main_flow/1, scenarios:SC-001/main_flow/2, scenarios:SC-001/main_flow/3, scenarios:SC-001/main_flow/4, scenarios:SC-001/main_flow/5, scenarios:SC-001/main_flow/6, scenarios:SC-001/postconditions/0, scenarios:SC-001/postconditions/1, scenarios:SC-001/postconditions/2, scenarios:SC-001/postconditions/3, scenarios:SC-001/postconditions/4, scenarios:SC-001/preconditions/0, scenarios:SC-001/preconditions/1, scenarios:SC-001/preconditions/2, scenarios:SC-001/preconditions/3, scenarios:SC-001/preconditions/4, scenarios:SC-005, scenarios:SC-005/alternate_flows/0, scenarios:SC-005/alternate_flows/0/steps/0, scenarios:SC-005/alternate_flows/1, scenarios:SC-005/alternate_flows/1/steps/0, scenarios:SC-005/alternate_flows/2, scenarios:SC-005/alternate_flows/2/steps/0, scenarios:SC-005/alternate_flows/3, scenarios:SC-005/alternate_flows/3/steps/0, scenarios:SC-005/alternate_flows/4, scenarios:SC-005/alternate_flows/4/steps/0, scenarios:SC-005/main_flow/0, scenarios:SC-005/main_flow/1, scenarios:SC-005/main_flow/2, scenarios:SC-005/main_flow/3, scenarios:SC-005/main_flow/4, scenarios:SC-005/postconditions/0, scenarios:SC-005/postconditions/1, scenarios:SC-005/postconditions/2, scenarios:SC-005/preconditions/0, scenarios:SC-005/preconditions/1, scenarios:SC-005/preconditions/2, sequences:SEQ-001, sequences:SEQ-001/messages/0, sequences:SEQ-001/messages/1, sequences:SEQ-001/messages/10, sequences:SEQ-001/messages/11, sequences:SEQ-001/messages/12, sequences:SEQ-001/messages/13, sequences:SEQ-001/messages/14, sequences:SEQ-001/messages/2, sequences:SEQ-001/messages/3, sequences:SEQ-001/messages/4, sequences:SEQ-001/messages/5, sequences:SEQ-001/messages/6, sequences:SEQ-001/messages/7, sequences:SEQ-001/messages/8, sequences:SEQ-001/messages/9, sequences:SEQ-005, sequences:SEQ-005/messages/0, sequences:SEQ-005/messages/1, sequences:SEQ-005/messages/10, sequences:SEQ-005/messages/11, sequences:SEQ-005/messages/12, sequences:SEQ-005/messages/13, sequences:SEQ-005/messages/14, sequences:SEQ-005/messages/2, sequences:SEQ-005/messages/3, sequences:SEQ-005/messages/4, sequences:SEQ-005/messages/5, sequences:SEQ-005/messages/6, sequences:SEQ-005/messages/7, sequences:SEQ-005/messages/8, sequences:SEQ-005/messages/9, stories:US-001

验证：CHECK-017, CHECK-044, CHECK-045, CHECK-056, CHECK-057, CHECK-058

## 实施任务

未声明；请结合范围说明核对。
