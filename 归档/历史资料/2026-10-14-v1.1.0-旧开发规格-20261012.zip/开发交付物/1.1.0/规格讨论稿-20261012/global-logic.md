# 全局逻辑说明

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](README.md) · [按功能阅读](features/README.md)

全局规则只在此定义，局部说明和任务通过编号引用；调整全局规则后需重新检查所有引用与测试。

## 系统目标与边界

云外呼平台承接应用接入、任务锁来源、逐行单号导入、精确供应商映射、每次结果回传及失败导出。主/子两层只表达同组业务关联；每次实际新导入保持本地batchId到该次供应商fileId映射。当前依据已批准合成原型形成产品规格，不把合成验证升级为真实供应商接口验证。

DCC决定是否/何时再次业务导入、本次priority与三天五呼计次；平台负责租户与来源校验、请求幂等、主子分配、单号拆批、自动提交、可信结果关联/展示/交付和精准删除。AliCti负责实际接收、排重、拨打及原始结果；其真实契约、并发和可靠性仍待工程与供应商核实。平台无每日衰减、每日状态查询、重导定时器、独立呼叫额度或保证换主叫；原型仅合成，不发真实供应商/DCC请求。

## 参与角色

- 超级管理员
- 运营人员
- DCC
- 云呼叫中心
- AliCti供应商

## 全局不变规则

<a id="GR-001"></a>

### GR-001

应用凭证+tenantId换取租户token；业务请求由token识别租户，任务归租户；应用只留来源追踪，凭据时效与真实接口未定。 超管可独立建立/维护应用用于该用途，日常应用页只表达密钥获取token；普通修改保留appId/密钥，删除使该应用不再获取新身份，合成已发身份失效，业务任务/记录及来源审计保留。生产密钥算法/存储/管理API/token时效和已发真实token失效机制仍未核验。

来源条目：rules:BR-001

验证：CHECK-017, CHECK-044, CHECK-045, CHECK-055, CHECK-056, CHECK-057

<a id="GR-002"></a>

### GR-002

有效新业务逐行新record和单手机号batch，不覆盖旧记录。DCC请求级requestId可多行，真重导用新ID；逐行isNewBatch可选Boolean、missing=false，同组固定phone保存root；true新主，false/缺省有主新子挂最近已保存同组主、无主auto首主，复用主关联仍新业务编号。同ID同归一完整有效内容返原逐行结果不新建重交，异内容拒整个重复请求；新请求失败行不回滚有效行。手工按原字段/提交前最终priority独立拆批，不新增DCCflag/request/归组协议。

来源条目：rules:BR-002

验证：CHECK-001, CHECK-006, CHECK-007, CHECK-010, CHECK-047, CHECK-048, CHECK-050, CHECK-051

<a id="GR-003"></a>

### GR-003

接口与手工R可选来源元数据，无字典维护/范围校验；缺R不失败，提供则保留且不删除旧值。priority独立必填，不补默认、不由R推导；taskId为供应商任务。接口按本次DCC提供的有效priority保存与透传，不继承旧priority、不按日期衰减；手工沿提交前逐条最终值。生产类型/长度/数值范围仍由开发核实。 DCC接口每行可选Boolean isNewBatch，未传等同false且归一参与完整有效请求幂等比较，非Boolean不当false；手工不新增该字段。

来源条目：rules:BR-003

验证：CHECK-005, CHECK-009, CHECK-030, CHECK-049

<a id="GR-004"></a>

### GR-004

DCC鉴权及租户/原任务归属后，以missing isNewBatch=false归一后的完整有效请求核对requestId；同ID同内容返原逐行record/batch/root，不重拆重交，异内容拒整个重复请求。仅新ID逐行校验固定phone组和主子规则，改号/归属冲突/历史组或主不明不提交，其他有效行继续；旧请求重传不因后有新主重新选root。手工原校验/最终priority保存独立记录批次，不新增DCC接口协议。有效新业务保存后自动提交供应商，明确拒绝失败导出且保留，未知不当拒绝、不自动重交，已提交不撤回重排。

来源条目：rules:BR-004

验证：CHECK-011, CHECK-013, CHECK-035, CHECK-050, CHECK-051

<a id="GR-005"></a>

### GR-005

接口和手工导入失败均适用：未成功下载不固定到期；成功下载后只删除本次导出明细/文件，失败中断保留，成功业务记录不受影响；真实下载成功信号待核。

来源条目：rules:BR-005

验证：CHECK-008, CHECK-031, CHECK-042

<a id="GR-006"></a>

### GR-006

平台取消每日状态查询、自然日priority衰减及派生存量改写，仅服务衰减的获取退出且不改独立人工查询。本次priority不因未拨/未接通/跨日/原导入日/旧批值改变，原时间审计，DCC决定本次导入及priority；同组主子不恢复每日策略。手工保留提交前最终priority和独立拆批，不新增DCCflag/request/归组主子协议。

来源条目：rules:BR-006

验证：CHECK-014, CHECK-015, CHECK-032

<a id="GR-007"></a>

### GR-007

删除仅指定原任务具体供应商批次号码，明确成功后本地记录、必要幂等/固定phone组/主子root/精确供应商通话映射保留并回传状态；失败未知不标已删。不按leadCode/主批/组整体删除，不作用其他主子或同号记录。无每日衰减/平台重导计划，执行中并发精准删除仍待核。 切换删除目标或结果样例清旧反馈，不抹对应旧对象已保存证据、不把旧反馈当当前结果。

来源条目：rules:BR-007

验证：CHECK-016, CHECK-024, CHECK-025, CHECK-061

<a id="GR-008"></a>

### GR-008

关联线路侧风控的每次话单/SIP及结果；接口任务回传DCC，由DCC决定是否再次导入。供应商导航可能自动降级，不承诺绝对换主叫，不叠加平台重导。 未可信纯SIP单独保留待核来源，不改原call业务结果或冒充可信非SIP冲突；无其他真实矛盾时，随后可信精准call/SIP在同一对象正常更新，无新增实际呼叫。

来源条目：rules:BR-008

验证：CHECK-002, CHECK-035, CHECK-062

<a id="GR-009"></a>

### GR-009

可信且准确关联的预测呼叫失败事件回传原因，无话单失败不等待客户状态推送/话单；精确事件编号与原因映射待核。；禁呼未解禁、限呼未到期及无可用中继失败回传真实原因，由DCC判断恢复条件与重导，不绕过限制、不在平台设置自动恢复或重导预算。

来源条目：rules:BR-009

验证：CHECK-003, CHECK-020, CHECK-033

<a id="GR-010"></a>

### GR-010

确认客户已接听、客户挂断且真实时长0～2秒（含0/2），纳入秒挂；未接通/缺失/异常不纳。供应商枚举和字段单位待核。

来源条目：rules:BR-010

验证：CHECK-021, CHECK-034

<a id="GR-011"></a>

### GR-011

秒挂是否/何时重导及次数由DCC决策，原30分钟业务上下文不形成平台计时器；不再发放独立额外4次。

来源条目：rules:BR-011

验证：CHECK-004, CHECK-022

<a id="GR-012"></a>

### GR-012

仅DCC接口按tenant/原supplierTaskId/leadCode固定phone归组，首次有效绑定phone，后续仅同phone；跨tenant/原任务隔离，不混组。新业务请求新requestId，可多行，每有效新行新recordId和单手机号batchId；逐行可选Boolean isNewBatch、missing=false，true可同组另开独立主(root=batch)，false/缺省有主新子root=最近已保存同组主batch，无主自动首主(root=batch)。最近主按本地主批创建顺序/稳定顺序，不按最近同号/结果时间/priority/子批，子不挂上一子。DCC不必传previousBatchId/parentBatchId且不虚构parent，root必须保存回执。先鉴权/归一后完整请求幂等，同ID同内容优先原逐行结果/映射不新建重交，异内容拒整重复；后来新主不改旧请求root。改号/归属冲突/历史组或主不明拒绝或待核不提交，多lead同phone未决不放开。本次priority不旧继承，原时间审计；每次结果依精确vendorfileId/实际batch/原始号码/call事件而非leadCode单键。DCC计次不因主子改变，手工不新增此接口协议。

来源条目：rules:BR-012

验证：CHECK-019, CHECK-023, CHECK-047, CHECK-048, CHECK-049, CHECK-050, CHECK-051, CHECK-052

<a id="GR-013"></a>

### GR-013

三天五呼及重导次数由DCC管理，单任务范围，初呼及秒挂同计5次目标，首次导入当日第1天；普通双方接通停止但秒挂例外。平台不重复调度计数。；初呼与秒挂共用单任务5次目标，由DCC按真实尝试汇总；重新导入请求或重复通知不直接计实际呼叫，平台不新增业务额度。 SRC-084～086仅改归组/主子，新主/子编号不直接算实际呼叫或重置DCC计数，多lead同phone计次关系仍待核。

来源条目：rules:BR-013

验证：CHECK-026, CHECK-027

<a id="GR-014"></a>

### GR-014

手工必需leadCode与priority，R可选无字典维护/范围校验，一号一独立批次；统一/逐条priority仅提交前可改、最终值保存提交。统一导入客户入口在预外呼列表及任务内常驻；按已锁来源分派DCC或手工入口，DCC任务不能使用手工写入口，后端同时校验来源；不可导入状态保留禁用入口及原因；提交后无人工改priority或自然日衰减。手工不新增DCC requestId/isNewBatch/归组主子字段或校验。 常驻通用导入入口按锁来源打开对应界面，接口任务不开放手工混入；手工CSV变化/预览失败使旧草稿不可提交，提交前复核当前有效预览。

来源条目：rules:BR-014

验证：CHECK-029, CHECK-030, CHECK-031, CHECK-059, CHECK-060

<a id="GR-015"></a>

### GR-015

关联不明/超时/冲突待核，不伪造结果终态，重复/SIP晚更新不算新呼叫。DCC新业务逐行固定phone组校验，改号/归属冲突/历史组或主不明拒绝或待核不提交，其他有效行继续，多lead同phone未决不放开，不盲配最近同号。DCC无需previous，不因遗漏上一批次拒绝。请求级幂等优先于新主子分配：missing flag=false归一后同ID同完整有效内容返原record/batch/root，异内容拒整个重复请求。补送不重导；真实规范化/作用域/原子性和供应商同号重导/排重/执行中并行待核，不新增先删/等finishRetryFlag策略。 未可信SIP来源与真实已确认非SIP矛盾分开；未可信包不污染原call或阻挡随后可信准确更新，真正矛盾继续待核。切换精确删除目标/结果样例清旧反馈且保留原业务证据。

来源条目：rules:BR-015

验证：CHECK-035, CHECK-043, CHECK-049, CHECK-050, CHECK-051, CHECK-062

<a id="GR-016"></a>

### GR-016

创建任务提交后锁定DCC接口导入或手工导入一种来源，不可切换或混用；后端同时校验taskId与方式，任务归租户不绑定应用。 预外呼列表/任务内导入入口常驻并按该锁来源打开；不可导入保留禁用原因，既有历史任务仅未启动补导且原名单批次累计、不扩启动后规则。

来源条目：rules:BR-016

验证：CHECK-029, CHECK-036, CHECK-059

<a id="GR-017"></a>

### GR-017

接口任务每次结果向后台配置固定地址回传requestId+行定位、tenant/原supplierTaskId/leadCode/phone、该实际记录batchId/rootBatchId及callID或稳定事件；root从保存映射取、后有新主不改旧归属。leadCode只组归属，供应商fileId/实际批次/call精确匹配保持；手工仅查看不新增DCC协议，无前台/租户接收端设置、不发真实回调。finishRetryFlag严格Integer1/0/未知，独立SIP晚更新，不宣整个任务或DCC计划完成、不新加等待该标记重导策略，每次结果回传非仅最后。

来源条目：rules:BR-017

验证：CHECK-018, CHECK-023, CHECK-037, CHECK-038, CHECK-052

<a id="GR-018"></a>

### GR-018

同步result=0不等逐条全成功，展示本地校验保存/供应商导入/呼叫阶段及原始importTotal/successTotal/invalidTotal；准确成功证据正常记录，仅汇总不任指行，未知矛盾待核。53分片按enterpriseId经核实tenant/原taskId/精确fileId/原始号码回查实际记录batch及保存组/root，多候选待核，不用leadCode单键/最近同号。totalBatchCount/currentBatchCount仅失败推送分片非业务主子，重复不新增/乱序迟到不丢；收齐仅该声明推送组、不等全导入终态，未收不推定零失败。接口回传原导入失败及requestId+行定位/组/实际batch/root，供应商未给业务字段则精确回查保存映射、不新增供应商协议承诺；手工仅查看。导入失败不计实际呼叫/平台重导，补送不重做供应商导入。

来源条目：rules:BR-018

验证：CHECK-039, CHECK-040, CHECK-041, CHECK-043

<a id="GR-019"></a>

### GR-019

失败快照显示分片完整性/待核，可信成功仅清该快照明细文件，失败中断保留、后到新失败下次下载。两来源客户记录、必要事件去重/分片交付状态保留；接口原逐行requestId幂等结果/固定phone组/主子root/精确vendorfileId和实际batch/call映射不随明细清理/精准删除丢失。手工不新增DCCflag/request/归组协议，已导出重复不再生，不清空整个导入或成功客户。

来源条目：rules:BR-019

验证：CHECK-008, CHECK-042, CHECK-043, CHECK-052

<a id="GR-020"></a>

### GR-020

应用接入的列表查询、查看详情、新增、修改、删除是超管可独立发起的五个业务操作；旧配置保存复用修改，不静默重编号。非超管菜单/直达页面/管理调用拒绝且无写，租户业务身份不获管理权，普通运营原导入/下载不移除。新建保存应用名称/可访问业务租户及appId/密钥，普通修改不重置；查看不写、取消/保存失败不假造成功。精确删除只该应用，合成凭证/已发身份失效，其他应用和业务记录/任务/结果保留。日常页简化密钥获取token，移除技术身份交换面板但保留授权验证和不可用合成密钥必要提示。生产凭证/CRUD/token撤权契约仍missing/partial；未要求的收费/启停/密钥重置/权限自动授予不添加。

来源条目：rules:BR-020

验证：CHECK-044, CHECK-045, CHECK-053, CHECK-054, CHECK-055, CHECK-056, CHECK-057, CHECK-058

<a id="GR-021"></a>

### GR-021

同任务待提交按本次有效priority高先、同级本地导入时间FIFO，不同任务独立；DCC本次输入/手工提交前最终值，不按旧批或日期改写。已提交不撤回重排，未知提交不因重排或同requestId重传重复提交；主子选择不改变priority、不承诺拨打顺序。

来源条目：rules:BR-021

验证：CHECK-009, CHECK-030, CHECK-046

## 端到端流程

<a id="GFLOW-APP"></a>

### GFLOW-APP 应用接入五项独立操作与租户业务身份

| 步骤 | 执行方 | 动作 | 局部说明 | 失败处理 |
| --- | --- | --- | --- | --- |

| GFLOW-APP-S01 | 超级管理员 | 按需读取应用列表或筛选 | [LOCAL-018](local-logic/LOCAL-018.md) | 无管理权拒绝读取；无结果显示空态。 |

| GFLOW-APP-S02 | 超级管理员 | 选择新增并保存名称/授权租户；已有应用也可直接进入查看 | [LOCAL-019](local-logic/LOCAL-019.md) | 取消/失败不生成应用；已有应用不必再次创建。 |

| GFLOW-APP-S03 | 超级管理员 | 查看指定应用详情与合成密钥 | [LOCAL-020](local-logic/LOCAL-020.md) | 无权/不存在/已删目标明确反馈，不显示其他应用。 |

| GFLOW-APP-S04 | 超级管理员 | 按需修改当前应用名称/授权，普通修改保持密钥 | [LOCAL-001](local-logic/LOCAL-001.md) | 取消/失败保留原配置；无权或目标变化拒绝。 |

| GFLOW-APP-S05 | 超级管理员 | 按需确认删除精确应用 | [LOCAL-021](local-logic/LOCAL-021.md) | 取消/失败不删除、不先撤权，其他应用及业务历史保持。 |

| GFLOW-APP-S06 | DCC | 在后台以有效应用凭证和指定租户申请业务身份；不要求先执行删除 | [LOCAL-002](local-logic/LOCAL-002.md) | 无效/已删凭证或未授权租户拒绝，业务身份不获管理权。 |

来源条目：documents:product-input.json, open_items:ISSUE-001, open_items:ISSUE-003, open_items:ISSUE-007, open_items:ISSUE-009, open_items:ISSUE-010, open_items:ISSUE-011, open_items:ISSUE-012, open_items:ISSUE-013, open_items:ISSUE-014, open_items:ISSUE-015, open_items:ISSUE-016, open_items:ISSUE-017, open_items:ISSUE-018, open_items:ISSUE-019, open_items:ISSUE-020, project_facts:PRODUCT-CONTEXT, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/4, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/5, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/6, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/7, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/8, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/9, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/4, project_facts:PRODUCT-FIELD-MAP, scenarios:SC-005, sequences:SEQ-005

验证：CHECK-017, CHECK-044, CHECK-045, CHECK-053, CHECK-054, CHECK-055, CHECK-056, CHECK-057, CHECK-058

<a id="GFLOW-DCC"></a>

### GFLOW-DCC DCC新业务导入与技术重传分流

| 步骤 | 执行方 | 动作 | 局部说明 | 失败处理 |
| --- | --- | --- | --- | --- |

| GFLOW-DCC-S01 | 运营人员 | 创建任务确认锁定DCC来源及租户/原任务 | [LOCAL-016](local-logic/LOCAL-016.md) | 校验失败不保存；已创建任务不可变更来源。 |

| GFLOW-DCC-S02 | DCC | 携租户业务身份与完整request导入，优先鉴权归一及幂等 | [LOCAL-004-B](local-logic/LOCAL-004-B.md) | 无权/归属错误拒绝；同ID同内容直接原回执结束，异内容整请求拒绝。 |

| GFLOW-DCC-S03 | 云呼叫中心 | 仅新请求逐行校验固定phone组并分配主/子单号批次 | [LOCAL-004](local-logic/LOCAL-004.md) | 无效/冲突/歧义行失败或待核不提交，其他有效行继续。 |

| GFLOW-DCC-S04 | 云呼叫中心 | 有效新行保存后依本次priority/FIFO自动独立供应商提交 | [LOCAL-005](local-logic/LOCAL-005.md) | 明确拒绝入失败；超时/矛盾待核不重交。 |

| GFLOW-DCC-S05 | 运营人员 | 在任务记录页查看原回执、单号batch/file映射与主子历史 | [LOCAL-015](local-logic/LOCAL-015.md) | 读取范围不符拒绝；无数据明确空态，未知不伪造成功。 |

来源条目：documents:product-input.json, flows:FLOW-001, flows:FLOW-001/steps/0, flows:FLOW-001/steps/1, flows:FLOW-001/steps/10, flows:FLOW-001/steps/2, flows:FLOW-001/steps/3, flows:FLOW-001/steps/4, flows:FLOW-001/steps/5, flows:FLOW-001/steps/6, flows:FLOW-001/steps/7, flows:FLOW-001/steps/8, flows:FLOW-001/steps/9, open_items:ISSUE-001, open_items:ISSUE-003, open_items:ISSUE-007, open_items:ISSUE-009, open_items:ISSUE-010, open_items:ISSUE-011, open_items:ISSUE-012, open_items:ISSUE-013, open_items:ISSUE-014, open_items:ISSUE-015, open_items:ISSUE-016, open_items:ISSUE-017, open_items:ISSUE-018, open_items:ISSUE-019, open_items:ISSUE-020, project_facts:PRODUCT-CONTEXT, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/4, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/5, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/6, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/7, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/8, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/9, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/4, project_facts:PRODUCT-FIELD-MAP, scenarios:SC-001, sequences:SEQ-001

验证：CHECK-001, CHECK-005, CHECK-006, CHECK-007, CHECK-009, CHECK-010, CHECK-011, CHECK-012, CHECK-014, CHECK-015, CHECK-019, CHECK-032, CHECK-036, CHECK-046, CHECK-047, CHECK-048, CHECK-049, CHECK-050, CHECK-051, CHECK-052

<a id="GFLOW-MANUAL"></a>

### GFLOW-MANUAL 手工当前预览的单号导入

| 步骤 | 执行方 | 动作 | 局部说明 | 失败处理 |
| --- | --- | --- | --- | --- |

| GFLOW-MANUAL-S01 | 运营人员 | 创建任务选择并锁定手工来源 | [LOCAL-016](local-logic/LOCAL-016.md) | 不允许已创建DCC任务换源或混用。 |

| GFLOW-MANUAL-S02 | 运营人员 | 从常驻入口编辑CSV、生成当前有效预览并确定最终priority | [LOCAL-004-A](local-logic/LOCAL-004-A.md) | 文本变化/预览失败/身份状态变更不提交旧稿；无权入口禁用有原因。 |

| GFLOW-MANUAL-S03 | 云呼叫中心 | 有效行新建独立记录及单号批次后自动提交 | [LOCAL-005](local-logic/LOCAL-005.md) | 逐行无效留失败；供应商明确拒绝与未知分开。 |

| GFLOW-MANUAL-S04 | 运营人员 | 仅在任务记录页查看导入和结果 | [LOCAL-015](local-logic/LOCAL-015.md) | 不生成DCC协议输入或回传；无权限拒绝。 |

来源条目：documents:product-input.json, open_items:ISSUE-001, open_items:ISSUE-003, open_items:ISSUE-007, open_items:ISSUE-009, open_items:ISSUE-010, open_items:ISSUE-011, open_items:ISSUE-012, open_items:ISSUE-013, open_items:ISSUE-014, open_items:ISSUE-015, open_items:ISSUE-016, open_items:ISSUE-017, open_items:ISSUE-018, open_items:ISSUE-019, open_items:ISSUE-020, project_facts:PRODUCT-CONTEXT, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/4, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/5, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/6, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/7, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/8, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/9, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/4, project_facts:PRODUCT-FIELD-MAP, scenarios:SC-001, sequences:SEQ-006

验证：CHECK-001, CHECK-005, CHECK-007, CHECK-014, CHECK-029, CHECK-030, CHECK-031, CHECK-036, CHECK-046, CHECK-059, CHECK-060

<a id="GFLOW-RESULT"></a>

### GFLOW-RESULT 每次供应商结果精确关联与来源分流

| 步骤 | 执行方 | 动作 | 局部说明 | 失败处理 |
| --- | --- | --- | --- | --- |

| GFLOW-RESULT-S01 | AliCti供应商 | 送入事件/话单/纯SIP，平台核实来源及精确关联并处理重复冲突 | [LOCAL-013](local-logic/LOCAL-013.md) | 缺关联/超时/可信矛盾待核；未可信纯SIP独立存证不污染call。 |

| GFLOW-RESULT-S02 | 云呼叫中心 | 对可信客户接通挂断结果识别秒挂 | [LOCAL-011](local-logic/LOCAL-011.md) | 条件不足不标秒挂；真实0秒与缺失区分。 |

| GFLOW-RESULT-S03 | 云呼叫中心 | 对可信无话单失败独立登记原因，无此事件则跳过 | [LOCAL-012](local-logic/LOCAL-012.md) | 缺稳定事件或关联则待核，不等待或伪造话单。 |

| GFLOW-RESULT-S04 | 云呼叫中心 | 接口每次结果/晚更新固定地址交付，手工仅查看 | [LOCAL-010](local-logic/LOCAL-010.md) | 失败待补送；补送不重导或新增实际呼叫。 |

| GFLOW-RESULT-S05 | 运营人员 | 查询本次实际批次/call及其来源交付证据 | [LOCAL-015](local-logic/LOCAL-015.md) | 没有结果保留未知；不以finishRetryFlag宣布整个任务完成。 |

来源条目：documents:product-input.json, open_items:ISSUE-001, open_items:ISSUE-003, open_items:ISSUE-007, open_items:ISSUE-009, open_items:ISSUE-010, open_items:ISSUE-011, open_items:ISSUE-012, open_items:ISSUE-013, open_items:ISSUE-014, open_items:ISSUE-015, open_items:ISSUE-016, open_items:ISSUE-017, open_items:ISSUE-018, open_items:ISSUE-019, open_items:ISSUE-020, project_facts:PRODUCT-CONTEXT, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/4, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/5, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/6, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/7, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/8, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/9, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/4, project_facts:PRODUCT-FIELD-MAP, scenarios:SC-002, scenarios:SC-003, scenarios:SC-004, sequences:SEQ-002, sequences:SEQ-003, sequences:SEQ-004

验证：CHECK-002, CHECK-003, CHECK-004, CHECK-018, CHECK-020, CHECK-021, CHECK-022, CHECK-023, CHECK-026, CHECK-027, CHECK-033, CHECK-034, CHECK-035, CHECK-037, CHECK-038, CHECK-062

<a id="GFLOW-FAILURE"></a>

### GFLOW-FAILURE 异步失败分片、交付与导出快照

| 步骤 | 执行方 | 动作 | 局部说明 | 失败处理 |
| --- | --- | --- | --- | --- |

| GFLOW-FAILURE-S01 | AliCti供应商 | 提供53失败分片，平台按企业/任务/file/原号码核实合并 | [LOCAL-017](local-logic/LOCAL-017.md) | 冲突待核；重复不新增，未收到不推零失败，片齐不推全终态。 |

| GFLOW-FAILURE-S02 | 云呼叫中心 | 接口导入失败携原始原因及保存关联交付，手工只查看 | [LOCAL-010](local-logic/LOCAL-010.md) | 回传失败保留待补送，不重新导入。 |

| GFLOW-FAILURE-S03 | 运营人员 | 生成本次失败快照并下载 | [LOCAL-006](local-logic/LOCAL-006.md) | 生成/点击/失败/中断不清；可信成功仅清本快照明细文件。 |

| GFLOW-FAILURE-S04 | 运营人员 | 查看后到失败及仍保留的关联/去重/交付证据 | [LOCAL-015](local-logic/LOCAL-015.md) | 旧重复不再生，新失败下次可导出，不清成功客户。 |

来源条目：documents:product-input.json, flows:FLOW-002, flows:FLOW-002/steps/0, flows:FLOW-002/steps/1, flows:FLOW-002/steps/2, flows:FLOW-002/steps/3, flows:FLOW-002/steps/4, open_items:ISSUE-001, open_items:ISSUE-003, open_items:ISSUE-007, open_items:ISSUE-009, open_items:ISSUE-010, open_items:ISSUE-011, open_items:ISSUE-012, open_items:ISSUE-013, open_items:ISSUE-014, open_items:ISSUE-015, open_items:ISSUE-016, open_items:ISSUE-017, open_items:ISSUE-018, open_items:ISSUE-019, open_items:ISSUE-020, project_facts:PRODUCT-CONTEXT, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/4, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/5, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/6, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/7, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/8, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/9, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/4, project_facts:PRODUCT-FIELD-MAP, sequences:SEQ-001, sequences:SEQ-007

验证：CHECK-008, CHECK-013, CHECK-031, CHECK-039, CHECK-040, CHECK-041, CHECK-042, CHECK-043, CHECK-052

<a id="GFLOW-DELETE"></a>

### GFLOW-DELETE 精确供应商删除与本地历史保护

| 步骤 | 执行方 | 动作 | 局部说明 | 失败处理 |
| --- | --- | --- | --- | --- |

| GFLOW-DELETE-S01 | DCC | 指定租户原任务的实际记录/批次/手机号删除 | [LOCAL-009](local-logic/LOCAL-009.md) | 关联缺失/多候选/越界拒绝或待核；失败未知不标已删。 |

| GFLOW-DELETE-S02 | 云呼叫中心 | 按对应实际对象交付删除结果与保留关联 | [LOCAL-010](local-logic/LOCAL-010.md) | 交付失败保留可补送，不重做删除。 |

| GFLOW-DELETE-S03 | 运营人员 | 在任务记录页查看本次结果及其他主子保持 | [LOCAL-015](local-logic/LOCAL-015.md) | 切换目标不沿用旧反馈，旧目标保存证据不丢。 |

来源条目：documents:product-input.json, flows:FLOW-001, flows:FLOW-001/steps/0, flows:FLOW-001/steps/1, flows:FLOW-001/steps/10, flows:FLOW-001/steps/2, flows:FLOW-001/steps/3, flows:FLOW-001/steps/4, flows:FLOW-001/steps/5, flows:FLOW-001/steps/6, flows:FLOW-001/steps/7, flows:FLOW-001/steps/8, flows:FLOW-001/steps/9, open_items:ISSUE-001, open_items:ISSUE-003, open_items:ISSUE-007, open_items:ISSUE-009, open_items:ISSUE-010, open_items:ISSUE-011, open_items:ISSUE-012, open_items:ISSUE-013, open_items:ISSUE-014, open_items:ISSUE-015, open_items:ISSUE-016, open_items:ISSUE-017, open_items:ISSUE-018, open_items:ISSUE-019, open_items:ISSUE-020, project_facts:PRODUCT-CONTEXT, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/4, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/5, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/6, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/7, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/8, project_facts:PRODUCT-CONTEXT/state_models/0/transitions/9, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/1/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/0, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/1, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/2, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/3, project_facts:PRODUCT-CONTEXT/state_models/2/transitions/4, project_facts:PRODUCT-FIELD-MAP, sequences:SEQ-009

验证：CHECK-016, CHECK-024, CHECK-025, CHECK-052, CHECK-061

## 共享状态规则

- 任务的tenant、原supplierTaskId与导入来源在创建确认后锁定；业务身份按当前应用授权解析，应用管理权限独立。
- DCC请求在鉴权/归属确认后先missing isNewBatch=false归一完整内容，再按requestId读原回执；同ID异内容拒绝整个重复请求，不为任何行重分配或覆盖。
- 同tenant/原任务/leadCode仅绑定固定phone；每有效新行总是新record和单号batch，root保存后不随后来新主改变。最近主按本地保存创建稳定顺序，具体并发原子性由工程落实。
- 同任务待提交按本次priority高先、同级本地时间FIFO；不同任务独立。已提交不撤回重排，未知不重复提交，日期/工作时间不修改priority。
- 本地校验/保存、供应商导入、实际呼叫和DCC交付是不同状态；同步汇总/53分片完整度/finishRetryFlag不得互相替代作全业务完成证据。
- 每次实际导入的供应商fileId对应该次batch；本地root仅归组。真实同号接收与排重、执行中并行及精准删除作用域未核实，不能由合成fileId推为生产保证。
- 重复/晚更新/补送仅作用原对象；未可信纯SIP独立存证，真实可信非SIP冲突保留待核，不因后续SIP抹除。
- 失败快照成功下载只清本次明细文件；必要幂等回执、group/root、批次/file/call映射、去重分片及交付状态保留。精准删除同样不删除这些关联。

## 数据归属

- 超级管理员维护应用名称与授权业务租户；平台提供合成凭证及范围解析，真实凭证算法、保存和token撤权机制由工程设计核实。
- DCC提供请求级requestId、逐行定位、leadCode/固定phone、本次priority及可选R/isNewBatch；DCC拥有重导时机和单任务业务计数职责。
- 运营人员仅在手工提交前编辑当前CSV和逐条最终priority；平台保存独立本地记录/批次及审计时间，不将手工导入扩为DCC主子协议。
- 平台产生recordId/batchId和DCC行root关联、原逐行回执与本地稳定顺序；这些映射以保存时事实为准，不能从后到结果或最新主反推。
- AliCti提供真实fileId、同步数量、53分片、通话/失败/SIP原证据；平台负责可信来源与精确关联及保留未知，不编造缺失结果或供应商新增字段。
- 平台维护每次结果、失败快照、已导出去重和固定后台DCC交付状态；DCC确认契约、真实下载成功信号与可靠交付技术待核。

## 跨模块协作

工程模块划分与物理接口由开发补充；业务衔接以本页流程和局部说明为准。

## 局部说明索引

- [LOCAL-001](local-logic/LOCAL-001.md) 修改具体应用
- [LOCAL-002](local-logic/LOCAL-002.md) 交换和解析指定租户业务身份
- [LOCAL-004-B](local-logic/LOCAL-004-B.md) 核验DCC身份与请求级幂等
- [LOCAL-004](local-logic/LOCAL-004.md) 接收DCC新行并分配主子批次
- [LOCAL-004-A](local-logic/LOCAL-004-A.md) 预览并提交手工线索
- [LOCAL-005](local-logic/LOCAL-005.md) 自动提交当前单号批次并登记同步证据
- [LOCAL-006](local-logic/LOCAL-006.md) 生成失败快照并按成功下载清理
- [LOCAL-009](local-logic/LOCAL-009.md) 精确删除指定供应商批次号码
- [LOCAL-010](local-logic/LOCAL-010.md) 按任务来源交付每次结果及补送
- [LOCAL-011](local-logic/LOCAL-011.md) 识别客户秒挂结果
- [LOCAL-012](local-logic/LOCAL-012.md) 独立记录无话单失败原因
- [LOCAL-013](local-logic/LOCAL-013.md) 处理结果关联、重复、冲突及SIP晚更新
- [LOCAL-015](local-logic/LOCAL-015.md) 查询任务级导入、结果与交付记录
- [LOCAL-016](local-logic/LOCAL-016.md) 创建任务并锁定单一导入来源
- [LOCAL-017](local-logic/LOCAL-017.md) 接收并合并53异步导入失败分片
- [LOCAL-018](local-logic/LOCAL-018.md) 查询应用列表
- [LOCAL-019](local-logic/LOCAL-019.md) 创建应用并提供接入凭证
- [LOCAL-020](local-logic/LOCAL-020.md) 查看指定应用详情与密钥
- [LOCAL-021](local-logic/LOCAL-021.md) 确认删除指定应用

## 字段与完整性

[字段定义](field-specs.md) · [逐项覆盖核对](completeness-matrix.md)
