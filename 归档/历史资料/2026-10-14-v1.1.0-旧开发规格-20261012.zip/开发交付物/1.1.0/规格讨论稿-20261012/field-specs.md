# 字段级逻辑说明

**DRAFT — 供讨论与补充，尚未完成本阶段交接**

[返回阅读入口](README.md) · [按功能阅读](features/README.md)

本文件供按字段查询；先在功能页选择相关字段，再跳到这里阅读完整规则。本包的定义由同一份规划生成。

## 字段范围

模式：field_level

覆盖已批准96项规范字段的现行业务含义和接口/页面引用；明确排除已退出API007来源字段和历史旧树，保留真实供应商物理映射待核。

范围依据：
- product-input.json#PRODUCT-FIELD-MAP

## 字段索引

- [FLD-001](field-specs.md#FLD-001) ImportRecord.r — 来源渠道R
- [FLD-002](field-specs.md#FLD-002) DccRequest.requestId — DCC请求标识
- [FLD-003](field-specs.md#FLD-003) Task.tenantId — 业务租户
- [FLD-004](field-specs.md#FLD-004) Task.supplierTaskId — 原供应商任务号
- [FLD-006](field-specs.md#FLD-006) TenantIdentity.token — 租户业务身份token
- [FLD-007](field-specs.md#FLD-007) ImportRecord.isNewBatch — 是否另开主批次
- [FLD-008](field-specs.md#FLD-008) ImportRecord.leadCode — 线索编码
- [FIELD-PHONE](field-specs.md#FIELD-PHONE) ImportRecord.phone — 客户手机号
- [FLD-009](field-specs.md#FLD-009) ImportRecord.priority — 本次导入优先级
- [FLD-010](field-specs.md#FLD-010) ImportRecord.batchId — 本地本次批次号
- [FLD-011](field-specs.md#FLD-011) ImportRecord.recordId — 本地记录号
- [FLD-013](field-specs.md#FLD-013) ImportRecord.rootBatchId — 关联主批次号
- [FIELD-ROW-ID](field-specs.md#FIELD-ROW-ID) DccRequestRow.rowId — 请求内行定位
- [FIELD-BATCH-KIND](field-specs.md#FIELD-BATCH-KIND) ImportRecord.batchKind — 本地批次归属类型
- [FLD-015](field-specs.md#FLD-015) DccRequestRow.receipt — 原逐行接收回执
- [FLD-020](field-specs.md#FLD-020) ImportRecord.supplierFileId — 本次供应商批次号
- [FLD-021](field-specs.md#FLD-021) SupplierImportResponse.importTotal — 供应商请求号码总数
- [FLD-022](field-specs.md#FLD-022) SupplierImportResponse.invalidTotal — 供应商非法号码数
- [FLD-023](field-specs.md#FLD-023) SupplierImportResponse.successTotal — 供应商成功导入数
- [FLD-025](field-specs.md#FLD-025) SupplierImportResponse.description — 同步响应描述
- [FLD-026](field-specs.md#FLD-026) SupplierImportResponse.result — 同步响应结果码
- [FLD-027](field-specs.md#FLD-027) SupplierIntegration.pushSettings — 供应商推送设置
- [FLD-028](field-specs.md#FLD-028) FailurePushGroup.currentBatchCount — 失败分片序号
- [FLD-029](field-specs.md#FLD-029) SupplierEvidence.enterpriseId — 供应商企业号
- [FLD-030](field-specs.md#FLD-030) ImportFailure.failedReason — 导入失败原始原因
- [FLD-031](field-specs.md#FLD-031) ImportFailure.originalRow — 失败项原始导入数据
- [FLD-033](field-specs.md#FLD-033) SupplierEvidence.fileName — 供应商批次名称
- [FLD-035](field-specs.md#FLD-035) FailurePushGroup.totalBatchCount — 声明失败分片总数
- [FLD-036](field-specs.md#FLD-036) FailurePushGroup.totalFailedCount — 声明失败号码总数
- [FIELD-EVENT-TYPE](field-specs.md#FIELD-EVENT-TYPE) SupplierEvidence.eventType — 供应商事件类型
- [FIELD-EVENT-PAYLOAD](field-specs.md#FIELD-EVENT-PAYLOAD) SupplierEvidence.rawPayload — 供应商原始事件证据
- [FLD-040](field-specs.md#FLD-040) CdrQuery.startTime — 话单查询开始时间
- [FLD-041](field-specs.md#FLD-041) CdrQuery.startTimeEnd — 话单查询结束时间
- [FLD-043](field-specs.md#FLD-043) CallResult.customerBridgeDuration — 客户实际接听时长原值
- [FLD-044](field-specs.md#FLD-044) CallResult.degradeRound — 供应商降级轮次
- [FLD-045](field-specs.md#FLD-045) CallResult.endTime — 通话结束时间原值
- [FLD-046](field-specs.md#FLD-046) CallResult.finishRetryFlag — 供应商最后一条标志
- [FLD-047](field-specs.md#FLD-047) CallResult.obSipCause — obSipCause原字段
- [FLD-048](field-specs.md#FLD-048) CallResult.onHookSource — 挂断来源原字段
- [FLD-049](field-specs.md#FLD-049) CallResult.sipCause — sipCause原字段
- [FLD-050](field-specs.md#FLD-050) CallResult.sipCauseAsyncUpdateFlag — SIP异步更新标志
- [FLD-051](field-specs.md#FLD-051) CallResult.status — 话单原始状态码
- [FIELD-STATUS-DESC](field-specs.md#FIELD-STATUS-DESC) CallResult.statusDesc — 话单状态描述
- [FLD-052](field-specs.md#FLD-052) CallResult.telRetryRound — 供应商号码重试轮次
- [FLD-054](field-specs.md#FLD-054) SupplierDeletion.result — 本次精准删除结果
- [FIELD-OCCURRED-AT](field-specs.md#FIELD-OCCURRED-AT) BusinessResult.occurredAt — 业务结果发生时间
- [FIELD-RESULT-STAGE](field-specs.md#FIELD-RESULT-STAGE) BusinessResult.stage — 业务结果阶段
- [FIELD-RESULT-REASON](field-specs.md#FIELD-RESULT-REASON) BusinessResult.reason — 呼叫或业务结果原因
- [FIELD-CUSTOMER-ANSWERED](field-specs.md#FIELD-CUSTOMER-ANSWERED) CallResult.customerAnswered — 客户真实接听状态
- [FIELD-AGENT-ANSWERED](field-specs.md#FIELD-AGENT-ANSWERED) CallResult.agentAnswered — 坐席实际接听状态
- [FIELD-SHORT-HANGUP](field-specs.md#FIELD-SHORT-HANGUP) CallResult.shortHangup — 秒挂识别结果
- [FLD-066](field-specs.md#FLD-066) BusinessResult.associationId — 真实通话或稳定事件标识
- [FIELD-EVIDENCE-SOURCE](field-specs.md#FIELD-EVIDENCE-SOURCE) SupplierEvidence.source — 结果来源与可信依据
- [FLD-068](field-specs.md#FLD-068) DccDelivery.ack — DCC接收确认
- [FLD-070](field-specs.md#FLD-070) ApplicationListView.keyword — 应用列表查询词
- [FLD-071](field-specs.md#FLD-071) ApplicationListView.total — 应用查询结果总数
- [FIELD-APP-PAGE](field-specs.md#FIELD-APP-PAGE) ApplicationListView.page — 应用列表页码
- [FIELD-APP-ID](field-specs.md#FIELD-APP-ID) Application.appId — 应用标识
- [FIELD-APP-CREATED](field-specs.md#FIELD-APP-CREATED) Application.createdAt — 应用创建时间
- [FLD-089](field-specs.md#FLD-089) Application.authorizedTenantIds — 应用可访问租户
- [FLD-090](field-specs.md#FLD-090) Application.name — 应用名称
- [FLD-093](field-specs.md#FLD-093) Application.appSecret — 应用接入密钥
- [FIELD-ORIGINAL-IMPORT-AT](field-specs.md#FIELD-ORIGINAL-IMPORT-AT) ImportRecord.originalImportDateTime — 原始导入时间
- [FIELD-RECEIVED-AT](field-specs.md#FIELD-RECEIVED-AT) ImportRecord.receivedAt — 本次本地接收时间
- [FIELD-BATCH-CREATED-AT](field-specs.md#FIELD-BATCH-CREATED-AT) ImportRecord.newBatchCreatedAt — 本批次创建时间
- [FIELD-RECEIVED-SEQUENCE](field-specs.md#FIELD-RECEIVED-SEQUENCE) ImportRecord.localReceivedSequence — 本地保存稳定顺序
- [FLD-078](field-specs.md#FLD-078) Task.importSource — 任务导入来源
- [FIELD-SUBMISSION-STATE](field-specs.md#FIELD-SUBMISSION-STATE) ImportRecord.submissionState — 供应商提交状态
- [FIELD-FRAGMENT-COMPLETENESS](field-specs.md#FIELD-FRAGMENT-COMPLETENESS) FailurePushGroup.completeness — 失败分片完整性
- [FIELD-EXPORT-SNAPSHOT](field-specs.md#FIELD-EXPORT-SNAPSHOT) FailureExport.snapshot — 本次失败导出快照
- [FIELD-DOWNLOAD-STATE](field-specs.md#FIELD-DOWNLOAD-STATE) FailureExport.downloadState — 失败快照下载状态
- [FIELD-DEDUP-EVIDENCE](field-specs.md#FIELD-DEDUP-EVIDENCE) BusinessEvidence.dedupAssociationState — 必要去重与关联留存
- [FIELD-DELIVERY-STATE](field-specs.md#FIELD-DELIVERY-STATE) DccDelivery.state — DCC逐次交付状态
- [FIELD-RESULT-VERSION](field-specs.md#FIELD-RESULT-VERSION) BusinessResult.version — 同一结果更新版本
- [FIELD-REVIEW-REASON](field-specs.md#FIELD-REVIEW-REASON) BusinessEvidence.reviewReason — 待核原因
- [FIELD-UNTRUSTED-SIP](field-specs.md#FIELD-UNTRUSTED-SIP) BusinessEvidence.untrustedSipEvidence — 独立未可信SIP证据
- [FIELD-CSV-TEXT](field-specs.md#FIELD-CSV-TEXT) ManualImportDraft.csvText — 手工当前CSV文本
- [FIELD-CSV-PREVIEW](field-specs.md#FIELD-CSV-PREVIEW) ManualImportDraft.preview — 当前有效预览草稿
- [FIELD-DELETION-SELECTION](field-specs.md#FIELD-DELETION-SELECTION) DeletionView.selection — 精准删除当前目标与样例
- [FIELD-DELETION-FEEDBACK](field-specs.md#FIELD-DELETION-FEEDBACK) DeletionView.feedback — 当前删除操作反馈

<a id="FLD-001"></a>

## FLD-001 来源渠道R

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`r`

类型：字符串

格式/枚举/单位/精度：可选来源元数据；未传/null表示无渠道，空串不产生默认渠道；有值原样留存，旧值不得随下载清理。不维护字典，不由R计算priority。

允许 null：True

必填条件：可选来源元数据；未传/null表示无渠道，空串不产生默认渠道；有值原样留存，旧值不得随下载清理。不维护字典，不由R计算priority。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 可选来源元数据；未传/null表示无渠道，空串不产生默认渠道；有值原样留存，旧值不得随下载清理。不维护字典，不由R计算priority。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 已鉴权DCC调用方（接口任务新业务行）
- 既有导入权限运营（仅手工任务提交前草稿）
- 平台接收服务（验证通过后首次保存；保存后不改写本次输入）

### 各状态行为

- 输入或接收：可选来源元数据；未传/null表示无渠道，空串不产生默认渠道；有值原样留存，旧值不得随下载清理。不维护字典，不由R计算priority。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：input

规则：可选来源元数据；未传/null表示无渠道，空串不产生默认渠道；有值原样留存，旧值不得随下载清理。不维护字典，不由R计算priority。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 渠道A

非法/拒绝：
- 不得因未传R拒绝本行

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#FLD-001
- product-input.json#FLD-075
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/7
- pages:PAGE-002/fields/3
- project_facts:PRODUCT-FIELD-MAP/fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/74

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-005

<a id="FLD-002"></a>

## FLD-002 DCC请求标识

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`DccRequest`

字段：`requestId`

类型：字符串

格式/枚举/单位/精度：DCC业务请求必填非空；手工不要求。一次请求可多行，新业务新ID；同ID完整归一内容一致返回原行回执，异内容拒整个重复请求。

允许 null：False

必填条件：DCC业务请求必填非空；手工不要求。一次请求可多行，新业务新ID；同ID完整归一内容一致返回原行回执，异内容拒整个重复请求。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- DCC业务请求必填非空；手工不要求。一次请求可多行，新业务新ID；同ID完整归一内容一致返回原行回执，异内容拒整个重复请求。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 已鉴权且租户/原任务归属通过的DCC调用方（仅新接口业务请求输入；手工入口不提供）
- 平台接收服务（归一并首次保存后只读；运营不得改写）

### 各状态行为

- 输入或接收：DCC业务请求必填非空；手工不要求。一次请求可多行，新业务新ID；同ID完整归一内容一致返回原行回执，异内容拒整个重复请求。
- 校验与确认：仅DCC接口来源任务处理；requestId与稳定行定位不可空，isNewBatch仅省略归一false，显式null/非Boolean拒绝。完整内容先做请求幂等，保存后运营不可编辑，手工不新增这些字段。
- 保存后或操作结束：通过鉴权、任务归属及请求级格式校验的新requestId完成逐行接收判定时，保存规范化请求及完整逐行回执，包含失败/待核行，允许有效行数为零。技术重试返回原回执；异内容同ID拒绝且不覆盖，后有新主不改原batch/root；无记录的失败行不虚构record/batch号。

### 来源与计算

来源类型：input

规则：DCC业务请求必填非空；手工不要求。一次请求可多行，新业务新ID；同ID完整归一内容一致返回原行回执，异内容拒整个重复请求。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：通过鉴权、任务归属及请求级格式校验的新requestId完成逐行接收判定时，保存规范化请求及完整逐行回执，包含失败/待核行，允许有效行数为零。技术重试返回原回执；异内容同ID拒绝且不覆盖，后有新主不改原batch/root；无记录的失败行不虚构record/batch号。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-REQ-101

非法/拒绝：
- 同ID改变priority必须冲突

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-010
- product-input.json#FLD-002
- product-input.json#FLD-012
- product-input.json#FLD-060
- product-input.json#FLD-082
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/4
- interfaces:API-001/response_fields/1
- interfaces:API-010/request_fields/0
- pages:PAGE-002/fields/12
- project_facts:PRODUCT-FIELD-MAP/fields/1
- project_facts:PRODUCT-FIELD-MAP/fields/11
- project_facts:PRODUCT-FIELD-MAP/fields/59
- project_facts:PRODUCT-FIELD-MAP/fields/81

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-047, CHECK-050, CHECK-051

<a id="FLD-003"></a>

## FLD-003 业务租户

单功能页面／局部明确关联：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [交换指定租户身份 · FUNC\-002](features/FUNC-002.md)
- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`Task`

字段：`tenantId`

类型：字符串

格式/枚举/单位/精度：来源于已授权租户身份及任务归属；不可用前台任意值跨租户读写。同租户可多应用，任务不归应用所有。

允许 null：False

必填条件：来源于已授权租户身份及任务归属；不可用前台任意值跨租户读写。同租户可多应用，任务不归应用所有。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 来源于已授权租户身份及任务归属；不可用前台任意值跨租户读写。同租户可多应用，任务不归应用所有。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 任务创建服务依据已授权的当前租户上下文保存；创建后导入或事件不得改写任务租户归属。

### 各状态行为

- 输入或接收：来源于已授权租户身份及任务归属；不可用前台任意值跨租户读写。同租户可多应用，任务不归应用所有。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：input

规则：来源于已授权租户身份及任务归属；不可用前台任意值跨租户读写。同租户可多应用，任务不归应用所有。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：任务创建成功时保存租户归属；DCC请求、供应商企业标识和结果事件仅校验同一归属，不跨租户覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-TENANT-A

非法/拒绝：
- 无权租户拒绝且不创建记录

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-010
- product-input.json#FLD-003
- product-input.json#FLD-014
- product-input.json#FLD-061
- product-input.json#FLD-074
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/1
- interfaces:API-001/response_fields/5
- interfaces:API-010/request_fields/1
- pages:PAGE-002/fields/1
- project_facts:PRODUCT-FIELD-MAP/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/60
- project_facts:PRODUCT-FIELD-MAP/fields/73

局部说明：[LOCAL-001](local-logic/LOCAL-001.md)、[LOCAL-002](local-logic/LOCAL-002.md)、[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-016](local-logic/LOCAL-016.md)

任务：

测试：CHECK-017, CHECK-036, CHECK-049

<a id="FLD-004"></a>

## FLD-004 原供应商任务号

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)

业务对象：`Task`

字段：`supplierTaskId`

类型：标识值

格式/枚举/单位/精度：DCC携原供应商taskId，校验租户任务归属后直接使用，不映射为本地任务号。供应商结果中的taskId必须与本次任务一致。

允许 null：False

必填条件：DCC携原供应商taskId，校验租户任务归属后直接使用，不映射为本地任务号。供应商结果中的taskId必须与本次任务一致。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- DCC携原供应商taskId，校验租户任务归属后直接使用，不映射为本地任务号。供应商结果中的taskId必须与本次任务一致。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 任务创建服务仅在任务创建成功并核对实际供应商任务归属时保存；创建后任何DCC请求或供应商响应均不得改写目标任务号。

### 各状态行为

- 创建成功：保存与当前租户绑定的实际供应商任务号；不得拿本地任务ID冒充。
- DCC接收与供应商提交：校验并原值使用已保存任务号；调用方不得重新指定其他任务覆盖该对象。
- 响应与事件：响应中的任务号必须与当前请求原任务一致；冲突留待核证据，不改锁定值。

### 来源与计算

来源类型：external

规则：DCC携原供应商taskId，校验租户任务归属后直接使用，不映射为本地任务号。供应商结果中的taskId必须与本次任务一致。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：任务创建成功时保存并锁定原供应商taskId。后续DCC请求只核对是否命中同租户原任务；导入响应和事件中的taskId只用于精确匹配及原证据留存，不更新Task.supplierTaskId。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-TASK-A

非法/拒绝：
- 跨任务结果不挂当前记录

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-002
- product-input.json#API-003
- product-input.json#API-004
- product-input.json#API-006
- product-input.json#API-010
- product-input.json#FLD-004
- product-input.json#FLD-014
- product-input.json#FLD-017
- product-input.json#FLD-024
- product-input.json#FLD-034
- product-input.json#FLD-042
- product-input.json#FLD-053
- product-input.json#FLD-061
- product-input.json#FLD-074
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/3
- interfaces:API-001/response_fields/5
- interfaces:API-002/request_fields/0
- interfaces:API-002/response_fields/3
- interfaces:API-003/response_fields/4
- interfaces:API-004/request_fields/2
- interfaces:API-006/request_fields/0
- interfaces:API-010/request_fields/1
- pages:PAGE-002/fields/1
- project_facts:PRODUCT-FIELD-MAP/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/16
- project_facts:PRODUCT-FIELD-MAP/fields/23
- project_facts:PRODUCT-FIELD-MAP/fields/3
- project_facts:PRODUCT-FIELD-MAP/fields/33
- project_facts:PRODUCT-FIELD-MAP/fields/41
- project_facts:PRODUCT-FIELD-MAP/fields/52
- project_facts:PRODUCT-FIELD-MAP/fields/60
- project_facts:PRODUCT-FIELD-MAP/fields/73

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-016](local-logic/LOCAL-016.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-012, CHECK-036, CHECK-049

<a id="FLD-006"></a>

## FLD-006 租户业务身份token

单功能页面／局部明确关联：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [交换指定租户身份 · FUNC\-002](features/FUNC-002.md)
- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

业务对象：`TenantIdentity`

字段：`token`

类型：不透明凭证

格式/枚举/单位/精度：应用凭证与授权tenantId成功校验后发放指定租户身份；尚未获取/失败不伪造token。只赋予租户业务权，不授予应用管理权。真实格式、时效、撤权失效由工程落实；仅合成已验证。

允许 null：True

必填条件：应用凭证与授权tenantId成功校验后发放指定租户身份；尚未获取/失败不伪造token。只赋予租户业务权，不授予应用管理权。真实格式、时效、撤权失效由工程落实；仅合成已验证。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 应用凭证与授权tenantId成功校验后发放指定租户身份；尚未获取/失败不伪造token。只赋予租户业务权，不授予应用管理权。真实格式、时效、撤权失效由工程落实；仅合成已验证。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 受权后台集成与鉴权服务

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：应用凭证与授权tenantId成功校验后发放指定租户身份；尚未获取/失败不伪造token。只赋予租户业务权，不授予应用管理权。真实格式、时效、撤权失效由工程落实；仅合成已验证。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：system

规则：应用凭证与授权tenantId成功校验后发放指定租户身份；尚未获取/失败不伪造token。只赋予租户业务权，不授予应用管理权。真实格式、时效、撤权失效由工程落实；仅合成已验证。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-ONLY-TOKEN

非法/拒绝：
- 凭业务token读应用管理列表必须拒绝

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#FLD-006
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/5

局部说明：[LOCAL-001](local-logic/LOCAL-001.md)、[LOCAL-002](local-logic/LOCAL-002.md)、[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-021](local-logic/LOCAL-021.md)

任务：

测试：CHECK-017, CHECK-044, CHECK-045, CHECK-056, CHECK-057

<a id="FLD-007"></a>

## FLD-007 是否另开主批次

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`isNewBatch`

类型：布尔

格式/枚举/单位/精度：仅DCC行适用；省略归一false，显式值只能Boolean，null/字符串不当false。true另开主；false有主新子、无主自动首主；仅决定本地主关联。手工不增加此输入。

允许 null：False

必填条件：仅DCC行适用；省略归一false，显式值只能Boolean，null/字符串不当false。true另开主；false有主新子、无主自动首主；仅决定本地主关联。手工不增加此输入。

### 默认与初始化

模式：literal；值：`false`

每个DCC请求行（包括同requestId技术重传）在完整有效内容比较前，将省略的isNewBatch归一为false；显式null或非Boolean拒绝该非法值，不套默认。手工来源不增加该字段。

### 校验与关联约束

- 仅DCC行适用；省略归一false，显式值只能Boolean，null/字符串不当false。true另开主；false有主新子、无主自动首主；仅决定本地主关联。手工不增加此输入。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 已鉴权且租户/原任务归属通过的DCC调用方（仅新接口业务请求输入；手工入口不提供）
- 平台接收服务（归一并首次保存后只读；运营不得改写）

### 各状态行为

- 输入或接收：仅DCC行适用；省略归一false，显式值只能Boolean，null/字符串不当false。true另开主；false有主新子、无主自动首主；仅决定本地主关联。手工不增加此输入。
- 校验与确认：仅DCC接口来源任务处理；requestId与稳定行定位不可空，isNewBatch仅省略归一false，显式null/非Boolean拒绝。完整内容先做请求幂等，保存后运营不可编辑，手工不新增这些字段。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：input

规则：仅DCC行适用；省略归一false，显式值只能Boolean，null/字符串不当false。true另开主；false有主新子、无主自动首主；仅决定本地主关联。手工不增加此输入。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- true；false；省略归一false

非法/拒绝：
- 字符串false和null拒绝该行

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#FLD-007
- product-input.json#FLD-014
- product-input.json#FLD-082
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/6
- interfaces:API-001/response_fields/5
- pages:PAGE-002/fields/12
- project_facts:PRODUCT-FIELD-MAP/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/81

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-047, CHECK-048, CHECK-049, CHECK-050, CHECK-051

<a id="FLD-008"></a>

## FLD-008 线索编码

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`leadCode`

类型：字符串

格式/枚举/单位/精度：DCC与手工有效行均必填非空；DCC在tenant/原任务/leadCode组内固定同phone。不同合法租户任务隔离；不能用leadCode单独定位供应商结果。

允许 null：False

必填条件：DCC与手工有效行均必填非空；DCC在tenant/原任务/leadCode组内固定同phone。不同合法租户任务隔离；不能用leadCode单独定位供应商结果。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- DCC与手工有效行均必填非空；DCC在tenant/原任务/leadCode组内固定同phone。不同合法租户任务隔离；不能用leadCode单独定位供应商结果。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 已鉴权DCC调用方（接口任务新业务行）
- 既有导入权限运营（仅手工任务提交前草稿）
- 平台接收服务（验证通过后首次保存；保存后不改写本次输入）

### 各状态行为

- 输入或接收：DCC与手工有效行均必填非空；DCC在tenant/原任务/leadCode组内固定同phone。不同合法租户任务隔离；不能用leadCode单独定位供应商结果。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：input

规则：DCC与手工有效行均必填非空；DCC在tenant/原任务/leadCode组内固定同phone。不同合法租户任务隔离；不能用leadCode单独定位供应商结果。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-LEAD-001

非法/拒绝：
- 空值拒绝；同组改号拒绝或待核

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-010
- product-input.json#FLD-008
- product-input.json#FLD-014
- product-input.json#FLD-061
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/5
- interfaces:API-001/response_fields/5
- interfaces:API-010/request_fields/1
- pages:PAGE-002/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/60
- project_facts:PRODUCT-FIELD-MAP/fields/7
- project_facts:PRODUCT-FIELD-MAP/fields/84

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-001, CHECK-031, CHECK-049, CHECK-052

<a id="FIELD-PHONE"></a>

## FIELD-PHONE 客户手机号

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`phone`

类型：字符串

格式/枚举/单位/精度：每有效新行一个号码和独立批次，按当前范围校验有效号码；保留原始输入证据。DCC同租户原任务线索组固定手机号，多lead同phone关系未决保持待核，不由新主绕过。国际区号/正规化规则由工程核对既有输入契约。

允许 null：False

必填条件：每有效新行一个号码和独立批次，按当前范围校验有效号码；保留原始输入证据。DCC同租户原任务线索组固定手机号，多lead同phone关系未决保持待核，不由新主绕过。国际区号/正规化规则由工程核对既有输入契约。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 每有效新行一个号码和独立批次，按当前范围校验有效号码；保留原始输入证据。DCC同租户原任务线索组固定手机号，多lead同phone关系未决保持待核，不由新主绕过。国际区号/正规化规则由工程核对既有输入契约。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 已鉴权DCC调用方（接口任务新业务行）
- 既有导入权限运营（仅手工任务提交前草稿）
- 平台接收服务（验证通过后首次保存；保存后不改写本次输入）

### 各状态行为

- 输入或接收：每有效新行一个号码和独立批次，按当前范围校验有效号码；保留原始输入证据。DCC同租户原任务线索组固定手机号，多lead同phone关系未决保持待核，不由新主绕过。国际区号/正规化规则由工程核对既有输入契约。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：input

规则：每有效新行一个号码和独立批次，按当前范围校验有效号码；保留原始输入证据。DCC同租户原任务线索组固定手机号，多lead同phone关系未决保持待核，不由新主绕过。国际区号/正规化规则由工程核对既有输入契约。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 13800000001（合成）

非法/拒绝：
- 缺号或格式明显非法拒绝该行；不按最近同号盲配

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-002
- product-input.json#API-004
- product-input.json#API-006
- product-input.json#API-010
- product-input.json#FLD-008
- product-input.json#FLD-014
- product-input.json#FLD-019
- product-input.json#FLD-042
- product-input.json#FLD-053
- product-input.json#FLD-061
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/5
- interfaces:API-001/response_fields/5
- interfaces:API-002/request_fields/1
- interfaces:API-004/request_fields/2
- interfaces:API-006/request_fields/0
- interfaces:API-010/request_fields/1
- pages:PAGE-002/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/18
- project_facts:PRODUCT-FIELD-MAP/fields/41
- project_facts:PRODUCT-FIELD-MAP/fields/52
- project_facts:PRODUCT-FIELD-MAP/fields/60
- project_facts:PRODUCT-FIELD-MAP/fields/7
- project_facts:PRODUCT-FIELD-MAP/fields/84

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-001, CHECK-006, CHECK-049, CHECK-052

<a id="FLD-009"></a>

## FLD-009 本次导入优先级

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`priority`

类型：数值

格式/枚举/单位/精度：DCC本次每行必填无默认，手工按提交前统一或逐行最终值；高值先提交，同级FIFO，仅本任务待提交。保存后不人工改、不继承旧值、不每日衰减。供应商文档上限999999；生产最小值/整数约束由工程核验，不将demo范围当业务确认。

允许 null：False

必填条件：DCC本次每行必填无默认，手工按提交前统一或逐行最终值；高值先提交，同级FIFO，仅本任务待提交。保存后不人工改、不继承旧值、不每日衰减。供应商文档上限999999；生产最小值/整数约束由工程核验，不将demo范围当业务确认。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- DCC本次每行必填无默认，手工按提交前统一或逐行最终值；高值先提交，同级FIFO，仅本任务待提交。保存后不人工改、不继承旧值、不每日衰减。供应商文档上限999999；生产最小值/整数约束由工程核验，不将demo范围当业务确认。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 已鉴权DCC调用方（接口任务新业务行）
- 既有导入权限运营（仅手工任务提交前草稿）
- 平台接收服务（验证通过后首次保存；保存后不改写本次输入）

### 各状态行为

- 输入或接收：DCC本次每行必填无默认，手工按提交前统一或逐行最终值；高值先提交，同级FIFO，仅本任务待提交。保存后不人工改、不继承旧值、不每日衰减。供应商文档上限999999；生产最小值/整数约束由工程核验，不将demo范围当业务确认。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：input

规则：DCC本次每行必填无默认，手工按提交前统一或逐行最终值；高值先提交，同级FIFO，仅本任务待提交。保存后不人工改、不继承旧值、不每日衰减。供应商文档上限999999；生产最小值/整数约束由工程核验，不将demo范围当业务确认。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 100；本次200不继承旧100

非法/拒绝：
- 缺失或非数值拒绝；跨日自动减值禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-002
- product-input.json#FLD-009
- product-input.json#FLD-018
- product-input.json#FLD-075
- product-input.json#FLD-080
- product-input.json#FLD-081
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/8
- interfaces:API-002/request_fields/2
- pages:PAGE-002/fields/11
- pages:PAGE-002/fields/13
- pages:PAGE-002/fields/3
- project_facts:PRODUCT-FIELD-MAP/fields/17
- project_facts:PRODUCT-FIELD-MAP/fields/74
- project_facts:PRODUCT-FIELD-MAP/fields/79
- project_facts:PRODUCT-FIELD-MAP/fields/8
- project_facts:PRODUCT-FIELD-MAP/fields/80

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-009, CHECK-014, CHECK-030, CHECK-032, CHECK-046

<a id="FLD-010"></a>

## FLD-010 本地本次批次号

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`batchId`

类型：字符串

格式/枚举/单位/精度：每有效新业务行生成独立单手机号批次；同请求重试复用原号。主与子均拥有独立编号；不是供应商fileId，不产生第三层本地批次。

允许 null：False

必填条件：每有效新业务行生成独立单手机号批次；同请求重试复用原号。主与子均拥有独立编号；不是供应商fileId，不产生第三层本地批次。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 每有效新业务行生成独立单手机号批次；同请求重试复用原号。主与子均拥有独立编号；不是供应商fileId，不产生第三层本地批次。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：每有效新业务行生成独立单手机号批次；同请求重试复用原号。主与子均拥有独立编号；不是供应商fileId，不产生第三层本地批次。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：system

规则：每有效新业务行生成独立单手机号批次；同请求重试复用原号。主与子均拥有独立编号；不是供应商fileId，不产生第三层本地批次。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-BATCH-002

非法/拒绝：
- 不同新业务覆盖旧batchId禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-010
- product-input.json#FLD-010
- product-input.json#FLD-065
- product-input.json#FLD-079
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/response_fields/3
- interfaces:API-010/request_fields/3
- pages:PAGE-002/fields/14
- pages:PAGE-002/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/64
- project_facts:PRODUCT-FIELD-MAP/fields/78
- project_facts:PRODUCT-FIELD-MAP/fields/84
- project_facts:PRODUCT-FIELD-MAP/fields/9

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-006, CHECK-047, CHECK-048, CHECK-052

<a id="FLD-011"></a>

## FLD-011 本地记录号

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`recordId`

类型：字符串

格式/枚举/单位/精度：有效新业务行保存时生成独立记录号；失败未保存行不伪造已创建编号。技术重试返回原记录；删除供应商号码及下载失败明细不删除此记录。

允许 null：False

必填条件：有效新业务行保存时生成独立记录号；失败未保存行不伪造已创建编号。技术重试返回原记录；删除供应商号码及下载失败明细不删除此记录。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 有效新业务行保存时生成独立记录号；失败未保存行不伪造已创建编号。技术重试返回原记录；删除供应商号码及下载失败明细不删除此记录。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：有效新业务行保存时生成独立记录号；失败未保存行不伪造已创建编号。技术重试返回原记录；删除供应商号码及下载失败明细不删除此记录。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：system

规则：有效新业务行保存时生成独立记录号；失败未保存行不伪造已创建编号。技术重试返回原记录；删除供应商号码及下载失败明细不删除此记录。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-RECORD-002

非法/拒绝：
- 技术重试生成新recordId禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-010
- product-input.json#FLD-011
- product-input.json#FLD-059
- product-input.json#FLD-079
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/response_fields/2
- interfaces:API-010/request_fields/2
- pages:PAGE-002/fields/14
- pages:PAGE-002/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/10
- project_facts:PRODUCT-FIELD-MAP/fields/58
- project_facts:PRODUCT-FIELD-MAP/fields/78
- project_facts:PRODUCT-FIELD-MAP/fields/84

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-006, CHECK-047, CHECK-052

<a id="FLD-013"></a>

## FLD-013 关联主批次号

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`rootBatchId`

类型：字符串

格式/枚举/单位/精度：DCC有效行保存主归属：主批root=自身batch；子root=同组最近已保存主的batch。最近按主批保存稳定顺序；子直接挂主，不挂上一子。旧回执/结果永远读已存root，不随新主变化；手工无DCC主子协议。

允许 null：True

必填条件：DCC有效行保存主归属：主批root=自身batch；子root=同组最近已保存主的batch。最近按主批保存稳定顺序；子直接挂主，不挂上一子。旧回执/结果永远读已存root，不随新主变化；手工无DCC主子协议。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- DCC有效行保存主归属：主批root=自身batch；子root=同组最近已保存主的batch。最近按主批保存稳定顺序；子直接挂主，不挂上一子。旧回执/结果永远读已存root，不随新主变化；手工无DCC主子协议。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：DCC有效行保存主归属：主批root=自身batch；子root=同组最近已保存主的batch。最近按主批保存稳定顺序；子直接挂主，不挂上一子。旧回执/结果永远读已存root，不随新主变化；手工无DCC主子协议。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：system

规则：DCC有效行保存主归属：主批root=自身batch；子root=同组最近已保存主的batch。最近按主批保存稳定顺序；子直接挂主，不挂上一子。旧回执/结果永远读已存root，不随新主变化；手工无DCC主子协议。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 子B002的root=B001

非法/拒绝：
- 用最近同号/结果时间选根或重算旧根禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-010
- product-input.json#FLD-013
- product-input.json#FLD-064
- product-input.json#FLD-082
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/response_fields/4
- interfaces:API-010/request_fields/4
- pages:PAGE-002/fields/12
- pages:PAGE-002/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/12
- project_facts:PRODUCT-FIELD-MAP/fields/63
- project_facts:PRODUCT-FIELD-MAP/fields/81
- project_facts:PRODUCT-FIELD-MAP/fields/84

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-048, CHECK-050, CHECK-052

<a id="FIELD-ROW-ID"></a>

## FIELD-ROW-ID 请求内行定位

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`DccRequestRow`

字段：`rowId`

类型：标识值

格式/枚举/单位/精度：DCC请求内每行必须可稳定定位，回执和回传以requestId+行定位找到原行，手工不要求此DCC协议。具体序号或客户行键形式由接口工程定，不能仅手机号代替。

允许 null：False

必填条件：DCC请求内每行必须可稳定定位，回执和回传以requestId+行定位找到原行，手工不要求此DCC协议。具体序号或客户行键形式由接口工程定，不能仅手机号代替。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- DCC请求内每行必须可稳定定位，回执和回传以requestId+行定位找到原行，手工不要求此DCC协议。具体序号或客户行键形式由接口工程定，不能仅手机号代替。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 已鉴权且租户/原任务归属通过的DCC调用方（仅新接口业务请求输入；手工入口不提供）
- 平台接收服务（归一并首次保存后只读；运营不得改写）

### 各状态行为

- 输入或接收：DCC请求内每行必须可稳定定位，回执和回传以requestId+行定位找到原行，手工不要求此DCC协议。具体序号或客户行键形式由接口工程定，不能仅手机号代替。
- 校验与确认：仅DCC接口来源任务处理；requestId与稳定行定位不可空，isNewBatch仅省略归一false，显式null/非Boolean拒绝。完整内容先做请求幂等，保存后运营不可编辑，手工不新增这些字段。
- 保存后或操作结束：通过鉴权、任务归属及请求级格式校验的新requestId完成逐行接收判定时，保存规范化请求及完整逐行回执，包含失败/待核行，允许有效行数为零。技术重试返回原回执；异内容同ID拒绝且不覆盖，后有新主不改原batch/root；无记录的失败行不虚构record/batch号。

### 来源与计算

来源类型：input

规则：DCC请求内每行必须可稳定定位，回执和回传以requestId+行定位找到原行，手工不要求此DCC协议。具体序号或客户行键形式由接口工程定，不能仅手机号代替。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：通过鉴权、任务归属及请求级格式校验的新requestId完成逐行接收判定时，保存规范化请求及完整逐行回执，包含失败/待核行，允许有效行数为零。技术重试返回原回执；异内容同ID拒绝且不覆盖，后有新主不改原batch/root；无记录的失败行不虚构record/batch号。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-ROW-01

非法/拒绝：
- 同请求无法区分两行时拒绝或待核

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#API-010
- product-input.json#FLD-015
- product-input.json#FLD-061
- product-input.json#FLD-082
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/response_fields/0
- interfaces:API-010/request_fields/1
- pages:PAGE-002/fields/12
- project_facts:PRODUCT-FIELD-MAP/fields/14
- project_facts:PRODUCT-FIELD-MAP/fields/60
- project_facts:PRODUCT-FIELD-MAP/fields/81

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-047, CHECK-050, CHECK-051, CHECK-052

<a id="FIELD-BATCH-KIND"></a>

## FIELD-BATCH-KIND 本地批次归属类型

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`batchKind`

类型：枚举

格式/枚举/单位/精度：业务显示主批/子批/手工独立；仅DCC按isNewBatch及既有已保存主选择。手工独立批次不被强制纳入DCC归组。

允许 null：False

必填条件：业务显示主批/子批/手工独立；仅DCC按isNewBatch及既有已保存主选择。手工独立批次不被强制纳入DCC归组。

### 默认与初始化

模式：derived；值：`null`

业务显示主批/子批/手工独立；仅DCC按isNewBatch及既有已保存主选择。手工独立批次不被强制纳入DCC归组。

### 校验与关联约束

- 业务显示主批/子批/手工独立；仅DCC按isNewBatch及既有已保存主选择。手工独立批次不被强制纳入DCC归组。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：业务显示主批/子批/手工独立；仅DCC按isNewBatch及既有已保存主选择。手工独立批次不被强制纳入DCC归组。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：calculated

规则：业务显示主批/子批/手工独立；仅DCC按isNewBatch及既有已保存主选择。手工独立批次不被强制纳入DCC归组。

依赖字段：[FLD-007](field-specs.md#FLD-007)、[FLD-010](field-specs.md#FLD-010)、[FLD-013](field-specs.md#FLD-013)、[FLD-078](field-specs.md#FLD-078)

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 主批；子批；手工独立

非法/拒绝：
- 把供应商失败分片称为子批禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#FLD-014
- product-input.json#FLD-082
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/response_fields/5
- pages:PAGE-002/fields/12
- pages:PAGE-002/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/81
- project_facts:PRODUCT-FIELD-MAP/fields/84

局部说明：[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-048, CHECK-052

<a id="FLD-015"></a>

## FLD-015 原逐行接收回执

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`DccRequestRow`

字段：`receipt`

类型：对象

格式/枚举/单位/精度：保存该行的接收成功/失败/待核及原因、行定位和实际已建record/batch/root；未建对象不补号。技术重试返回原逐行结果，原失败也不重新分配；具体编码结构待工程定义。

允许 null：False

必填条件：保存该行的接收成功/失败/待核及原因、行定位和实际已建record/batch/root；未建对象不补号。技术重试返回原逐行结果，原失败也不重新分配；具体编码结构待工程定义。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存该行的接收成功/失败/待核及原因、行定位和实际已建record/batch/root；未建对象不补号。技术重试返回原逐行结果，原失败也不重新分配；具体编码结构待工程定义。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：保存该行的接收成功/失败/待核及原因、行定位和实际已建record/batch/root；未建对象不补号。技术重试返回原逐行结果，原失败也不重新分配；具体编码结构待工程定义。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：通过鉴权、任务归属及请求级格式校验的新requestId完成逐行接收判定时，保存规范化请求及完整逐行回执，包含失败/待核行，允许有效行数为零。技术重试返回原回执；异内容同ID拒绝且不覆盖，后有新主不改原batch/root；无记录的失败行不虚构record/batch号。

### 来源与计算

来源类型：system

规则：保存该行的接收成功/失败/待核及原因、行定位和实际已建record/batch/root；未建对象不补号。技术重试返回原逐行结果，原失败也不重新分配；具体编码结构待工程定义。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：通过鉴权、任务归属及请求级格式校验的新requestId完成逐行接收判定时，保存规范化请求及完整逐行回执，包含失败/待核行，允许有效行数为零。技术重试返回原回执；异内容同ID拒绝且不覆盖，后有新主不改原batch/root；无记录的失败行不虚构record/batch号。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 成功行原映射；失败行原原因

非法/拒绝：
- 新主出现后重传改root禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#FLD-015
- product-input.json#FLD-082
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/response_fields/0
- pages:PAGE-002/fields/12
- project_facts:PRODUCT-FIELD-MAP/fields/14
- project_facts:PRODUCT-FIELD-MAP/fields/81

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-007, CHECK-047, CHECK-050, CHECK-051

<a id="FLD-020"></a>

## FLD-020 本次供应商批次号

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`ImportRecord`

字段：`supplierFileId`

类型：供应商标识值

格式/枚举/单位/精度：保存本次真实导入响应fileId映射；未返回为空并待核，不能拿本地root/batch补值。新业务导入不传旧fileId追加；同号多次分别保存各次映射。供应商接收/排重兼容仍待联调，不以本地生成号证明已接收。

允许 null：True

必填条件：保存本次真实导入响应fileId映射；未返回为空并待核，不能拿本地root/batch补值。新业务导入不传旧fileId追加；同号多次分别保存各次映射。供应商接收/排重兼容仍待联调，不以本地生成号证明已接收。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存本次真实导入响应fileId映射；未返回为空并待核，不能拿本地root/batch补值。新业务导入不传旧fileId追加；同号多次分别保存各次映射。供应商接收/排重兼容仍待联调，不以本地生成号证明已接收。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存本次真实导入响应fileId映射；未返回为空并待核，不能拿本地root/batch补值。新业务导入不传旧fileId追加；同号多次分别保存各次映射。供应商接收/排重兼容仍待联调，不以本地生成号证明已接收。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 来源与计算

来源类型：external

规则：保存本次真实导入响应fileId映射；未返回为空并待核，不能拿本地root/batch补值。新业务导入不传旧fileId追加；同号多次分别保存各次映射。供应商接收/排重兼容仍待联调，不以本地生成号证明已接收。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 本地B002对应供应商F102

非法/拒绝：
- 缺fileId时用B001作供应商批次禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-002
- product-input.json#API-003
- product-input.json#API-004
- product-input.json#API-006
- product-input.json#FLD-016
- product-input.json#FLD-020
- product-input.json#FLD-032
- product-input.json#FLD-042
- product-input.json#FLD-053
- product-input.json#FLD-073
- product-input.json#FLD-079
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-002/request_fields/3
- interfaces:API-002/response_fields/2
- interfaces:API-003/response_fields/5
- interfaces:API-004/request_fields/2
- interfaces:API-006/request_fields/0
- pages:PAGE-002/fields/14
- pages:PAGE-002/fields/2
- pages:PAGE-002/fields/8
- project_facts:PRODUCT-FIELD-MAP/fields/15
- project_facts:PRODUCT-FIELD-MAP/fields/19
- project_facts:PRODUCT-FIELD-MAP/fields/31
- project_facts:PRODUCT-FIELD-MAP/fields/41
- project_facts:PRODUCT-FIELD-MAP/fields/52
- project_facts:PRODUCT-FIELD-MAP/fields/72
- project_facts:PRODUCT-FIELD-MAP/fields/78
- project_facts:PRODUCT-FIELD-MAP/fields/84

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-012, CHECK-039, CHECK-040, CHECK-052

<a id="FLD-021"></a>

## FLD-021 供应商请求号码总数

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierImportResponse`

字段：`importTotal`

类型：整数

格式/枚举/单位/精度：保留供应商同步原始请求总数和来源；缺失=null/未知，不当0。非负计数，矛盾值保留待核，不臆造总数恒等式或任意分配成功行。

允许 null：True

必填条件：保留供应商同步原始请求总数和来源；缺失=null/未知，不当0。非负计数，矛盾值保留待核，不臆造总数恒等式或任意分配成功行。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留供应商同步原始请求总数和来源；缺失=null/未知，不当0。非负计数，矛盾值保留待核，不臆造总数恒等式或任意分配成功行。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留供应商同步原始请求总数和来源；缺失=null/未知，不当0。非负计数，矛盾值保留待核，不臆造总数恒等式或任意分配成功行。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 来源与计算

来源类型：external

规则：保留供应商同步原始请求总数和来源；缺失=null/未知，不当0。非负计数，矛盾值保留待核，不臆造总数恒等式或任意分配成功行。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 1；0为明确返回的零

非法/拒绝：
- 缺失显示0或负数当有效禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-002
- product-input.json#FLD-021
- product-input.json#FLD-076
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-002/response_fields/4
- pages:PAGE-002/fields/7
- project_facts:PRODUCT-FIELD-MAP/fields/20
- project_facts:PRODUCT-FIELD-MAP/fields/75

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-039, CHECK-043

<a id="FLD-022"></a>

## FLD-022 供应商非法号码数

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierImportResponse`

字段：`invalidTotal`

类型：整数

格式/枚举/单位/精度：保留同步原始非法号码数；缺失与0区分，不推断未指明号码的失败归属；负数/矛盾保持原证据待核。

允许 null：True

必填条件：保留同步原始非法号码数；缺失与0区分，不推断未指明号码的失败归属；负数/矛盾保持原证据待核。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留同步原始非法号码数；缺失与0区分，不推断未指明号码的失败归属；负数/矛盾保持原证据待核。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留同步原始非法号码数；缺失与0区分，不推断未指明号码的失败归属；负数/矛盾保持原证据待核。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 来源与计算

来源类型：external

规则：保留同步原始非法号码数；缺失与0区分，不推断未指明号码的失败归属；负数/矛盾保持原证据待核。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 0；1

非法/拒绝：
- 凭汇总1任意指定某行失败禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-002
- product-input.json#FLD-022
- product-input.json#FLD-076
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-002/response_fields/6
- pages:PAGE-002/fields/7
- project_facts:PRODUCT-FIELD-MAP/fields/21
- project_facts:PRODUCT-FIELD-MAP/fields/75

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-039, CHECK-043

<a id="FLD-023"></a>

## FLD-023 供应商成功导入数

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierImportResponse`

字段：`successTotal`

类型：整数

格式/枚举/单位/精度：保留同步原始成功数量及来源，有准确证据正常标成功，仅汇总不能任意指定成功行；未知不概称全成功或仅受理。

允许 null：True

必填条件：保留同步原始成功数量及来源，有准确证据正常标成功，仅汇总不能任意指定成功行；未知不概称全成功或仅受理。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留同步原始成功数量及来源，有准确证据正常标成功，仅汇总不能任意指定成功行；未知不概称全成功或仅受理。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留同步原始成功数量及来源，有准确证据正常标成功，仅汇总不能任意指定成功行；未知不概称全成功或仅受理。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 来源与计算

来源类型：external

规则：保留同步原始成功数量及来源，有准确证据正常标成功，仅汇总不能任意指定成功行；未知不概称全成功或仅受理。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 1；0

非法/拒绝：
- result=0直接填满全行成功禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-002
- product-input.json#FLD-023
- product-input.json#FLD-076
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-002/response_fields/5
- pages:PAGE-002/fields/7
- project_facts:PRODUCT-FIELD-MAP/fields/22
- project_facts:PRODUCT-FIELD-MAP/fields/75

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-039, CHECK-043

<a id="FLD-025"></a>

## FLD-025 同步响应描述

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)

业务对象：`SupplierImportResponse`

字段：`description`

类型：字符串

格式/枚举/单位/精度：供应商同步原始描述留存与显示；缺失明确无描述，不能编造供应商失败原因。与结果码和本次批次证据一起解释。

允许 null：True

必填条件：供应商同步原始描述留存与显示；缺失明确无描述，不能编造供应商失败原因。与结果码和本次批次证据一起解释。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 供应商同步原始描述留存与显示；缺失明确无描述，不能编造供应商失败原因。与结果码和本次批次证据一起解释。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：供应商同步原始描述留存与显示；缺失明确无描述，不能编造供应商失败原因。与结果码和本次批次证据一起解释。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 来源与计算

来源类型：external

规则：供应商同步原始描述留存与显示；缺失明确无描述，不能编造供应商失败原因。与结果码和本次批次证据一起解释。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 合成：号码格式错误

非法/拒绝：
- 无描述时生成虚构真实原因禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-002
- product-input.json#FLD-025
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-002/response_fields/1
- project_facts:PRODUCT-FIELD-MAP/fields/24

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)

任务：

测试：CHECK-013, CHECK-039

<a id="FLD-026"></a>

## FLD-026 同步响应结果码

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)

业务对象：`SupplierImportResponse`

字段：`result`

类型：供应商原始码

格式/枚举/单位/精度：保留原值；已知result=0不等逐行全成功；缺失/未知或与数量冲突待核。生产类型和其他码由接口契约落实。

允许 null：True

必填条件：保留原值；已知result=0不等逐行全成功；缺失/未知或与数量冲突待核。生产类型和其他码由接口契约落实。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留原值；已知result=0不等逐行全成功；缺失/未知或与数量冲突待核。生产类型和其他码由接口契约落实。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留原值；已知result=0不等逐行全成功；缺失/未知或与数量冲突待核。生产类型和其他码由接口契约落实。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 来源与计算

来源类型：external

规则：保留原值；已知result=0不等逐行全成功；缺失/未知或与数量冲突待核。生产类型和其他码由接口契约落实。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 0（仅响应码）

非法/拒绝：
- 把0等同所有行导入成功禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-002
- product-input.json#FLD-026
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-002/response_fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/25

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)

任务：

测试：CHECK-013, CHECK-039

<a id="FLD-027"></a>

## FLD-027 供应商推送设置

单功能页面／局部明确关联：

- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierIntegration`

字段：`pushSettings`

类型：配置对象

格式/枚举/单位/精度：来源是供应商创建推送配置能力，非完整回调契约。平台产品仅依赖可接收可信事件，不新增运营前台配置；配置形状/认证/ACK/推送组标识待工程核实。

允许 null：True

必填条件：来源是供应商创建推送配置能力，非完整回调契约。平台产品仅依赖可接收可信事件，不新增运营前台配置；配置形状/认证/ACK/推送组标识待工程核实。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 来源是供应商创建推送配置能力，非完整回调契约。平台产品仅依赖可接收可信事件，不新增运营前台配置；配置形状/认证/ACK/推送组标识待工程核实。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 受权后台集成与鉴权服务

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：来源是供应商创建推送配置能力，非完整回调契约。平台产品仅依赖可接收可信事件，不新增运营前台配置；配置形状/认证/ACK/推送组标识待工程核实。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：仅外部供应商拥有配置，平台保留核实引用；不在日常前台创建或修改推送设置，不把计划配置视为已执行。

### 来源与计算

来源类型：external

规则：来源是供应商创建推送配置能力，非完整回调契约。平台产品仅依赖可接收可信事件，不新增运营前台配置；配置形状/认证/ACK/推送组标识待工程核实。

依赖字段：无

### 保存与更新

方式：external

物理映射：由开发补充

业务保存或更新时机：仅外部供应商拥有配置，平台保留核实引用；不在日常前台创建或修改推送设置，不把计划配置视为已执行。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 已核实订阅53事件的配置证据

非法/拒绝：
- 把配置文档当已验证完整回调契约禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-027
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/request_fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/26

局部说明：[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-003, CHECK-040

<a id="FLD-028"></a>

## FLD-028 失败分片序号

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`FailurePushGroup`

字段：`currentBatchCount`

类型：整数

格式/枚举/单位/精度：供应商53失败推送片号，须与声明总片数一致；重复片不新增，乱序迟到保留，冲突待核。不是业务批次；未收到不推定0失败。编号起点以真实协议核验。

允许 null：True

必填条件：供应商53失败推送片号，须与声明总片数一致；重复片不新增，乱序迟到保留，冲突待核。不是业务批次；未收到不推定0失败。编号起点以真实协议核验。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 供应商53失败推送片号，须与声明总片数一致；重复片不新增，乱序迟到保留，冲突待核。不是业务批次；未收到不推定0失败。编号起点以真实协议核验。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：供应商53失败推送片号，须与声明总片数一致；重复片不新增，乱序迟到保留，冲突待核。不是业务批次；未收到不推定0失败。编号起点以真实协议核验。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 来源与计算

来源类型：external

规则：供应商53失败推送片号，须与声明总片数一致；重复片不新增，乱序迟到保留，冲突待核。不是业务批次；未收到不推定0失败。编号起点以真实协议核验。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 声明中的有效第1片（合成）

非法/拒绝：
- 片号超出声明或冲突时不可声称收齐

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-028
- product-input.json#FLD-073
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/9
- pages:PAGE-002/fields/8
- project_facts:PRODUCT-FIELD-MAP/fields/27
- project_facts:PRODUCT-FIELD-MAP/fields/72

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-040, CHECK-042, CHECK-043

<a id="FLD-029"></a>

## FLD-029 供应商企业号

单功能页面／局部明确关联：

- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierEvidence`

字段：`enterpriseId`

类型：供应商标识值

格式/枚举/单位/精度：保留53企业号，须经已核实租户映射后参与定位；缺失、无映射、多候选待核，不将其直接等同本地tenantId。

允许 null：True

必填条件：保留53企业号，须经已核实租户映射后参与定位；缺失、无映射、多候选待核，不将其直接等同本地tenantId。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留53企业号，须经已核实租户映射后参与定位；缺失、无映射、多候选待核，不将其直接等同本地tenantId。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留53企业号，须经已核实租户映射后参与定位；缺失、无映射、多候选待核，不将其直接等同本地tenantId。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 来源与计算

来源类型：external

规则：保留53企业号，须经已核实租户映射后参与定位；缺失、无映射、多候选待核，不将其直接等同本地tenantId。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-ENTERPRISE-A

非法/拒绝：
- 未经核实映射直接归租户禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-029
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/3
- project_facts:PRODUCT-FIELD-MAP/fields/28

局部说明：[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-040, CHECK-043

<a id="FLD-030"></a>

## FLD-030 导入失败原始原因

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`ImportFailure`

字段：`failedReason`

类型：字符串

格式/枚举/单位/精度：保存原始失败码与可核实解释；53已知TaskDup/BatchDup/ReqDup/NumFmtErr/BlkNum/CustNumNil，未知码留原文且待核，不能误作呼叫失败。明细只在对应快照可信成功下载后清理，必要原因交付证据保留。

允许 null：True

必填条件：保存原始失败码与可核实解释；53已知TaskDup/BatchDup/ReqDup/NumFmtErr/BlkNum/CustNumNil，未知码留原文且待核，不能误作呼叫失败。明细只在对应快照可信成功下载后清理，必要原因交付证据保留。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存原始失败码与可核实解释；53已知TaskDup/BatchDup/ReqDup/NumFmtErr/BlkNum/CustNumNil，未知码留原文且待核，不能误作呼叫失败。明细只在对应快照可信成功下载后清理，必要原因交付证据保留。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存原始失败码与可核实解释；53已知TaskDup/BatchDup/ReqDup/NumFmtErr/BlkNum/CustNumNil，未知码留原文且待核，不能误作呼叫失败。明细只在对应快照可信成功下载后清理，必要原因交付证据保留。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信失败时保存明细；生成快照时保存范围及状态；仅本次快照可信下载成功清理对应明细/文件，失败中断及后到新失败保留，必要关联去重交付证据持续保留。

### 来源与计算

来源类型：external

规则：保存原始失败码与可核实解释；53已知TaskDup/BatchDup/ReqDup/NumFmtErr/BlkNum/CustNumNil，未知码留原文且待核，不能误作呼叫失败。明细只在对应快照可信成功下载后清理，必要原因交付证据保留。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信失败时保存明细；生成快照时保存范围及状态；仅本次快照可信下载成功清理对应明细/文件，失败中断及后到新失败保留，必要关联去重交付证据持续保留。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- TaskDup；NumFmtErr

非法/拒绝：
- 未知码随意翻译为风控已解除禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-030
- product-input.json#FLD-072
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/11
- pages:PAGE-002/fields/9
- project_facts:PRODUCT-FIELD-MAP/fields/29
- project_facts:PRODUCT-FIELD-MAP/fields/71

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-013, CHECK-040, CHECK-041, CHECK-042

<a id="FLD-031"></a>

## FLD-031 失败项原始导入数据

单功能页面／局部明确关联：

- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportFailure`

字段：`originalRow`

类型：对象或原始文本

格式/枚举/单位/精度：按实际供应商载荷保留原始号码行；failedTelList文档数组与示例字符串差异待核。与enterprise/task/fileId精确关联，不能由最近同号补造。明细按快照下载规则清理。

允许 null：True

必填条件：按实际供应商载荷保留原始号码行；failedTelList文档数组与示例字符串差异待核。与enterprise/task/fileId精确关联，不能由最近同号补造。明细按快照下载规则清理。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 按实际供应商载荷保留原始号码行；failedTelList文档数组与示例字符串差异待核。与enterprise/task/fileId精确关联，不能由最近同号补造。明细按快照下载规则清理。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：按实际供应商载荷保留原始号码行；failedTelList文档数组与示例字符串差异待核。与enterprise/task/fileId精确关联，不能由最近同号补造。明细按快照下载规则清理。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信失败时保存明细；生成快照时保存范围及状态；仅本次快照可信下载成功清理对应明细/文件，失败中断及后到新失败保留，必要关联去重交付证据持续保留。

### 来源与计算

来源类型：external

规则：按实际供应商载荷保留原始号码行；failedTelList文档数组与示例字符串差异待核。与enterprise/task/fileId精确关联，不能由最近同号补造。明细按快照下载规则清理。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信失败时保存明细；生成快照时保存范围及状态；仅本次快照可信下载成功清理对应明细/文件，失败中断及后到新失败保留，必要关联去重交付证据持续保留。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 含原始tel的合成失败项

非法/拒绝：
- 缺原始行时拼造号码关联禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-031
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/10
- project_facts:PRODUCT-FIELD-MAP/fields/30

局部说明：[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-040, CHECK-042, CHECK-043

<a id="FLD-033"></a>

## FLD-033 供应商批次名称

单功能页面／局部明确关联：

- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierEvidence`

字段：`fileName`

类型：字符串

格式/枚举/单位/精度：保留53原始批次名称供审计，不能用名称替代精确fileId或当作本地根批次。缺失不伪造。

允许 null：True

必填条件：保留53原始批次名称供审计，不能用名称替代精确fileId或当作本地根批次。缺失不伪造。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留53原始批次名称供审计，不能用名称替代精确fileId或当作本地根批次。缺失不伪造。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留53原始批次名称供审计，不能用名称替代精确fileId或当作本地根批次。缺失不伪造。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 来源与计算

来源类型：external

规则：保留53原始批次名称供审计，不能用名称替代精确fileId或当作本地根批次。缺失不伪造。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 合成单号批次

非法/拒绝：
- 同名批次自动合并禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-033
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/32

局部说明：[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-040, CHECK-043

<a id="FLD-035"></a>

## FLD-035 声明失败分片总数

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`FailurePushGroup`

字段：`totalBatchCount`

类型：整数

格式/枚举/单位/精度：保存53声明的推送片总数；未知独立表示。与已知片号一致时才计算该组收齐，声明冲突待核；收齐不意味着全导入终态。

允许 null：True

必填条件：保存53声明的推送片总数；未知独立表示。与已知片号一致时才计算该组收齐，声明冲突待核；收齐不意味着全导入终态。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存53声明的推送片总数；未知独立表示。与已知片号一致时才计算该组收齐，声明冲突待核；收齐不意味着全导入终态。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存53声明的推送片总数；未知独立表示。与已知片号一致时才计算该组收齐，声明冲突待核；收齐不意味着全导入终态。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 来源与计算

来源类型：external

规则：保存53声明的推送片总数；未知独立表示。与已知片号一致时才计算该组收齐，声明冲突待核；收齐不意味着全导入终态。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 2片（合成）

非法/拒绝：
- 收到2/2即宣布全导入终态禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-035
- product-input.json#FLD-073
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/8
- pages:PAGE-002/fields/8
- project_facts:PRODUCT-FIELD-MAP/fields/34
- project_facts:PRODUCT-FIELD-MAP/fields/72

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-040, CHECK-042, CHECK-043

<a id="FLD-036"></a>

## FLD-036 声明失败号码总数

单功能页面／局部明确关联：

- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`FailurePushGroup`

字段：`totalFailedCount`

类型：整数

格式/枚举/单位/精度：供应商53原始声明总失败数；未知不补0，与明细不符保留证据待核，不从未收到事件推断零失败。

允许 null：True

必填条件：供应商53原始声明总失败数；未知不补0，与明细不符保留证据待核，不从未收到事件推断零失败。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 供应商53原始声明总失败数；未知不补0，与明细不符保留证据待核，不从未收到事件推断零失败。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：供应商53原始声明总失败数；未知不补0，与明细不符保留证据待核，不从未收到事件推断零失败。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 来源与计算

来源类型：external

规则：供应商53原始声明总失败数；未知不补0，与明细不符保留证据待核，不从未收到事件推断零失败。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 2（明确声明）

非法/拒绝：
- 没有53事件即写0失败禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-036
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/7
- project_facts:PRODUCT-FIELD-MAP/fields/35

局部说明：[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-040, CHECK-043

<a id="FIELD-EVENT-TYPE"></a>

## FIELD-EVENT-TYPE 供应商事件类型

单功能页面／局部明确关联：

- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierEvidence`

字段：`eventType`

类型：整数或原始值

格式/枚举/单位/精度：区分52预测呼叫失败、53导入失败和1060降级结果来源；未知事件保留待核，不将53计实际呼叫或1060作平台换主叫成功。真实payload及可信鉴权仍待核。

允许 null：True

必填条件：区分52预测呼叫失败、53导入失败和1060降级结果来源；未知事件保留待核，不将53计实际呼叫或1060作平台换主叫成功。真实payload及可信鉴权仍待核。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 区分52预测呼叫失败、53导入失败和1060降级结果来源；未知事件保留待核，不将53计实际呼叫或1060作平台换主叫成功。真实payload及可信鉴权仍待核。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：区分52预测呼叫失败、53导入失败和1060降级结果来源；未知事件保留待核，不将53计实际呼叫或1060作平台换主叫成功。真实payload及可信鉴权仍待核。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 来源与计算

来源类型：external

规则：区分52预测呼叫失败、53导入失败和1060降级结果来源；未知事件保留待核，不将53计实际呼叫或1060作平台换主叫成功。真实payload及可信鉴权仍待核。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 52；53；1060

非法/拒绝：
- 53失败增加实际呼叫次数禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-037
- product-input.json#FLD-038
- product-input.json#FLD-039
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/0
- interfaces:API-003/response_fields/1
- interfaces:API-003/response_fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/36
- project_facts:PRODUCT-FIELD-MAP/fields/37
- project_facts:PRODUCT-FIELD-MAP/fields/38

局部说明：[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-003, CHECK-040

<a id="FIELD-EVENT-PAYLOAD"></a>

## FIELD-EVENT-PAYLOAD 供应商原始事件证据

单功能页面／局部明确关联：

- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierEvidence`

字段：`rawPayload`

类型：对象或原始文本

格式/枚举/单位/精度：保留实际收到的原始包、来源及关联检查结果；未可信纯SIP独立待核，不覆盖已确认call。重复保留去重与来源证据，不再造业务事件；具体安全存储由工程设计。

允许 null：False

必填条件：保留实际收到的原始包、来源及关联检查结果；未可信纯SIP独立待核，不覆盖已确认call。重复保留去重与来源证据，不再造业务事件；具体安全存储由工程设计。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留实际收到的原始包、来源及关联检查结果；未可信纯SIP独立待核，不覆盖已确认call。重复保留去重与来源证据，不再造业务事件；具体安全存储由工程设计。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留实际收到的原始包、来源及关联检查结果；未可信纯SIP独立待核，不覆盖已确认call。重复保留去重与来源证据，不再造业务事件；具体安全存储由工程设计。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 来源与计算

来源类型：external

规则：保留实际收到的原始包、来源及关联检查结果；未可信纯SIP独立待核，不覆盖已确认call。重复保留去重与来源证据，不再造业务事件；具体安全存储由工程设计。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 合成事件包及来源

非法/拒绝：
- 未可信纯SIP覆盖可信call结果禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-003
- product-input.json#FLD-037
- product-input.json#FLD-038
- product-input.json#FLD-039
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-003/response_fields/0
- interfaces:API-003/response_fields/1
- interfaces:API-003/response_fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/36
- project_facts:PRODUCT-FIELD-MAP/fields/37
- project_facts:PRODUCT-FIELD-MAP/fields/38

局部说明：[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-003, CHECK-035, CHECK-040, CHECK-062

<a id="FLD-040"></a>

## FLD-040 话单查询开始时间

单功能页面／局部明确关联：

- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

业务对象：`CdrQuery`

字段：`startTime`

类型：时间值

格式/枚举/单位/精度：用于既有话单查询时间窗口而非每日衰减查询；有窗口时开始不得晚于结束。真实时间编码、时区、边界含义待接口核实，缺值不擅自扩查所有租户。

允许 null：True

必填条件：用于既有话单查询时间窗口而非每日衰减查询；有窗口时开始不得晚于结束。真实时间编码、时区、边界含义待接口核实，缺值不擅自扩查所有租户。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 用于既有话单查询时间窗口而非每日衰减查询；有窗口时开始不得晚于结束。真实时间编码、时区、边界含义待接口核实，缺值不擅自扩查所有租户。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 既有话单查询授权调用方（受限租户任务查询范围）；不新增每日查询调度

### 各状态行为

- 输入或接收：用于既有话单查询时间窗口而非每日衰减查询；有窗口时开始不得晚于结束。真实时间编码、时区、边界含义待接口核实，缺值不擅自扩查所有租户。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：input

规则：用于既有话单查询时间窗口而非每日衰减查询；有窗口时开始不得晚于结束。真实时间编码、时区、边界含义待接口核实，缺值不擅自扩查所有租户。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 经核准的合成时间起点

非法/拒绝：
- 开始晚于结束不得发起查询

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-040
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/request_fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/39

局部说明：[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-035, CHECK-038

<a id="FLD-041"></a>

## FLD-041 话单查询结束时间

单功能页面／局部明确关联：

- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

业务对象：`CdrQuery`

字段：`startTimeEnd`

类型：时间值

格式/枚举/单位/精度：与查询开始时间组成受权任务范围窗口；不驱动每日状态查询或衰减，时间单位与时区待工程映射，缺值按真实接口约定。

允许 null：True

必填条件：与查询开始时间组成受权任务范围窗口；不驱动每日状态查询或衰减，时间单位与时区待工程映射，缺值按真实接口约定。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 与查询开始时间组成受权任务范围窗口；不驱动每日状态查询或衰减，时间单位与时区待工程映射，缺值按真实接口约定。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 既有话单查询授权调用方（受限租户任务查询范围）；不新增每日查询调度

### 各状态行为

- 输入或接收：与查询开始时间组成受权任务范围窗口；不驱动每日状态查询或衰减，时间单位与时区待工程映射，缺值按真实接口约定。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：input

规则：与查询开始时间组成受权任务范围窗口；不驱动每日状态查询或衰减，时间单位与时区待工程映射，缺值按真实接口约定。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 经核准的合成时间终点

非法/拒绝：
- 缺失时伪造当前时间导致错误窗口禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-041
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/request_fields/1
- project_facts:PRODUCT-FIELD-MAP/fields/40

局部说明：[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-035, CHECK-038

<a id="FLD-043"></a>

## FLD-043 客户实际接听时长原值

单功能页面／局部明确关联：

- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`customerBridgeDuration`

类型：整数

格式/枚举/单位/精度：保留客户实际接听时长原值，0是真实合法值，null/未接通/异常不纳秒挂。不得用坐席桥接时长替代；原始单位待核，须可靠转换到秒后才做0～2秒判断。

允许 null：True

必填条件：保留客户实际接听时长原值，0是真实合法值，null/未接通/异常不纳秒挂。不得用坐席桥接时长替代；原始单位待核，须可靠转换到秒后才做0～2秒判断。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留客户实际接听时长原值，0是真实合法值，null/未接通/异常不纳秒挂。不得用坐席桥接时长替代；原始单位待核，须可靠转换到秒后才做0～2秒判断。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留客户实际接听时长原值，0是真实合法值，null/未接通/异常不纳秒挂。不得用坐席桥接时长替代；原始单位待核，须可靠转换到秒后才做0～2秒判断。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保留客户实际接听时长原值，0是真实合法值，null/未接通/异常不纳秒挂。不得用坐席桥接时长替代；原始单位待核，须可靠转换到秒后才做0～2秒判断。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 可信已接听的真实0秒；2秒

非法/拒绝：
- 缺失当0秒或负时长认定秒挂禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-043
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/1
- project_facts:PRODUCT-FIELD-MAP/fields/42

局部说明：[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-013](local-logic/LOCAL-013.md)

任务：

测试：CHECK-021, CHECK-034

<a id="FLD-044"></a>

## FLD-044 供应商降级轮次

单功能页面／局部明确关联：

- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)

业务对象：`CallResult`

字段：`degradeRound`

类型：整数

格式/枚举/单位/精度：保存供应商原始降级轮次及来源，仅观察真实结果，不代表平台priority衰减或平台重导次数。未返回未知，合法范围待真实协议核验。

允许 null：True

必填条件：保存供应商原始降级轮次及来源，仅观察真实结果，不代表平台priority衰减或平台重导次数。未返回未知，合法范围待真实协议核验。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存供应商原始降级轮次及来源，仅观察真实结果，不代表平台priority衰减或平台重导次数。未返回未知，合法范围待真实协议核验。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存供应商原始降级轮次及来源，仅观察真实结果，不代表平台priority衰减或平台重导次数。未返回未知，合法范围待真实协议核验。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保存供应商原始降级轮次及来源，仅观察真实结果，不代表平台priority衰减或平台重导次数。未返回未知，合法范围待真实协议核验。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商明确返回1

非法/拒绝：
- 缺失补0或据此调度重导禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-044
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/8
- project_facts:PRODUCT-FIELD-MAP/fields/43

局部说明：[LOCAL-013](local-logic/LOCAL-013.md)

任务：

测试：CHECK-002, CHECK-035

<a id="FLD-045"></a>

## FLD-045 通话结束时间原值

单功能页面／局部明确关联：

- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)

业务对象：`CallResult`

字段：`endTime`

类型：Long时间值

格式/枚举/单位/精度：保存供应商原始结束时间及来源；单位/时区映射待核，不将缺失视为通话未发生，不以结果时间选最近主。

允许 null：True

必填条件：保存供应商原始结束时间及来源；单位/时区映射待核，不将缺失视为通话未发生，不以结果时间选最近主。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存供应商原始结束时间及来源；单位/时区映射待核，不将缺失视为通话未发生，不以结果时间选最近主。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存供应商原始结束时间及来源；单位/时区映射待核，不将缺失视为通话未发生，不以结果时间选最近主。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保存供应商原始结束时间及来源；单位/时区映射待核，不将缺失视为通话未发生，不以结果时间选最近主。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商明确返回的合成Long值

非法/拒绝：
- 把毫秒按秒展示未核实值禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-045
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/44

局部说明：[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-013](local-logic/LOCAL-013.md)

任务：

测试：CHECK-023, CHECK-035

<a id="FLD-046"></a>

## FLD-046 供应商最后一条标志

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`finishRetryFlag`

类型：整数

格式/枚举/单位/精度：只接受可信Integer1=最后一条、0=否，缺失/其他值独立未知；不与SIP异步更新标记混淆，不代表整个任务或DCC计划完成，不设等待后重导门禁。

允许 null：True

必填条件：只接受可信Integer1=最后一条、0=否，缺失/其他值独立未知；不与SIP异步更新标记混淆，不代表整个任务或DCC计划完成，不设等待后重导门禁。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 只接受可信Integer1=最后一条、0=否，缺失/其他值独立未知；不与SIP异步更新标记混淆，不代表整个任务或DCC计划完成，不设等待后重导门禁。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：只接受可信Integer1=最后一条、0=否，缺失/其他值独立未知；不与SIP异步更新标记混淆，不代表整个任务或DCC计划完成，不设等待后重导门禁。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：只接受可信Integer1=最后一条、0=否，缺失/其他值独立未知；不与SIP异步更新标记混淆，不代表整个任务或DCC计划完成，不设等待后重导门禁。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 1；0；null为未知

非法/拒绝：
- 字符串1未经核实当Integer1或未知当0禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#API-010
- product-input.json#FLD-046
- product-input.json#FLD-058
- product-input.json#FLD-086
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/7
- interfaces:API-010/request_fields/9
- pages:PAGE-002/fields/5
- project_facts:PRODUCT-FIELD-MAP/fields/45
- project_facts:PRODUCT-FIELD-MAP/fields/57
- project_facts:PRODUCT-FIELD-MAP/fields/85

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-033, CHECK-038

<a id="FLD-047"></a>

## FLD-047 obSipCause原字段

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`obSipCause`

类型：字符串

格式/枚举/单位/精度：保留可信SIP原字段与来源；未知不补值，与sipCause分别保存。可信准确晚更新同一call，未可信包单列待核，不新增呼叫。

允许 null：True

必填条件：保留可信SIP原字段与来源；未知不补值，与sipCause分别保存。可信准确晚更新同一call，未可信包单列待核，不新增呼叫。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留可信SIP原字段与来源；未知不补值，与sipCause分别保存。可信准确晚更新同一call，未可信包单列待核，不新增呼叫。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留可信SIP原字段与来源；未知不补值，与sipCause分别保存。可信准确晚更新同一call，未可信包单列待核，不新增呼叫。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保留可信SIP原字段与来源；未知不补值，与sipCause分别保存。可信准确晚更新同一call，未可信包单列待核，不新增呼叫。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商原始SIP文本

非法/拒绝：
- 未经确认把文本转换为另一字段覆盖禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#API-010
- product-input.json#FLD-047
- product-input.json#FLD-067
- product-input.json#FLD-086
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/5
- interfaces:API-010/request_fields/8
- pages:PAGE-002/fields/5
- project_facts:PRODUCT-FIELD-MAP/fields/46
- project_facts:PRODUCT-FIELD-MAP/fields/66
- project_facts:PRODUCT-FIELD-MAP/fields/85

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-018, CHECK-035, CHECK-062

<a id="FLD-048"></a>

## FLD-048 挂断来源原字段

单功能页面／局部明确关联：

- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`onHookSource`

类型：字符串

格式/枚举/单位/精度：响应原字段为String，与查询Integer[]参数不同；客户挂断判定须基于核实枚举。未知不能当客户挂断，保留原值及来源。

允许 null：True

必填条件：响应原字段为String，与查询Integer[]参数不同；客户挂断判定须基于核实枚举。未知不能当客户挂断，保留原值及来源。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 响应原字段为String，与查询Integer[]参数不同；客户挂断判定须基于核实枚举。未知不能当客户挂断，保留原值及来源。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：响应原字段为String，与查询Integer[]参数不同；客户挂断判定须基于核实枚举。未知不能当客户挂断，保留原值及来源。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：响应原字段为String，与查询Integer[]参数不同；客户挂断判定须基于核实枚举。未知不能当客户挂断，保留原值及来源。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 客户挂断（来源示例）

非法/拒绝：
- 未核实数字枚举直接认定客户挂断禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-048
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/47

局部说明：[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-013](local-logic/LOCAL-013.md)

任务：

测试：CHECK-021, CHECK-034

<a id="FLD-049"></a>

## FLD-049 sipCause原字段

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`sipCause`

类型：整数

格式/枚举/单位/精度：保存原始Integer SIP码，缺失不填0，准确可信晚更新同一call；与obSipCause类型语义分开，不作为业务结果唯一证据。

允许 null：True

必填条件：保存原始Integer SIP码，缺失不填0，准确可信晚更新同一call；与obSipCause类型语义分开，不作为业务结果唯一证据。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存原始Integer SIP码，缺失不填0，准确可信晚更新同一call；与obSipCause类型语义分开，不作为业务结果唯一证据。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存原始Integer SIP码，缺失不填0，准确可信晚更新同一call；与obSipCause类型语义分开，不作为业务结果唯一证据。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保存原始Integer SIP码，缺失不填0，准确可信晚更新同一call；与obSipCause类型语义分开，不作为业务结果唯一证据。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商明确返回的合成码486

非法/拒绝：
- 未可信SIP改变原call业务结果禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#API-010
- product-input.json#FLD-049
- product-input.json#FLD-067
- product-input.json#FLD-086
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/4
- interfaces:API-010/request_fields/8
- pages:PAGE-002/fields/5
- project_facts:PRODUCT-FIELD-MAP/fields/48
- project_facts:PRODUCT-FIELD-MAP/fields/66
- project_facts:PRODUCT-FIELD-MAP/fields/85

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-018, CHECK-035, CHECK-062

<a id="FLD-050"></a>

## FLD-050 SIP异步更新标志

单功能页面／局部明确关联：

- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`sipCauseAsyncUpdateFlag`

类型：整数

格式/枚举/单位/精度：保存供应商Integer原值和来源，枚举映射待核；仅为SIP更新相关证据，不是最后一通标志。晚更新不算新呼叫。

允许 null：True

必填条件：保存供应商Integer原值和来源，枚举映射待核；仅为SIP更新相关证据，不是最后一通标志。晚更新不算新呼叫。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存供应商Integer原值和来源，枚举映射待核；仅为SIP更新相关证据，不是最后一通标志。晚更新不算新呼叫。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存供应商Integer原值和来源，枚举映射待核；仅为SIP更新相关证据，不是最后一通标志。晚更新不算新呼叫。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保存供应商Integer原值和来源，枚举映射待核；仅为SIP更新相关证据，不是最后一通标志。晚更新不算新呼叫。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商明确返回值

非法/拒绝：
- 把此标志当finishRetryFlag禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-050
- product-input.json#FLD-086
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/6
- pages:PAGE-002/fields/5
- project_facts:PRODUCT-FIELD-MAP/fields/49
- project_facts:PRODUCT-FIELD-MAP/fields/85

局部说明：[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-035, CHECK-038, CHECK-062

<a id="FLD-051"></a>

## FLD-051 话单原始状态码

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`status`

类型：整数

格式/枚举/单位/精度：保存Integer话单状态及其来源，与状态描述分开；枚举未核实保持原码未知，不伪造终态，不凭无话单判未拨。

允许 null：True

必填条件：保存Integer话单状态及其来源，与状态描述分开；枚举未核实保持原码未知，不伪造终态，不凭无话单判未拨。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存Integer话单状态及其来源，与状态描述分开；枚举未核实保持原码未知，不伪造终态，不凭无话单判未拨。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存Integer话单状态及其来源，与状态描述分开；枚举未核实保持原码未知，不伪造终态，不凭无话单判未拨。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保存Integer话单状态及其来源，与状态描述分开；枚举未核实保持原码未知，不伪造终态，不凭无话单判未拨。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商明确状态码

非法/拒绝：
- 未知码自动映射已完成禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#API-010
- product-input.json#FLD-051
- product-input.json#FLD-067
- product-input.json#FLD-086
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/3
- interfaces:API-010/request_fields/8
- pages:PAGE-002/fields/5
- project_facts:PRODUCT-FIELD-MAP/fields/50
- project_facts:PRODUCT-FIELD-MAP/fields/66
- project_facts:PRODUCT-FIELD-MAP/fields/85

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-018, CHECK-035, CHECK-038

<a id="FIELD-STATUS-DESC"></a>

## FIELD-STATUS-DESC 话单状态描述

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`statusDesc`

类型：字符串

格式/枚举/单位/精度：保存供应商statusDesc，与原status一起展示；未返回明确缺失，不编造枚举解释。

允许 null：True

必填条件：保存供应商statusDesc，与原status一起展示；未返回明确缺失，不编造枚举解释。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存供应商statusDesc，与原status一起展示；未返回明确缺失，不编造枚举解释。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存供应商statusDesc，与原status一起展示；未返回明确缺失，不编造枚举解释。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保存供应商statusDesc，与原status一起展示；未返回明确缺失，不编造枚举解释。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 合成：已接通

非法/拒绝：
- 原码未知时编写真实成功描述禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#API-010
- product-input.json#FLD-051
- product-input.json#FLD-067
- product-input.json#FLD-086
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/3
- interfaces:API-010/request_fields/8
- pages:PAGE-002/fields/5
- project_facts:PRODUCT-FIELD-MAP/fields/50
- project_facts:PRODUCT-FIELD-MAP/fields/66
- project_facts:PRODUCT-FIELD-MAP/fields/85

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-018, CHECK-035

<a id="FLD-052"></a>

## FLD-052 供应商号码重试轮次

单功能页面／局部明确关联：

- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)

业务对象：`CallResult`

字段：`telRetryRound`

类型：整数

格式/枚举/单位/精度：保存供应商原始重试轮次及来源，不直接等于DCC业务计次；重复通知/业务导入不增加真实呼叫。合法范围及链范围待核。

允许 null：True

必填条件：保存供应商原始重试轮次及来源，不直接等于DCC业务计次；重复通知/业务导入不增加真实呼叫。合法范围及链范围待核。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存供应商原始重试轮次及来源，不直接等于DCC业务计次；重复通知/业务导入不增加真实呼叫。合法范围及链范围待核。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存供应商原始重试轮次及来源，不直接等于DCC业务计次；重复通知/业务导入不增加真实呼叫。合法范围及链范围待核。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：保存供应商原始重试轮次及来源，不直接等于DCC业务计次；重复通知/业务导入不增加真实呼叫。合法范围及链范围待核。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商明确返回2

非法/拒绝：
- 从导入次数推造telRetryRound禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-004
- product-input.json#FLD-052
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-004/response_fields/9
- project_facts:PRODUCT-FIELD-MAP/fields/51

局部说明：[LOCAL-013](local-logic/LOCAL-013.md)

任务：

测试：CHECK-023, CHECK-027, CHECK-035

<a id="FLD-054"></a>

## FLD-054 本次精准删除结果

单功能页面／局部明确关联：

- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierDeletion`

字段：`result`

类型：枚举

格式/枚举/单位/精度：产品结果为明确成功/明确失败/未知，尚未操作可空；仅明确成功标对应供应商批次已删，本地记录/关联/幂等保留，不作用同组其他批次。供应商具体码及执行中并发待核。

允许 null：True

必填条件：产品结果为明确成功/明确失败/未知，尚未操作可空；仅明确成功标对应供应商批次已删，本地记录/关联/幂等保留，不作用同组其他批次。供应商具体码及执行中并发待核。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 产品结果为明确成功/明确失败/未知，尚未操作可空；仅明确成功标对应供应商批次已删，本地记录/关联/幂等保留，不作用同组其他批次。供应商具体码及执行中并发待核。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：产品结果为明确成功/明确失败/未知，尚未操作可空；仅明确成功标对应供应商批次已删，本地记录/关联/幂等保留，不作用同组其他批次。供应商具体码及执行中并发待核。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 来源与计算

来源类型：external

规则：产品结果为明确成功/明确失败/未知，尚未操作可空；仅明确成功标对应供应商批次已删，本地记录/关联/幂等保留，不作用同组其他批次。供应商具体码及执行中并发待核。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：接收外部响应或事件时保存原值/来源；可信精确关联后更新对应对象；缺失/矛盾保留未知或待核，晚更新不创建新呼叫，原始关联不被新主或下载清理覆盖。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 明确成功；超时未知

非法/拒绝：
- 超时标已删或按主批级联删除禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-006
- product-input.json#FLD-054
- product-input.json#FLD-079
- product-input.json#FLD-083
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-006/response_fields/0
- pages:PAGE-002/fields/14
- pages:PAGE-002/fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/53
- project_facts:PRODUCT-FIELD-MAP/fields/78
- project_facts:PRODUCT-FIELD-MAP/fields/82

局部说明：[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-016, CHECK-024, CHECK-025, CHECK-061

<a id="FIELD-OCCURRED-AT"></a>

## FIELD-OCCURRED-AT 业务结果发生时间

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)

业务对象：`BusinessResult`

字段：`occurredAt`

类型：时间值

格式/枚举/单位/精度：保存真实导入/呼叫/删除结果发生时间，缺失未知不以接收时间冒充；原始编码与展示时区由工程核实，不用于选择主批。

允许 null：True

必填条件：保存真实导入/呼叫/删除结果发生时间，缺失未知不以接收时间冒充；原始编码与展示时区由工程核实，不用于选择主批。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存真实导入/呼叫/删除结果发生时间，缺失未知不以接收时间冒充；原始编码与展示时区由工程核实，不用于选择主批。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保存真实导入/呼叫/删除结果发生时间，缺失未知不以接收时间冒充；原始编码与展示时区由工程核实，不用于选择主批。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 来源与计算

来源类型：external

规则：保存真实导入/呼叫/删除结果发生时间，缺失未知不以接收时间冒充；原始编码与展示时区由工程核实，不用于选择主批。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商明确发生时间

非法/拒绝：
- 用晚到时间改写原发生时间禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-062
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/61

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-012](local-logic/LOCAL-012.md)

任务：

测试：CHECK-018, CHECK-023, CHECK-033

<a id="FIELD-RESULT-STAGE"></a>

## FIELD-RESULT-STAGE 业务结果阶段

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)

业务对象：`BusinessResult`

字段：`stage`

类型：枚举

格式/枚举/单位/精度：明确区分本地校验保存、供应商导入、实际呼叫及精准删除；导入失败不算呼叫失败或实际呼叫；阶段不得仅由result=0合并。

允许 null：False

必填条件：明确区分本地校验保存、供应商导入、实际呼叫及精准删除；导入失败不算呼叫失败或实际呼叫；阶段不得仅由result=0合并。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 明确区分本地校验保存、供应商导入、实际呼叫及精准删除；导入失败不算呼叫失败或实际呼叫；阶段不得仅由result=0合并。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：明确区分本地校验保存、供应商导入、实际呼叫及精准删除；导入失败不算呼叫失败或实际呼叫；阶段不得仅由result=0合并。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 来源与计算

来源类型：system

规则：明确区分本地校验保存、供应商导入、实际呼叫及精准删除；导入失败不算呼叫失败或实际呼叫；阶段不得仅由result=0合并。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 供应商导入；实际呼叫

非法/拒绝：
- 导入拒绝算一次实际呼叫禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-062
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/61

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-012](local-logic/LOCAL-012.md)

任务：

测试：CHECK-013, CHECK-039, CHECK-041

<a id="FIELD-RESULT-REASON"></a>

## FIELD-RESULT-REASON 呼叫或业务结果原因

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`BusinessResult`

字段：`reason`

类型：字符串或原始码

格式/枚举/单位/精度：保留可信准确关联的本次结果/风控失败原因，无话单失败独立记录，可缺callId但需稳定事件；未知不编造解除/重导条件，导入failedReason另行保存。

允许 null：True

必填条件：保留可信准确关联的本次结果/风控失败原因，无话单失败独立记录，可缺callId但需稳定事件；未知不编造解除/重导条件，导入failedReason另行保存。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保留可信准确关联的本次结果/风控失败原因，无话单失败独立记录，可缺callId但需稳定事件；未知不编造解除/重导条件，导入failedReason另行保存。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：保留可信准确关联的本次结果/风控失败原因，无话单失败独立记录，可缺callId但需稳定事件；未知不编造解除/重导条件，导入failedReason另行保存。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 来源与计算

来源类型：external

规则：保留可信准确关联的本次结果/风控失败原因，无话单失败独立记录，可缺callId但需稳定事件；未知不编造解除/重导条件，导入failedReason另行保存。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 合成：无可用中继

非法/拒绝：
- 未知原因编写已解禁并重导禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-062
- product-input.json#FLD-087
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/6
- pages:PAGE-002/fields/4
- project_facts:PRODUCT-FIELD-MAP/fields/61
- project_facts:PRODUCT-FIELD-MAP/fields/86

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-002, CHECK-003, CHECK-020, CHECK-033

<a id="FIELD-CUSTOMER-ANSWERED"></a>

## FIELD-CUSTOMER-ANSWERED 客户真实接听状态

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`customerAnswered`

类型：布尔

格式/枚举/单位/精度：true须有真实客户接听证据，false为明确未接，null未知；不以坐席接听或桥接时长代替，不从空时长推断。

允许 null：True

必填条件：true须有真实客户接听证据，false为明确未接，null未知；不以坐席接听或桥接时长代替，不从空时长推断。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- true须有真实客户接听证据，false为明确未接，null未知；不以坐席接听或桥接时长代替，不从空时长推断。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：true须有真实客户接听证据，false为明确未接，null未知；不以坐席接听或桥接时长代替，不从空时长推断。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：true须有真实客户接听证据，false为明确未接，null未知；不以坐席接听或桥接时长代替，不从空时长推断。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- true；false；null未知

非法/拒绝：
- 仅坐席接听认定客户已接听禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-063
- product-input.json#FLD-087
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/7
- pages:PAGE-002/fields/4
- project_facts:PRODUCT-FIELD-MAP/fields/62
- project_facts:PRODUCT-FIELD-MAP/fields/86

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-021, CHECK-034

<a id="FIELD-AGENT-ANSWERED"></a>

## FIELD-AGENT-ANSWERED 坐席实际接听状态

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`agentAnswered`

类型：布尔

格式/枚举/单位/精度：独立保存坐席实际接听证据，true/false/null未知与客户状态分开；不得代替客户真实接听条件或时长。

允许 null：True

必填条件：独立保存坐席实际接听证据，true/false/null未知与客户状态分开；不得代替客户真实接听条件或时长。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 独立保存坐席实际接听证据，true/false/null未知与客户状态分开；不得代替客户真实接听条件或时长。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：独立保存坐席实际接听证据，true/false/null未知与客户状态分开；不得代替客户真实接听条件或时长。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 来源与计算

来源类型：external

规则：独立保存坐席实际接听证据，true/false/null未知与客户状态分开；不得代替客户真实接听条件或时长。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联到原通话的供应商话单/事件证据后保存原字段、来源和未知状态；可信晚更新只更新同一原call，原始关联保持，重复不新增呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- true；null未知

非法/拒绝：
- 坐席true自动填客户true禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-063
- product-input.json#FLD-087
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/7
- pages:PAGE-002/fields/4
- project_facts:PRODUCT-FIELD-MAP/fields/62
- project_facts:PRODUCT-FIELD-MAP/fields/86

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-018, CHECK-021

<a id="FIELD-SHORT-HANGUP"></a>

## FIELD-SHORT-HANGUP 秒挂识别结果

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`CallResult`

字段：`shortHangup`

类型：布尔

格式/枚举/单位/精度：仅可信客户已接听、客户主动挂断且客户实际时长换算为秒后0～2含边界认定true；已知不满足false，关键证据缺失/异常为未知或不纳入，保留原因。不触发平台重导。

允许 null：True

必填条件：仅可信客户已接听、客户主动挂断且客户实际时长换算为秒后0～2含边界认定true；已知不满足false，关键证据缺失/异常为未知或不纳入，保留原因。不触发平台重导。

### 默认与初始化

模式：derived；值：`null`

仅可信客户已接听、客户主动挂断且客户实际时长换算为秒后0～2含边界认定true；已知不满足false，关键证据缺失/异常为未知或不纳入，保留原因。不触发平台重导。

### 校验与关联约束

- 仅可信客户已接听、客户主动挂断且客户实际时长换算为秒后0～2含边界认定true；已知不满足false，关键证据缺失/异常为未知或不纳入，保留原因。不触发平台重导。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：仅可信客户已接听、客户主动挂断且客户实际时长换算为秒后0～2含边界认定true；已知不满足false，关键证据缺失/异常为未知或不纳入，保留原因。不触发平台重导。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信且精确关联的客户接听、挂断方和客户真实时长证据后计算并保存秒挂识别；关键证据缺失/异常保留未知或不纳入；可信晚更新可在原call重算并更新相应交付版本，不新增呼叫、不启动重导。

### 来源与计算

来源类型：calculated

规则：仅可信客户已接听、客户主动挂断且客户实际时长换算为秒后0～2含边界认定true；已知不满足false，关键证据缺失/异常为未知或不纳入，保留原因。不触发平台重导。

依赖字段：[FIELD-CUSTOMER-ANSWERED](field-specs.md#FIELD-CUSTOMER-ANSWERED)、[FLD-043](field-specs.md#FLD-043)、[FLD-048](field-specs.md#FLD-048)

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信且精确关联的客户接听、挂断方和客户真实时长证据后计算并保存秒挂识别；关键证据缺失/异常保留未知或不纳入；可信晚更新可在原call重算并更新相应交付版本，不新增呼叫、不启动重导。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 真实0秒、2秒且客户挂断=true

非法/拒绝：
- null时长或未接通不得判true

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-063
- product-input.json#FLD-087
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/7
- pages:PAGE-002/fields/4
- project_facts:PRODUCT-FIELD-MAP/fields/62
- project_facts:PRODUCT-FIELD-MAP/fields/86

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-004, CHECK-021, CHECK-034

<a id="FLD-066"></a>

## FLD-066 真实通话或稳定事件标识

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`BusinessResult`

字段：`associationId`

类型：标识值

格式/枚举/单位/精度：实际呼叫用真实callID，无话单失败可用稳定事件关联；同时核对已存vendorfileId/实际batch/原始号码，不用leadCode单键或最近同号。具体事件键由工程核实。

允许 null：False

必填条件：实际呼叫用真实callID，无话单失败可用稳定事件关联；同时核对已存vendorfileId/实际batch/原始号码，不用leadCode单键或最近同号。具体事件键由工程核实。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 实际呼叫用真实callID，无话单失败可用稳定事件关联；同时核对已存vendorfileId/实际batch/原始号码，不用leadCode单键或最近同号。具体事件键由工程核实。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：实际呼叫用真实callID，无话单失败可用稳定事件关联；同时核对已存vendorfileId/实际batch/原始号码，不用leadCode单键或最近同号。具体事件键由工程核实。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 来源与计算

来源类型：external

规则：实际呼叫用真实callID，无话单失败可用稳定事件关联；同时核对已存vendorfileId/实际batch/原始号码，不用leadCode单键或最近同号。具体事件键由工程核实。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-CALL-001或可信稳定事件

非法/拒绝：
- 无callID且无稳定关联仍创建已确认呼叫禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-066
- product-input.json#FLD-085
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/5
- pages:PAGE-002/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/65
- project_facts:PRODUCT-FIELD-MAP/fields/84

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-023, CHECK-033, CHECK-035, CHECK-052

<a id="FIELD-EVIDENCE-SOURCE"></a>

## FIELD-EVIDENCE-SOURCE 结果来源与可信依据

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`SupplierEvidence`

字段：`source`

类型：对象

格式/枚举/单位/精度：明确同步响应/事件/话单查询/SIP晚更新的来源及可信关联结果；未可信来源待核独立保留，不覆盖已有可信call，不以合成演示证明生产可信。

允许 null：False

必填条件：明确同步响应/事件/话单查询/SIP晚更新的来源及可信关联结果；未可信来源待核独立保留，不覆盖已有可信call，不以合成演示证明生产可信。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 明确同步响应/事件/话单查询/SIP晚更新的来源及可信关联结果；未可信来源待核独立保留，不覆盖已有可信call，不以合成演示证明生产可信。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：明确同步响应/事件/话单查询/SIP晚更新的来源及可信关联结果；未可信来源待核独立保留，不覆盖已有可信call，不以合成演示证明生产可信。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 来源与计算

来源类型：system

规则：明确同步响应/事件/话单查询/SIP晚更新的来源及可信关联结果；未可信来源待核独立保留，不覆盖已有可信call，不以合成演示证明生产可信。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到外部响应/事件/查询结果时保存实际原包及来源；来源不可信或无法精确关联时独立待核，可信关联后写入对应业务证据，不把原包存在当作结果确认；保留必要去重与原始来源。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 合成话单来源及精准关联证据

非法/拒绝：
- 未核实来源标为可信生产禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-067
- product-input.json#FLD-076
- product-input.json#FLD-084
- product-input.json#FLD-086
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/request_fields/8
- pages:PAGE-002/fields/15
- pages:PAGE-002/fields/5
- pages:PAGE-002/fields/7
- project_facts:PRODUCT-FIELD-MAP/fields/66
- project_facts:PRODUCT-FIELD-MAP/fields/75
- project_facts:PRODUCT-FIELD-MAP/fields/83
- project_facts:PRODUCT-FIELD-MAP/fields/85

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-035, CHECK-039, CHECK-062

<a id="FLD-068"></a>

## FLD-068 DCC接收确认

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)

业务对象：`DccDelivery`

字段：`ack`

类型：原始确认对象

格式/枚举/单位/精度：仅接口来源向后台固定地址回传，每次接收ACK原证据保存；未取得/超时未知，不冒充已送达。真实ACK判据待工程确认，补送同对象不重新导入。

允许 null：True

必填条件：仅接口来源向后台固定地址回传，每次接收ACK原证据保存；未取得/超时未知，不冒充已送达。真实ACK判据待工程确认，补送同对象不重新导入。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 仅接口来源向后台固定地址回传，每次接收ACK原证据保存；未取得/超时未知，不冒充已送达。真实ACK判据待工程确认，补送同对象不重新导入。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台结果交付服务（仅当前业务结果的交付状态）
- 经核实的固定DCC接收端确认（保存真实ACK证据，不以供应商响应替代）

### 各状态行为

- 输入或接收：仅接口来源向后台固定地址回传，每次接收ACK原证据保存；未取得/超时未知，不冒充已送达。真实ACK判据待工程确认，补送同对象不重新导入。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：仅接口来源的每次已关联业务结果或可信晚更新形成待交付内容时保存交付状态和版本；向固定DCC接收端发送后保存实际ACK/失败/未知证据；失败补送更新交付而不新建导入或呼叫，手工不创建该交付。

### 来源与计算

来源类型：external

规则：仅接口来源向后台固定地址回传，每次接收ACK原证据保存；未取得/超时未知，不冒充已送达。真实ACK判据待工程确认，补送同对象不重新导入。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：仅接口来源的每次已关联业务结果或可信晚更新形成待交付内容时保存交付状态和版本；向固定DCC接收端发送后保存实际ACK/失败/未知证据；失败补送更新交付而不新建导入或呼叫，手工不创建该交付。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 合成明确接收确认

非法/拒绝：
- 网络发出即声称已接收禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-010
- product-input.json#FLD-068
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-010/response_fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/67

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)

任务：

测试：CHECK-035, CHECK-037, CHECK-041

<a id="FLD-070"></a>

## FLD-070 应用列表查询词

单功能页面／局部明确关联：

- [查询应用列表 · FUNC\-018](features/FUNC-018.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

业务对象：`ApplicationListView`

字段：`keyword`

类型：字符串

格式/枚举/单位/精度：超管按应用名称或appId查询；空串表示无筛选，不改业务数据；切换查询重新计算结果页。名称长度和匹配策略未确认不把demo限制写成业务约束。

允许 null：False

必填条件：超管按应用名称或appId查询；空串表示无筛选，不改业务数据；切换查询重新计算结果页。名称长度和匹配策略未确认不把demo限制写成业务约束。

### 默认与初始化

模式：literal；值：`""`

仅新打开当前查询/草稿时为空文本；编辑保留当前输入，不自动恢复旧草稿。

### 校验与关联约束

- 超管按应用名称或appId查询；空串表示无筛选，不改业务数据；切换查询重新计算结果页。名称长度和匹配策略未确认不把demo限制写成业务约束。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）

可写：
- 超管（仅查询输入，不修改应用）

### 各状态行为

- 输入或接收：超管按应用名称或appId查询；空串表示无筛选，不改业务数据；切换查询重新计算结果页。名称长度和匹配策略未确认不把demo限制写成业务约束。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：input

规则：超管按应用名称或appId查询；空串表示无筛选，不改业务数据；切换查询重新计算结果页。名称长度和匹配策略未确认不把demo限制写成业务约束。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 演示应用；空串清筛选

非法/拒绝：
- 查询执行创建或删除应用禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-070
- product-input.json#PAGE-001
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-001/fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/69

局部说明：[LOCAL-018](local-logic/LOCAL-018.md)

任务：

测试：CHECK-053

<a id="FLD-071"></a>

## FLD-071 应用查询结果总数

单功能页面／局部明确关联：

- [查询应用列表 · FUNC\-018](features/FUNC-018.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

业务对象：`ApplicationListView`

字段：`total`

类型：整数

格式/枚举/单位/精度：按当前管理权限、查询词的匹配结果计数，非负；无结果合法0并保留新增入口；读取失败不伪造0条成功结果。

允许 null：False

必填条件：按当前管理权限、查询词的匹配结果计数，非负；无结果合法0并保留新增入口；读取失败不伪造0条成功结果。

### 默认与初始化

模式：derived；值：`null`

按当前管理权限、查询词的匹配结果计数，非负；无结果合法0并保留新增入口；读取失败不伪造0条成功结果。

### 校验与关联约束

- 按当前管理权限、查询词的匹配结果计数，非负；无结果合法0并保留新增入口；读取失败不伪造0条成功结果。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：按当前管理权限、查询词的匹配结果计数，非负；无结果合法0并保留新增入口；读取失败不伪造0条成功结果。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：calculated

规则：按当前管理权限、查询词的匹配结果计数，非负；无结果合法0并保留新增入口；读取失败不伪造0条成功结果。

依赖字段：[FLD-070](field-specs.md#FLD-070)

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 0；3

非法/拒绝：
- 读取失败显示正常空列表禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-071
- product-input.json#PAGE-001
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-001/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/70

局部说明：[LOCAL-018](local-logic/LOCAL-018.md)

任务：

测试：CHECK-053

<a id="FIELD-APP-PAGE"></a>

## FIELD-APP-PAGE 应用列表页码

单功能页面／局部明确关联：

- [查询应用列表 · FUNC\-018](features/FUNC-018.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

业务对象：`ApplicationListView`

字段：`page`

类型：整数

格式/枚举/单位/精度：正整数页码，初始第一页；查询变化/删除导致越界回到有效页并重算，不改变应用；生产页容量由工程确定，不能把demo页数冻结。

允许 null：False

必填条件：正整数页码，初始第一页；查询变化/删除导致越界回到有效页并重算，不改变应用；生产页容量由工程确定，不能把demo页数冻结。

### 默认与初始化

模式：literal；值：`1`

首次进入列表或查询条件变化时从第一页读取；后续分页按当前查询计算。

### 校验与关联约束

- 正整数页码，初始第一页；查询变化/删除导致越界回到有效页并重算，不改变应用；生产页容量由工程确定，不能把demo页数冻结。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）

可写：
- 超管（翻页）
- 列表服务（查询变化或页码越界校正有效页）

### 各状态行为

- 输入或接收：正整数页码，初始第一页；查询变化/删除导致越界回到有效页并重算，不改变应用；生产页容量由工程确定，不能把demo页数冻结。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：input

规则：正整数页码，初始第一页；查询变化/删除导致越界回到有效页并重算，不改变应用；生产页容量由工程确定，不能把demo页数冻结。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 1；2

非法/拒绝：
- 0或负页码禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-071
- product-input.json#PAGE-001
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-001/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/70

局部说明：[LOCAL-018](local-logic/LOCAL-018.md)

任务：

测试：CHECK-053

<a id="FIELD-APP-ID"></a>

## FIELD-APP-ID 应用标识

单功能页面／局部明确关联：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [交换指定租户身份 · FUNC\-002](features/FUNC-002.md)
- [查询应用列表 · FUNC\-018](features/FUNC-018.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

业务对象：`Application`

字段：`appId`

类型：字符串

格式/枚举/单位/精度：创建成功生成稳定应用标识，列表详情显示；普通修改/查看保持，删除只该应用不可再获取新身份，历史来源审计保留。原型DEMO标识非生产生成规则。

允许 null：False

必填条件：创建成功生成稳定应用标识，列表详情显示；普通修改/查看保持，删除只该应用不可再获取新身份，历史来源审计保留。原型DEMO标识非生产生成规则。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 创建成功生成稳定应用标识，列表详情显示；普通修改/查看保持，删除只该应用不可再获取新身份，历史来源审计保留。原型DEMO标识非生产生成规则。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）
- 受权后台鉴权服务仅用于应用、授权范围及凭证校验；不授予普通前台管理读取或明文密钥展示权限。

可写：
- 应用管理服务（创建成功生成；普通修改保持）

### 各状态行为

- 输入或接收：创建成功生成稳定应用标识，列表详情显示；普通修改/查看保持，删除只该应用不可再获取新身份，历史来源审计保留。原型DEMO标识非生产生成规则。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 来源与计算

来源类型：system

规则：创建成功生成稳定应用标识，列表详情显示；普通修改/查看保持，删除只该应用不可再获取新身份，历史来源审计保留。原型DEMO标识非生产生成规则。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-APP-001

非法/拒绝：
- 修改名称自动换appId禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#FLD-005
- product-input.json#FLD-069
- product-input.json#FLD-088
- product-input.json#FLD-092
- product-input.json#FLD-094
- product-input.json#PAGE-001
- product-input.json#PAGE-003
- product-input.json#PAGE-004
- product-input.json#PAGE-005
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/0
- pages:PAGE-001/fields/1
- pages:PAGE-003/fields/2
- pages:PAGE-004/fields/0
- pages:PAGE-005/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/4
- project_facts:PRODUCT-FIELD-MAP/fields/68
- project_facts:PRODUCT-FIELD-MAP/fields/87
- project_facts:PRODUCT-FIELD-MAP/fields/91
- project_facts:PRODUCT-FIELD-MAP/fields/93

局部说明：[LOCAL-001](local-logic/LOCAL-001.md)、[LOCAL-002](local-logic/LOCAL-002.md)、[LOCAL-018](local-logic/LOCAL-018.md)、[LOCAL-019](local-logic/LOCAL-019.md)、[LOCAL-020](local-logic/LOCAL-020.md)、[LOCAL-021](local-logic/LOCAL-021.md)

任务：

测试：CHECK-054, CHECK-055, CHECK-056, CHECK-057

<a id="FIELD-APP-CREATED"></a>

## FIELD-APP-CREATED 应用创建时间

单功能页面／局部明确关联：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [查询应用列表 · FUNC\-018](features/FUNC-018.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [交换指定租户身份 · FUNC\-002](features/FUNC-002.md)

业务对象：`Application`

字段：`createdAt`

类型：时间值

格式/枚举/单位/精度：应用首次保存成功生成并保留；查看/修改不重置，取消/失败不生成已保存时间；展示格式不改变原时间，生产编码/时区由工程设计。

允许 null：False

必填条件：应用首次保存成功生成并保留；查看/修改不重置，取消/失败不生成已保存时间；展示格式不改变原时间，生产编码/时区由工程设计。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 应用首次保存成功生成并保留；查看/修改不重置，取消/失败不生成已保存时间；展示格式不改变原时间，生产编码/时区由工程设计。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）

可写：
- 应用管理服务（创建成功生成；普通修改保持）

### 各状态行为

- 输入或接收：应用首次保存成功生成并保留；查看/修改不重置，取消/失败不生成已保存时间；展示格式不改变原时间，生产编码/时区由工程设计。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 来源与计算

来源类型：system

规则：应用首次保存成功生成并保留；查看/修改不重置，取消/失败不生成已保存时间；展示格式不改变原时间，生产编码/时区由工程设计。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 应用创建成功的合成时间

非法/拒绝：
- 普通修改更新创建时间禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-069
- product-input.json#FLD-091
- product-input.json#FLD-094
- product-input.json#PAGE-001
- product-input.json#PAGE-004
- product-input.json#PAGE-005
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-001/fields/1
- pages:PAGE-004/fields/2
- pages:PAGE-005/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/68
- project_facts:PRODUCT-FIELD-MAP/fields/90
- project_facts:PRODUCT-FIELD-MAP/fields/93

局部说明：[LOCAL-001](local-logic/LOCAL-001.md)、[LOCAL-018](local-logic/LOCAL-018.md)、[LOCAL-019](local-logic/LOCAL-019.md)、[LOCAL-020](local-logic/LOCAL-020.md)、[LOCAL-021](local-logic/LOCAL-021.md)

任务：

测试：CHECK-053, CHECK-054, CHECK-056

<a id="FLD-089"></a>

## FLD-089 应用可访问租户

单功能页面／局部明确关联：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [交换指定租户身份 · FUNC\-002](features/FUNC-002.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

业务对象：`Application`

字段：`authorizedTenantIds`

类型：租户标识集合

格式/枚举/单位/精度：超管新增/修改必选已有业务租户，空集合不满足保存条件；一个租户可授权多应用。修改成功后只撤被移除租户业务访问，取消/失败原权限保持；任务不与应用绑定。

允许 null：False

必填条件：超管新增/修改必选已有业务租户，空集合不满足保存条件；一个租户可授权多应用。修改成功后只撤被移除租户业务访问，取消/失败原权限保持；任务不与应用绑定。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 超管新增/修改必选已有业务租户，空集合不满足保存条件；一个租户可授权多应用。修改成功后只撤被移除租户业务访问，取消/失败原权限保持；任务不与应用绑定。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）
- 受权后台鉴权服务仅用于应用、授权范围及凭证校验；不授予普通前台管理读取或明文密钥展示权限。

可写：
- 超管（名称/授权在新增或修改成功时）

### 各状态行为

- 输入或接收：超管新增/修改必选已有业务租户，空集合不满足保存条件；一个租户可授权多应用。修改成功后只撤被移除租户业务访问，取消/失败原权限保持；任务不与应用绑定。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 来源与计算

来源类型：input

规则：超管新增/修改必选已有业务租户，空集合不满足保存条件；一个租户可授权多应用。修改成功后只撤被移除租户业务访问，取消/失败原权限保持；任务不与应用绑定。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- [DEMO-TENANT-A]

非法/拒绝：
- 未授权租户交换token拒绝；空集不可保存

### 依据、使用位置与验证

来源：
- product-input.json#FLD-089
- product-input.json#FLD-091
- product-input.json#FLD-095
- product-input.json#PAGE-003
- product-input.json#PAGE-004
- product-input.json#PAGE-005
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-003/fields/1
- pages:PAGE-004/fields/2
- pages:PAGE-005/fields/1
- project_facts:PRODUCT-FIELD-MAP/fields/88
- project_facts:PRODUCT-FIELD-MAP/fields/90
- project_facts:PRODUCT-FIELD-MAP/fields/94

局部说明：[LOCAL-001](local-logic/LOCAL-001.md)、[LOCAL-002](local-logic/LOCAL-002.md)、[LOCAL-019](local-logic/LOCAL-019.md)、[LOCAL-020](local-logic/LOCAL-020.md)、[LOCAL-021](local-logic/LOCAL-021.md)

任务：

测试：CHECK-017, CHECK-055, CHECK-056, CHECK-057

<a id="FLD-090"></a>

## FLD-090 应用名称

单功能页面／局部明确关联：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [查询应用列表 · FUNC\-018](features/FUNC-018.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [交换指定租户身份 · FUNC\-002](features/FUNC-002.md)

业务对象：`Application`

字段：`name`

类型：字符串

格式/枚举/单位/精度：超管新增/修改必填非空名称；详情列表一致显示，取消/失败不改旧值；不把demo60字或重名限制上升为冻结规则，生产安全长度/重名策略另核。

允许 null：False

必填条件：超管新增/修改必填非空名称；详情列表一致显示，取消/失败不改旧值；不把demo60字或重名限制上升为冻结规则，生产安全长度/重名策略另核。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 超管新增/修改必填非空名称；详情列表一致显示，取消/失败不改旧值；不把demo60字或重名限制上升为冻结规则，生产安全长度/重名策略另核。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）

可写：
- 超管（名称/授权在新增或修改成功时）

### 各状态行为

- 输入或接收：超管新增/修改必填非空名称；详情列表一致显示，取消/失败不改旧值；不把demo60字或重名限制上升为冻结规则，生产安全长度/重名策略另核。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 来源与计算

来源类型：input

规则：超管新增/修改必填非空名称；详情列表一致显示，取消/失败不改旧值；不把demo60字或重名限制上升为冻结规则，生产安全长度/重名策略另核。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 演示DCC应用

非法/拒绝：
- 空白名称保存失败且无写入

### 依据、使用位置与验证

来源：
- product-input.json#FLD-069
- product-input.json#FLD-090
- product-input.json#FLD-092
- product-input.json#FLD-096
- product-input.json#PAGE-001
- product-input.json#PAGE-003
- product-input.json#PAGE-004
- product-input.json#PAGE-005
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-001/fields/1
- pages:PAGE-003/fields/0
- pages:PAGE-004/fields/0
- pages:PAGE-005/fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/68
- project_facts:PRODUCT-FIELD-MAP/fields/89
- project_facts:PRODUCT-FIELD-MAP/fields/91
- project_facts:PRODUCT-FIELD-MAP/fields/95

局部说明：[LOCAL-001](local-logic/LOCAL-001.md)、[LOCAL-018](local-logic/LOCAL-018.md)、[LOCAL-019](local-logic/LOCAL-019.md)、[LOCAL-020](local-logic/LOCAL-020.md)、[LOCAL-021](local-logic/LOCAL-021.md)

任务：

测试：CHECK-053, CHECK-054, CHECK-055, CHECK-056

<a id="FLD-093"></a>

## FLD-093 应用接入密钥

单功能页面／局部明确关联：

- [修改应用 · FUNC\-001](features/FUNC-001.md)
- [交换指定租户身份 · FUNC\-002](features/FUNC-002.md)
- [创建应用 · FUNC\-019](features/FUNC-019.md)
- [查看应用详情 · FUNC\-020](features/FUNC-020.md)
- [删除应用 · FUNC\-021](features/FUNC-021.md)

业务对象：`Application`

字段：`appSecret`

类型：不透明凭证

格式/枚举/单位/精度：创建成功生成，详情默认掩码，可按已批准交互查看/复制；只用于获取授权租户token，普通修改不重置。当前只不可用合成值；生产生成/存储及查看能力须工程安全设计。

允许 null：False

必填条件：创建成功生成，详情默认掩码，可按已批准交互查看/复制；只用于获取授权租户token，普通修改不重置。当前只不可用合成值；生产生成/存储及查看能力须工程安全设计。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 创建成功生成，详情默认掩码，可按已批准交互查看/复制；只用于获取授权租户token，普通修改不重置。当前只不可用合成值；生产生成/存储及查看能力须工程安全设计。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 超管（应用管理授权范围）
- 受权后台鉴权服务仅用于应用、授权范围及凭证校验；不授予普通前台管理读取或明文密钥展示权限。

可写：
- 应用管理服务（创建成功生成；普通修改保持）

### 各状态行为

- 输入或接收：创建成功生成，详情默认掩码，可按已批准交互查看/复制；只用于获取授权租户token，普通修改不重置。当前只不可用合成值；生产生成/存储及查看能力须工程安全设计。
- 校验与确认：仅超管可进入或调用应用管理；非超管菜单、页面直达和管理调用均拒绝。取消/失败不写业务；查看/查询不改变应用凭证或授权。
- 保存后或操作结束：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 来源与计算

来源类型：system

规则：创建成功生成，详情默认掩码，可按已批准交互查看/复制；只用于获取授权租户token，普通修改不重置。当前只不可用合成值；生产生成/存储及查看能力须工程安全设计。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：新增应用成功时保存；名称/授权仅对应修改成功时更新，appId/密钥/创建时间保持；删除后业务来源审计仍保留，真实秘密存储与撤权机制由工程设计。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DEMO-ONLY-SECRET

非法/拒绝：
- 列表明文批量暴露或普通修改重置禁止

### 依据、使用位置与验证

来源：
- product-input.json#API-001
- product-input.json#FLD-005
- product-input.json#FLD-088
- product-input.json#FLD-093
- product-input.json#FLD-094
- product-input.json#PAGE-003
- product-input.json#PAGE-004
- product-input.json#PAGE-005
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- interfaces:API-001/request_fields/0
- pages:PAGE-003/fields/2
- pages:PAGE-004/fields/1
- pages:PAGE-005/fields/2
- project_facts:PRODUCT-FIELD-MAP/fields/4
- project_facts:PRODUCT-FIELD-MAP/fields/87
- project_facts:PRODUCT-FIELD-MAP/fields/92
- project_facts:PRODUCT-FIELD-MAP/fields/93

局部说明：[LOCAL-001](local-logic/LOCAL-001.md)、[LOCAL-002](local-logic/LOCAL-002.md)、[LOCAL-019](local-logic/LOCAL-019.md)、[LOCAL-020](local-logic/LOCAL-020.md)、[LOCAL-021](local-logic/LOCAL-021.md)

任务：

测试：CHECK-045, CHECK-054, CHECK-055, CHECK-056, CHECK-058

<a id="FIELD-ORIGINAL-IMPORT-AT"></a>

## FIELD-ORIGINAL-IMPORT-AT 原始导入时间

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`originalImportDateTime`

类型：时间值

格式/枚举/单位/精度：每次新业务记录首次本地接收时保存原始导入审计时刻，当前已批准原型取该记录receivedAt；同请求重传不重算，新业务不继承旧主批时间。历史记录缺原值时保留未知，不用当前时间补造，不参与每日衰减。DCC接口不新增必传原导入时间。

允许 null：True

必填条件：新有效业务记录保存时产生；历史记录原值缺失可保留未知，不要求DCC另传时间字段。

### 默认与初始化

模式：derived；值：`null`

每次新业务记录首次本地接收时保存原始导入审计时刻，当前已批准原型取该记录receivedAt；同请求重传不重算，新业务不继承旧主批时间。历史记录缺原值时保留未知，不用当前时间补造，不参与每日衰减。DCC接口不新增必传原导入时间。

### 校验与关联约束

- 每次新业务记录首次本地接收时保存原始导入审计时刻，当前已批准原型取该记录receivedAt；同请求重传不重算，新业务不继承旧主批时间。历史记录缺原值时保留未知，不用当前时间补造，不参与每日衰减。DCC接口不新增必传原导入时间。
- 保持真实时间原值和可解释的时间编码；生产时区与编码由工程统一，迁移未知不可当新接收时间。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收服务在本次新业务记录首次保存时生成；保存后作为审计原值保留，不允许运营或重传改写。

### 各状态行为

- 新业务保存：每次新业务记录首次本地接收时保存原始导入审计时刻，当前已批准原型取该记录receivedAt；同请求重传不重算，新业务不继承旧主批时间。历史记录缺原值时保留未知，不用当前时间补造，不参与每日衰减。DCC接口不新增必传原导入时间。
- 重传及后续事件：沿用该记录原审计值，不因新的主批、供应商结果、删除或失败清理重新赋值。

### 来源与计算

来源类型：system

规则：每次新业务记录首次本地接收时保存原始导入审计时刻，当前已批准原型取该记录receivedAt；同请求重传不重算，新业务不继承旧主批时间。历史记录缺原值时保留未知，不用当前时间补造，不参与每日衰减。DCC接口不新增必传原导入时间。

依赖字段：[FIELD-RECEIVED-AT](field-specs.md#FIELD-RECEIVED-AT)

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：每次新业务记录首次本地接收时保存原始导入审计时刻，当前已批准原型取该记录receivedAt；同请求重传不重算，新业务不继承旧主批时间。历史记录缺原值时保留未知，不用当前时间补造，不参与每日衰减。DCC接口不新增必传原导入时间。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 本次新业务记录首次接收时刻；历史原值缺失保留未知

非法/拒绝：
- 把重传时间覆盖原值或要求DCC补一个新必传时间字段

### 依据、使用位置与验证

来源：
- product-input.json#FLD-075
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/3
- project_facts:PRODUCT-FIELD-MAP/fields/74

局部说明：[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-014, CHECK-015, CHECK-032

<a id="FIELD-RECEIVED-AT"></a>

## FIELD-RECEIVED-AT 本次本地接收时间

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`receivedAt`

类型：时间值

格式/枚举/单位/精度：有效新行在本次本地接收时记录；同任务同priority按本地导入先后FIFO，不同任务独立；技术重传保留原时间不重排，真实时区表示由工程落实。

允许 null：False

必填条件：有效新行在本次本地接收时记录；同任务同priority按本地导入先后FIFO，不同任务独立；技术重传保留原时间不重排，真实时区表示由工程落实。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 有效新行在本次本地接收时记录；同任务同priority按本地导入先后FIFO，不同任务独立；技术重传保留原时间不重排，真实时区表示由工程落实。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：有效新行在本次本地接收时记录；同任务同priority按本地导入先后FIFO，不同任务独立；技术重传保留原时间不重排，真实时区表示由工程落实。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：system

规则：有效新行在本次本地接收时记录；同任务同priority按本地导入先后FIFO，不同任务独立；技术重传保留原时间不重排，真实时区表示由工程落实。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 本次保存的合成时间

非法/拒绝：
- 技术重试更新时间而插队禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-075
- product-input.json#FLD-080
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/11
- pages:PAGE-002/fields/3
- project_facts:PRODUCT-FIELD-MAP/fields/74
- project_facts:PRODUCT-FIELD-MAP/fields/79

局部说明：[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-014, CHECK-046

<a id="FIELD-BATCH-CREATED-AT"></a>

## FIELD-BATCH-CREATED-AT 本批次创建时间

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`newBatchCreatedAt`

类型：时间值

格式/枚举/单位/精度：新批次保存时记录，仅审计并与主批保存稳定顺序一致；旧批不改；精度相同不以结果时间打破主批顺序，稳定序列由工程实现。

允许 null：False

必填条件：新批次保存时记录，仅审计并与主批保存稳定顺序一致；旧批不改；精度相同不以结果时间打破主批顺序，稳定序列由工程实现。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 新批次保存时记录，仅审计并与主批保存稳定顺序一致；旧批不改；精度相同不以结果时间打破主批顺序，稳定序列由工程实现。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：新批次保存时记录，仅审计并与主批保存稳定顺序一致；旧批不改；精度相同不以结果时间打破主批顺序，稳定序列由工程实现。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：system

规则：新批次保存时记录，仅审计并与主批保存稳定顺序一致；旧批不改；精度相同不以结果时间打破主批顺序，稳定序列由工程实现。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 新主保存时间

非法/拒绝：
- 收到晚结果重写批次创建时间禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-075
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/3
- project_facts:PRODUCT-FIELD-MAP/fields/74

局部说明：[LOCAL-004](local-logic/LOCAL-004.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-014, CHECK-048

<a id="FIELD-RECEIVED-SEQUENCE"></a>

## FIELD-RECEIVED-SEQUENCE 本地保存稳定顺序

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`localReceivedSequence`

类型：有序标识

格式/枚举/单位/精度：保持同任务有效行的保存先后，支撑同priority FIFO及同组最近已保存主判定；仅主参与选根，技术重试不新增顺序。并发原子实现由工程补齐。

允许 null：False

必填条件：保持同任务有效行的保存先后，支撑同priority FIFO及同组最近已保存主判定；仅主参与选根，技术重试不新增顺序。并发原子实现由工程补齐。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保持同任务有效行的保存先后，支撑同priority FIFO及同组最近已保存主判定；仅主参与选根，技术重试不新增顺序。并发原子实现由工程补齐。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：保持同任务有效行的保存先后，支撑同priority FIFO及同组最近已保存主判定；仅主参与选根，技术重试不新增顺序。并发原子实现由工程补齐。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：system

规则：保持同任务有效行的保存先后，支撑同priority FIFO及同组最近已保存主判定；仅主参与选根，技术重试不新增顺序。并发原子实现由工程补齐。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 先保存B001再B002

非法/拒绝：
- 按priority或最新子批选主禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-080
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/11
- project_facts:PRODUCT-FIELD-MAP/fields/79

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-046, CHECK-048, CHECK-050

<a id="FLD-078"></a>

## FLD-078 任务导入来源

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`Task`

字段：`importSource`

类型：枚举

格式/枚举/单位/精度：任务创建确认前选择DCC接口或手工，提交创建后锁定不可切换/混用；记录页只读。不存在默认推定来源；入口按保存来源分派，不改变历史任务状态规则。

允许 null：False

必填条件：任务创建确认前选择DCC接口或手工，提交创建后锁定不可切换/混用；记录页只读。不存在默认推定来源；入口按保存来源分派，不改变历史任务状态规则。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 任务创建确认前选择DCC接口或手工，提交创建后锁定不可切换/混用；记录页只读。不存在默认推定来源；入口按保存来源分派，不改变历史任务状态规则。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 有权DCC调用方（仅接口字段）或有权运营（仅手工/查询字段），按字段适用场景

### 各状态行为

- 输入或接收：任务创建确认前选择DCC接口或手工，提交创建后锁定不可切换/混用；记录页只读。不存在默认推定来源；入口按保存来源分派，不改变历史任务状态规则。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：input

规则：任务创建确认前选择DCC接口或手工，提交创建后锁定不可切换/混用；记录页只读。不存在默认推定来源；入口按保存来源分派，不改变历史任务状态规则。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- DCC接口；手工

非法/拒绝：
- 已创建DCC任务用手工入口写入拒绝

### 依据、使用位置与验证

来源：
- product-input.json#FLD-078
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/0
- project_facts:PRODUCT-FIELD-MAP/fields/77

局部说明：[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004-A](local-logic/LOCAL-004-A.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-016](local-logic/LOCAL-016.md)

任务：

测试：CHECK-029, CHECK-036, CHECK-059

<a id="FIELD-SUBMISSION-STATE"></a>

## FIELD-SUBMISSION-STATE 供应商提交状态

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ImportRecord`

字段：`submissionState`

类型：枚举

格式/枚举/单位/精度：区分待提交/已提交有响应/结果未知；新有效记录自动提交，未知不为重排或同请求重试重复提交。排序仅待提交且不承诺真实拨号顺序。

允许 null：False

必填条件：区分待提交/已提交有响应/结果未知；新有效记录自动提交，未知不为重排或同请求重试重复提交。排序仅待提交且不承诺真实拨号顺序。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 区分待提交/已提交有响应/结果未知；新有效记录自动提交，未知不为重排或同请求重试重复提交。排序仅待提交且不承诺真实拨号顺序。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：区分待提交/已提交有响应/结果未知；新有效记录自动提交，未知不为重排或同请求重试重复提交。排序仅待提交且不承诺真实拨号顺序。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 来源与计算

来源类型：system

规则：区分待提交/已提交有响应/结果未知；新有效记录自动提交，未知不为重排或同请求重试重复提交。排序仅待提交且不承诺真实拨号顺序。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：首次有效业务保存时写入，后续仅按本字段规则更新状态；请求技术重试返回原已保存值，供应商删除/失败下载不删除必要业务关联和幂等证据。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 待提交；结果未知

非法/拒绝：
- 超时为抢顺序重交禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-080
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/11
- project_facts:PRODUCT-FIELD-MAP/fields/79

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-011, CHECK-039, CHECK-046

<a id="FIELD-FRAGMENT-COMPLETENESS"></a>

## FIELD-FRAGMENT-COMPLETENESS 失败分片完整性

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`FailurePushGroup`

字段：`completeness`

类型：枚举

格式/枚举/单位/精度：未知/未收齐/声明组已收齐/冲突待核分开，依声明与唯一已收到片号计算；收齐仅该失败组，不能宣布全导入终态或无新迟到。

允许 null：False

必填条件：未知/未收齐/声明组已收齐/冲突待核分开，依声明与唯一已收到片号计算；收齐仅该失败组，不能宣布全导入终态或无新迟到。

### 默认与初始化

模式：derived；值：`null`

未知/未收齐/声明组已收齐/冲突待核分开，依声明与唯一已收到片号计算；收齐仅该失败组，不能宣布全导入终态或无新迟到。

### 校验与关联约束

- 未知/未收齐/声明组已收齐/冲突待核分开，依声明与唯一已收到片号计算；收齐仅该失败组，不能宣布全导入终态或无新迟到。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：未知/未收齐/声明组已收齐/冲突待核分开，依声明与唯一已收到片号计算；收齐仅该失败组，不能宣布全导入终态或无新迟到。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 来源与计算

来源类型：calculated

规则：未知/未收齐/声明组已收齐/冲突待核分开，依声明与唯一已收到片号计算；收齐仅该失败组，不能宣布全导入终态或无新迟到。

依赖字段：[FLD-028](field-specs.md#FLD-028)、[FLD-035](field-specs.md#FLD-035)

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：每次收到53声明与分片时保存原值、片号及去重证据，按已知片号重算该声明组完整性；冲突待核，乱序迟到仍处理；下载明细清理不抹必要分片和去重状态。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 已知2片收到1片=未收齐

非法/拒绝：
- 未收到分片推定零失败/全部完成禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-073
- product-input.json#FLD-077
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/10
- pages:PAGE-002/fields/8
- project_facts:PRODUCT-FIELD-MAP/fields/72
- project_facts:PRODUCT-FIELD-MAP/fields/76

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-040, CHECK-042, CHECK-043

<a id="FIELD-EXPORT-SNAPSHOT"></a>

## FIELD-EXPORT-SNAPSHOT 本次失败导出快照

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`FailureExport`

字段：`snapshot`

类型：对象

格式/枚举/单位/精度：点击导出冻结本次失败明细集合及分片完整性，后到新失败不加入旧快照；失败或中断保留，可信下载成功只清本快照明细和对应文件，必要去重/关联/交付状态保留。

允许 null：False

必填条件：点击导出冻结本次失败明细集合及分片完整性，后到新失败不加入旧快照；失败或中断保留，可信下载成功只清本快照明细和对应文件，必要去重/关联/交付状态保留。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 点击导出冻结本次失败明细集合及分片完整性，后到新失败不加入旧快照；失败或中断保留，可信下载成功只清本快照明细和对应文件，必要去重/关联/交付状态保留。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：点击导出冻结本次失败明细集合及分片完整性，后到新失败不加入旧快照；失败或中断保留，可信下载成功只清本快照明细和对应文件，必要去重/关联/交付状态保留。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：收到可信失败时保存明细；生成快照时保存范围及状态；仅本次快照可信下载成功清理对应明细/文件，失败中断及后到新失败保留，必要关联去重交付证据持续保留。

### 来源与计算

来源类型：system

规则：点击导出冻结本次失败明细集合及分片完整性，后到新失败不加入旧快照；失败或中断保留，可信下载成功只清本快照明细和对应文件，必要去重/关联/交付状态保留。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：收到可信失败时保存明细；生成快照时保存范围及状态；仅本次快照可信下载成功清理对应明细/文件，失败中断及后到新失败保留，必要关联去重交付证据持续保留。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 快照仅包含当时失败A/B

非法/拒绝：
- 下载成功清空后来失败C禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-072
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/9
- project_facts:PRODUCT-FIELD-MAP/fields/71

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-008, CHECK-042, CHECK-043

<a id="FIELD-DOWNLOAD-STATE"></a>

## FIELD-DOWNLOAD-STATE 失败快照下载状态

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`FailureExport`

字段：`downloadState`

类型：枚举

格式/枚举/单位/精度：未下载/处理中/失败中断/可信成功分开；只有可信成功才清本次明细和文件。真实成功信号待工程核实，原型显式合成，不把点击下载当成功。

允许 null：False

必填条件：未下载/处理中/失败中断/可信成功分开；只有可信成功才清本次明细和文件。真实成功信号待工程核实，原型显式合成，不把点击下载当成功。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 未下载/处理中/失败中断/可信成功分开；只有可信成功才清本次明细和文件。真实成功信号待工程核实，原型显式合成，不把点击下载当成功。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：未下载/处理中/失败中断/可信成功分开；只有可信成功才清本次明细和文件。真实成功信号待工程核实，原型显式合成，不把点击下载当成功。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：为本次失败快照开始下载时记处理状态；收到可信下载结果后更新成功/失败/中断，只有可信成功才删除该快照对应明细和文件，后到新失败与必要证据保留；真实成功信号仍待工程落实。

### 来源与计算

来源类型：system

规则：未下载/处理中/失败中断/可信成功分开；只有可信成功才清本次明细和文件。真实成功信号待工程核实，原型显式合成，不把点击下载当成功。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：为本次失败快照开始下载时记处理状态；收到可信下载结果后更新成功/失败/中断，只有可信成功才删除该快照对应明细和文件，后到新失败与必要证据保留；真实成功信号仍待工程落实。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 中断=保留明细

非法/拒绝：
- 仅点击按钮即删除明细禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-083
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/82

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-008, CHECK-042, CHECK-043

<a id="FIELD-DEDUP-EVIDENCE"></a>

## FIELD-DEDUP-EVIDENCE 必要去重与关联留存

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`BusinessEvidence`

字段：`dedupAssociationState`

类型：对象

格式/枚举/单位/精度：保存原请求逐行幂等回执、精确供应商/通话关联、已导出事件标识及分片/交付去重；供应商删除或失败快照清理不删除这些必要状态。具体键/存储由工程设计。

允许 null：False

必填条件：保存原请求逐行幂等回执、精确供应商/通话关联、已导出事件标识及分片/交付去重；供应商删除或失败快照清理不删除这些必要状态。具体键/存储由工程设计。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 保存原请求逐行幂等回执、精确供应商/通话关联、已导出事件标识及分片/交付去重；供应商删除或失败快照清理不删除这些必要状态。具体键/存储由工程设计。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：保存原请求逐行幂等回执、精确供应商/通话关联、已导出事件标识及分片/交付去重；供应商删除或失败快照清理不删除这些必要状态。具体键/存储由工程设计。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：出现请求接收、事件去重、关联核验、快照下载或结果交付等对应行为时保存该行为的证据与状态；未可信SIP独立保存，真实矛盾保持待核；清理失败明细与供应商删除不清必要关联、幂等、分片或交付状态。

### 来源与计算

来源类型：system

规则：保存原请求逐行幂等回执、精确供应商/通话关联、已导出事件标识及分片/交付去重；供应商删除或失败快照清理不删除这些必要状态。具体键/存储由工程设计。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：出现请求接收、事件去重、关联核验、快照下载或结果交付等对应行为时保存该行为的证据与状态；未可信SIP独立保存，真实矛盾保持待核；清理失败明细与供应商删除不清必要关联、幂等、分片或交付状态。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 已导出事件重复不再生明细

非法/拒绝：
- 清下载明细同时清幂等记录禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-077
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/10
- project_facts:PRODUCT-FIELD-MAP/fields/76

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-042, CHECK-050, CHECK-052

<a id="FIELD-DELIVERY-STATE"></a>

## FIELD-DELIVERY-STATE DCC逐次交付状态

单功能页面／局部明确关联：

- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`DccDelivery`

字段：`state`

类型：枚举

格式/枚举/单位/精度：接口结果每次回传并记录待发送/等待回执确认/发送失败可补送/确认成功及版本；手工不创建DCC交付。补送重用同业务对象，不新导入或算新呼叫；超时不改变业务结果。

允许 null：True

必填条件：接口结果每次回传并记录待发送/等待回执确认/发送失败可补送/确认成功及版本；手工不创建DCC交付。补送重用同业务对象，不新导入或算新呼叫；超时不改变业务结果。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 接口结果每次回传并记录待发送/等待回执确认/发送失败可补送/确认成功及版本；手工不创建DCC交付。补送重用同业务对象，不新导入或算新呼叫；超时不改变业务结果。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台结果交付服务（仅当前业务结果的交付状态）
- 经核实的固定DCC接收端确认（保存真实ACK证据，不以供应商响应替代）

### 各状态行为

- 输入或接收：接口结果每次回传并记录待发送/等待回执确认/发送失败可补送/确认成功及版本；手工不创建DCC交付。补送重用同业务对象，不新导入或算新呼叫；超时不改变业务结果。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：仅接口来源的每次已关联业务结果或可信晚更新形成待交付内容时保存交付状态和版本；向固定DCC接收端发送后保存实际ACK/失败/未知证据；失败补送更新交付而不新建导入或呼叫，手工不创建该交付。

### 来源与计算

来源类型：system

规则：接口结果每次回传并记录待发送/等待回执确认/发送失败可补送/确认成功及版本；手工不创建DCC交付。补送重用同业务对象，不新导入或算新呼叫；超时不改变业务结果。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：仅接口来源的每次已关联业务结果或可信晚更新形成待交付内容时保存交付状态和版本；向固定DCC接收端发送后保存实际ACK/失败/未知证据；失败补送更新交付而不新建导入或呼叫，手工不创建该交付。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 失败待补送；确认成功

非法/拒绝：
- 补送触发新供应商导入禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-077
- product-input.json#FLD-083
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/10
- pages:PAGE-002/fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/76
- project_facts:PRODUCT-FIELD-MAP/fields/82

局部说明：[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-035, CHECK-037, CHECK-041, CHECK-052

<a id="FIELD-RESULT-VERSION"></a>

## FIELD-RESULT-VERSION 同一结果更新版本

单功能页面／局部明确关联：

- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`BusinessResult`

字段：`version`

类型：有序标识

格式/枚举/单位/精度：可信精准晚更新在同一call对象更新来源字段并形成相应交付版本，重复不新建实际呼叫；未可信SIP不改已确认业务版本。版本实现不假定生产序列格式。

允许 null：False

必填条件：可信精准晚更新在同一call对象更新来源字段并形成相应交付版本，重复不新建实际呼叫；未可信SIP不改已确认业务版本。版本实现不假定生产序列格式。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 可信精准晚更新在同一call对象更新来源字段并形成相应交付版本，重复不新建实际呼叫；未可信SIP不改已确认业务版本。版本实现不假定生产序列格式。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：可信精准晚更新在同一call对象更新来源字段并形成相应交付版本，重复不新建实际呼叫；未可信SIP不改已确认业务版本。版本实现不假定生产序列格式。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 来源与计算

来源类型：system

规则：可信精准晚更新在同一call对象更新来源字段并形成相应交付版本，重复不新建实际呼叫；未可信SIP不改已确认业务版本。版本实现不假定生产序列格式。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：确认本次导入、真实呼叫、无话单稳定失败事件或精准删除结果时保存该结果的阶段、发生时间/原因与精确关联；可信晚更新在原对象更新版本并回传，未知证据保留待核；不以新导入记录存在提前生成实际呼叫。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 同call可信SIP更新至后续版本

非法/拒绝：
- 纯重复包增加实际呼叫禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-083
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/82

局部说明：[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-035, CHECK-052, CHECK-062

<a id="FIELD-REVIEW-REASON"></a>

## FIELD-REVIEW-REASON 待核原因

单功能页面／局部明确关联：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)

业务对象：`BusinessEvidence`

字段：`reviewReason`

类型：字符串集合

格式/枚举/单位/精度：关联不明、来源不可信、声明冲突、真实业务矛盾分别记录；空集合表示当前无待核原因而非未读取。纯未可信SIP独立待核，不冒充可信非SIP冲突阻挡随后可信更新。

允许 null：False

必填条件：关联不明、来源不可信、声明冲突、真实业务矛盾分别记录；空集合表示当前无待核原因而非未读取。纯未可信SIP独立待核，不冒充可信非SIP冲突阻挡随后可信更新。

### 默认与初始化

模式：literal；值：`[]`

新对象尚无该类证据时为空集合；读取失败不是合法空集合，不覆盖已保存证据。

### 校验与关联约束

- 关联不明、来源不可信、声明冲突、真实业务矛盾分别记录；空集合表示当前无待核原因而非未读取。纯未可信SIP独立待核，不冒充可信非SIP冲突阻挡随后可信更新。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台业务处理服务（按确定业务规则生成/计算）

### 各状态行为

- 输入或接收：关联不明、来源不可信、声明冲突、真实业务矛盾分别记录；空集合表示当前无待核原因而非未读取。纯未可信SIP独立待核，不冒充可信非SIP冲突阻挡随后可信更新。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：出现请求接收、事件去重、关联核验、快照下载或结果交付等对应行为时保存该行为的证据与状态；未可信SIP独立保存，真实矛盾保持待核；清理失败明细与供应商删除不清必要关联、幂等、分片或交付状态。

### 来源与计算

来源类型：system

规则：关联不明、来源不可信、声明冲突、真实业务矛盾分别记录；空集合表示当前无待核原因而非未读取。纯未可信SIP独立待核，不冒充可信非SIP冲突阻挡随后可信更新。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：出现请求接收、事件去重、关联核验、快照下载或结果交付等对应行为时保存该行为的证据与状态；未可信SIP独立保存，真实矛盾保持待核；清理失败明细与供应商删除不清必要关联、幂等、分片或交付状态。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- [关联存在多候选]

非法/拒绝：
- 随意清除真实矛盾并伪造成功禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-083
- product-input.json#FLD-084
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/15
- pages:PAGE-002/fields/6
- project_facts:PRODUCT-FIELD-MAP/fields/82
- project_facts:PRODUCT-FIELD-MAP/fields/83

局部说明：[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-006](local-logic/LOCAL-006.md)、[LOCAL-009](local-logic/LOCAL-009.md)、[LOCAL-010](local-logic/LOCAL-010.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)、[LOCAL-017](local-logic/LOCAL-017.md)

任务：

测试：CHECK-035, CHECK-043, CHECK-049, CHECK-062

<a id="FIELD-UNTRUSTED-SIP"></a>

## FIELD-UNTRUSTED-SIP 独立未可信SIP证据

单功能页面／局部明确关联：

- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`BusinessEvidence`

字段：`untrustedSipEvidence`

类型：对象集合

格式/枚举/单位/精度：独立保存未可信纯SIP包及原因，空集合合法；不污染原call、不得改变其已确认结果；随后准确可信call/SIP更新仍可执行，无新增呼叫。

允许 null：False

必填条件：独立保存未可信纯SIP包及原因，空集合合法；不污染原call、不得改变其已确认结果；随后准确可信call/SIP更新仍可执行，无新增呼叫。

### 默认与初始化

模式：literal；值：`[]`

新对象尚无该类证据时为空集合；读取失败不是合法空集合，不覆盖已保存证据。

### 校验与关联约束

- 独立保存未可信纯SIP包及原因，空集合合法；不污染原call、不得改变其已确认结果；随后准确可信call/SIP更新仍可执行，无新增呼叫。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有权租户业务身份/运营（仅当前租户任务）
- 平台业务处理服务（仅受权作用域）

可写：
- 平台接收处理（验证供应商来源并准确关联后）；未知证据只写待核记录

### 各状态行为

- 输入或接收：独立保存未可信纯SIP包及原因，空集合合法；不污染原call、不得改变其已确认结果；随后准确可信call/SIP更新仍可执行，无新增呼叫。
- 校验与确认：仅在上述适用作用域/权限和证据条件满足时接受；缺失、非法或冲突按本字段说明反馈，外部未知不伪造成已确认值。
- 保存后或操作结束：出现请求接收、事件去重、关联核验、快照下载或结果交付等对应行为时保存该行为的证据与状态；未可信SIP独立保存，真实矛盾保持待核；清理失败明细与供应商删除不清必要关联、幂等、分片或交付状态。

### 来源与计算

来源类型：external

规则：独立保存未可信纯SIP包及原因，空集合合法；不污染原call、不得改变其已确认结果；随后准确可信call/SIP更新仍可执行，无新增呼叫。

依赖字段：无

### 保存与更新

方式：stored

物理映射：由开发补充

业务保存或更新时机：出现请求接收、事件去重、关联核验、快照下载或结果交付等对应行为时保存该行为的证据与状态；未可信SIP独立保存，真实矛盾保持待核；清理失败明细与供应商删除不清必要关联、幂等、分片或交付状态。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 一条未可信SIP原包

非法/拒绝：
- 将未可信包直接并入call正式字段禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-084
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/15
- project_facts:PRODUCT-FIELD-MAP/fields/83

局部说明：[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)

任务：

测试：CHECK-062

<a id="FIELD-CSV-TEXT"></a>

## FIELD-CSV-TEXT 手工当前CSV文本

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ManualImportDraft`

字段：`csvText`

类型：字符串

格式/枚举/单位/精度：仅手工来源有权任务导入草稿；空文本无有效预览；每次文本变化立即使旧预览不可提交；不新增DCC requestId/isNewBatch输入。

允许 null：False

必填条件：仅手工来源有权任务导入草稿；空文本无有效预览；每次文本变化立即使旧预览不可提交；不新增DCC requestId/isNewBatch输入。

### 默认与初始化

模式：literal；值：`""`

仅新打开当前查询/草稿时为空文本；编辑保留当前输入，不自动恢复旧草稿。

### 校验与关联约束

- 仅手工来源有权任务导入草稿；空文本无有效预览；每次文本变化立即使旧预览不可提交；不新增DCC requestId/isNewBatch输入。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 既有导入权限运营（仅当前租户的手工来源任务）

可写：
- 既有导入权限运营（当前手工草稿输入）

### 各状态行为

- 输入或接收：仅手工来源有权任务导入草稿；空文本无有效预览；每次文本变化立即使旧预览不可提交；不新增DCC requestId/isNewBatch输入。
- 校验与确认：仅既有有权运营且为手工来源任务可编辑，提交前核验当前文本与有效预览完全对应；取消或失败不提交旧草稿。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：input

规则：仅手工来源有权任务导入草稿；空文本无有效预览；每次文本变化立即使旧预览不可提交；不新增DCC requestId/isNewBatch输入。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 含leadCode、phone、priority的合成CSV

非法/拒绝：
- 改文本后提交旧草稿禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-081
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/80

局部说明：[LOCAL-004-A](local-logic/LOCAL-004-A.md)

任务：

测试：CHECK-060

<a id="FIELD-CSV-PREVIEW"></a>

## FIELD-CSV-PREVIEW 当前有效预览草稿

单功能页面／局部明确关联：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`ManualImportDraft`

字段：`preview`

类型：对象或null

格式/枚举/单位/精度：仅当前文本成功预览后保存当前行集合及文本对应证据；文本改变或预览失败清除/冻结旧草稿，提交前重核一致；统一/逐条priority只改当前有效草稿。

允许 null：True

必填条件：仅当前文本成功预览后保存当前行集合及文本对应证据；文本改变或预览失败清除/冻结旧草稿，提交前重核一致；统一/逐条priority只改当前有效草稿。

### 默认与初始化

模式：derived；值：`null`

仅当前文本成功预览后保存当前行集合及文本对应证据；文本改变或预览失败清除/冻结旧草稿，提交前重核一致；统一/逐条priority只改当前有效草稿。

### 校验与关联约束

- 仅当前文本成功预览后保存当前行集合及文本对应证据；文本改变或预览失败清除/冻结旧草稿，提交前重核一致；统一/逐条priority只改当前有效草稿。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 既有导入权限运营（仅当前租户的手工来源任务）

可写：
- 手工预览服务（仅当前文本成功预览或失效时更新）

### 各状态行为

- 输入或接收：仅当前文本成功预览后保存当前行集合及文本对应证据；文本改变或预览失败清除/冻结旧草稿，提交前重核一致；统一/逐条priority只改当前有效草稿。
- 校验与确认：仅既有有权运营且为手工来源任务可编辑，提交前核验当前文本与有效预览完全对应；取消或失败不提交旧草稿。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：calculated

规则：仅当前文本成功预览后保存当前行集合及文本对应证据；文本改变或预览失败清除/冻结旧草稿，提交前重核一致；统一/逐条priority只改当前有效草稿。

依赖字段：[FIELD-CSV-TEXT](field-specs.md#FIELD-CSV-TEXT)

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 当前文本对应的有效行

非法/拒绝：
- 新预览失败仍提交上次成功草稿禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-081
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/13
- project_facts:PRODUCT-FIELD-MAP/fields/80

局部说明：[LOCAL-004-A](local-logic/LOCAL-004-A.md)

任务：

测试：CHECK-030, CHECK-060

<a id="FIELD-DELETION-SELECTION"></a>

## FIELD-DELETION-SELECTION 精准删除当前目标与样例

单功能页面／局部明确关联：

- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`DeletionView`

字段：`selection`

类型：对象或null

格式/枚举/单位/精度：页面选择当前record/batch/fileId/号码及合成结果样例，先校验租户任务作用域。切换任一目标/样例清旧反馈，不能改旧对象已保存删除证据；样例仅合成不作为生产输入。

允许 null：True

必填条件：页面选择当前record/batch/fileId/号码及合成结果样例，先校验租户任务作用域。切换任一目标/样例清旧反馈，不能改旧对象已保存删除证据；样例仅合成不作为生产输入。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 页面选择当前record/batch/fileId/号码及合成结果样例，先校验租户任务作用域。切换任一目标/样例清旧反馈，不能改旧对象已保存删除证据；样例仅合成不作为生产输入。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有精准删除权限的当前租户任务调用方/运营

可写：
- 有精准删除权限的当前租户任务调用方/运营（选择目标或合成样例）

### 各状态行为

- 输入或接收：页面选择当前record/batch/fileId/号码及合成结果样例，先校验租户任务作用域。切换任一目标/样例清旧反馈，不能改旧对象已保存删除证据；样例仅合成不作为生产输入。
- 校验与确认：仅有权当前租户任务的调用方可操作，提交前核验精确record/batch/fileId/手机号；切换目标或样例清旧反馈且保留旧业务证据。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：input

规则：页面选择当前record/batch/fileId/号码及合成结果样例，先校验租户任务作用域。切换任一目标/样例清旧反馈，不能改旧对象已保存删除证据；样例仅合成不作为生产输入。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- 当前精确B002/F102目标

非法/拒绝：
- 切换B003仍显示B002已删禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-079
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/14
- project_facts:PRODUCT-FIELD-MAP/fields/78

局部说明：[LOCAL-009](local-logic/LOCAL-009.md)

任务：

测试：CHECK-061

<a id="FIELD-DELETION-FEEDBACK"></a>

## FIELD-DELETION-FEEDBACK 当前删除操作反馈

单功能页面／局部明确关联：

- [删除指定供应商号码 · FUNC\-009](features/FUNC-009.md)

共享页面／局部／任务上下文（不等于字段专属归属）：

- [接收预外呼线索 · FUNC\-004](features/FUNC-004.md)
- [自动提交导入批次 · FUNC\-005](features/FUNC-005.md)
- [下载导入失败记录 · FUNC\-006](features/FUNC-006.md)
- [回传接口任务每次结果 · FUNC\-010](features/FUNC-010.md)
- [识别客户秒挂结果 · FUNC\-011](features/FUNC-011.md)
- [记录无话单失败原因 · FUNC\-012](features/FUNC-012.md)
- [处理待核或重复结果 · FUNC\-013](features/FUNC-013.md)
- [查询任务业务记录 · FUNC\-015](features/FUNC-015.md)
- [创建任务并锁定导入方式 · FUNC\-016](features/FUNC-016.md)
- [接收并关联异步导入失败 · FUNC\-017](features/FUNC-017.md)

业务对象：`DeletionView`

字段：`feedback`

类型：对象或null

格式/枚举/单位/精度：只显示本次选定目标与结果样例对应操作反馈；切换目标/样例立即清空，不代表清理旧对象业务删除证据，失败不显示成功。

允许 null：True

必填条件：只显示本次选定目标与结果样例对应操作反馈；切换目标/样例立即清空，不代表清理旧对象业务删除证据，失败不显示成功。

### 默认与初始化

模式：none；值：`null`

无默认值；缺失按本字段必填/未知规则处理，不以旧值、空串、零值或当前时间补造；编辑不因未提供新值自动清空。

### 校验与关联约束

- 只显示本次选定目标与结果样例对应操作反馈；切换目标/样例立即清空，不代表清理旧对象业务删除证据，失败不显示成功。
- null/缺失与合法零值、空串、空集合分别按本字段语义处理；无来源确认的生产类型长度/编码不从合成样例推定。

### 读写权限

可读：
- 有精准删除权限的当前租户任务调用方/运营

可写：
- 精准删除处理服务（仅当前目标和样例反馈）

### 各状态行为

- 输入或接收：只显示本次选定目标与结果样例对应操作反馈；切换目标/样例立即清空，不代表清理旧对象业务删除证据，失败不显示成功。
- 校验与确认：仅有权当前租户任务的调用方可操作，提交前核验精确record/batch/fileId/手机号；切换目标或样例清旧反馈且保留旧业务证据。
- 保存后或操作结束：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 来源与计算

来源类型：system

规则：只显示本次选定目标与结果样例对应操作反馈；切换目标/样例立即清空，不代表清理旧对象业务删除证据，失败不显示成功。

依赖字段：无

### 保存与更新

方式：transient

物理映射：由开发补充

业务保存或更新时机：仅当前操作/会话保留；查询和表单草稿不直接写业务记录，提交成功后仅对应业务对象按其字段保存；取消/失败不冒充已保存。

### 接口映射

由开发依据本字段业务规则补充接口映射，见[开发补充清单](developer-supplement.md)。



### 边界示例

合法：
- B002明确成功的对应反馈

非法/拒绝：
- 把旧样例成功反馈套给新目标禁止

### 依据、使用位置与验证

来源：
- product-input.json#FLD-079
- product-input.json#PAGE-002
- product-input.json#PRODUCT-FIELD-MAP

来源条目：
- pages:PAGE-002/fields/14
- project_facts:PRODUCT-FIELD-MAP/fields/78

局部说明：[LOCAL-009](local-logic/LOCAL-009.md)

任务：

测试：CHECK-061
