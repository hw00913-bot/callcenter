# v1.1.0 接口与事件清单

**讨论稿：业务能力已列明，正式路由与未核协议仍需补齐；未调用真实接口。**

[返回开发包入口](README.md) · [按功能阅读](features/README.md) · [开发待补事项](developer-supplement.md)

本清单覆盖 17 项功能、19 个业务动作和全部 62 条验收，共 23 项接口或处理能力。编号 `CAP-*` 用于清单定位，不表示有 23 个已存在的 HTTP 端点。可信下载完成、结果补送等可能作为内部机制实现；不由此新增页面、按钮或原型目录。

本平台的请求与返回按已批准业务语义列出；真实路由、方法、JSON 包装、错误码及安全协议尚未确定。供应商操作只记录既有官方文档快照中能找到的路径和方法，仍保持 partial／missing，不代表真实联调通过。

## 快速查找

| 编号 | 能力 | 方向 | 地址或机制 | 当前状态 |
| --- | --- | --- | --- | --- |
| [CAP-001](#cap-001) | 应用列表查询 | 超管管理前端 → 应用管理服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-002](#cap-002) | 新增应用 | 超管管理前端 → 应用管理服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-003](#cap-003) | 应用详情读取 | 超管管理前端 → 应用管理服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-004](#cap-004) | 修改应用 | 超管管理前端 → 应用管理服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-005](#cap-005) | 删除应用 | 超管管理前端 → 应用管理服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-006](#cap-006) | 应用凭据换指定租户业务身份 | DCC/业务接入系统 → 本平台身份服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-007](#cap-007) | 创建任务并锁定导入来源 | 既有任务创建前端 → 本平台任务服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-008](#cap-008) | 任务与业务记录查询 | 任务页面/既有授权前端 → 本平台任务与记录服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-009](#cap-009) | DCC批量线索接收与逐行回执 | DCC → 本平台导入服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-010](#cap-010) | 手工线索提交 | 既有授权运营前端 → 本平台导入服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-011](#cap-011) | 指定实际批次号码删除请求 | DCC；既有运营入口按原权限及已批准边界 → 本平台删除服务→供应商 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-012](#cap-012) | 失败快照生成 | 既有授权运营前端 → 本平台失败导出服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-013](#cap-013) | 失败快照下载与可信完成处理 | 既有授权运营前端及待确认的可信下载完成机制 → 本平台失败导出生命周期处理 | 下载路由与可信完成机制未定 | 当前业务能力，正式协议待补 |
| [CAP-014](#cap-014) | 每次结果/晚更新回传DCC及ACK | 本平台结果交付服务 → 后台配置固定DCC接收端 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-015](#cap-015) | 失败交付补送 | 交付保障机制（实施方式待定） → 本平台交付服务→同一DCC接收端 | 内部机制，未定 HTTP 端点 | 当前业务能力，正式协议待补 |
| [CAP-016](#cap-016) | 供应商通话/无话单失败/SIP结果接收 | 供应商可信事件或话单查询结果 → 本平台结果接收与关联服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-017](#cap-017) | 53异步导入失败分片接收 | 供应商53通知 → 本平台导入失败关联服务 | 路由及方法未定 | 当前业务能力，正式协议待补 |
| [CAP-018](#cap-018) | 自动提交供应商单号码批次 | 本平台提交队列 → 供应商导入接口 | /interface/{version}/task/importTaskTel | 供应商文档已定位，真实能力仍partial |
| [CAP-019](#cap-019) | 获取供应商精确批次信息 | 本平台供应商适配服务 → AliCti | /interface/{version}/task/getTaskFile | 已取得文档的候选适配操作，未联调 |
| [CAP-020](#cap-020) | 查询供应商任务号码 | 本平台供应商适配服务 → AliCti | /interface/{version}/task/listTaskTel | 已取得文档的候选适配操作，未联调 |
| [CAP-021](#cap-021) | 预测话单查询与可信结果补查 | 本平台供应商适配服务 → AliCti | /cc/list_cdr_predictive_call | 已取得文档的候选适配操作，未联调 |
| [CAP-022](#cap-022) | 删除供应商指定实际批次号码 | 本平台供应商适配服务 → AliCti | /interface/{version}/task/deleteTaskTel | 已取得文档的候选适配操作，未联调 |
| [CAP-023](#cap-023) | 配置供应商推送订阅 | 本平台供应商适配服务 → AliCti | /cc/create_push_action | 冻结来源已定位配置路径，载荷与启用仍partial |

## 批次和请求标识的使用

| 标识 | 使用边界 |
| --- | --- |
| DCC `requestId` | 一次业务请求的幂等标识，可含多行；同 ID 同完整归一内容返回原回执。与供应商话单查询返回的 `requestId`、`requestUniqueId` 分开。 |
| 本地 `recordId` / `batchId` | 每个有效新业务行独立生成；主批和子批都各自有自己的 `batchId`。 |
| 本地 `rootBatchId` | 保存本次所属主批；后来的新主批不改变旧记录或旧事件的 root。不能当供应商 `fileId`。 |
| 供应商 `fileId` | 每次实际新导入从供应商响应中取得并保存映射。新导入不带旧 `fileId` 追加；同号两次是否实际接收及得到独立 `fileId` 仍需验证。 |
| 供应商通话／事件标识 | 通过可信、精确映射回到原业务记录；只按手机号或当前最近主批不足以关联。 |
| 53 分片计数 | `totalBatchCount/currentBatchCount` 描述失败结果分片；不是业务主／子批次号，也不是 `fileId`。 |

导入文档的 `name` 是必填批次名称，命名策略由适配设计确定；不是新增业务批次层级。`getTaskFile` 要求 `taskId + fileId`；话单查询 `list_cdr_predictive_call` 没有列出 `fileId` 筛选。删除接口的 `tels`、批次、状态存在优先级，不能视作 AND 交集。

## 本平台接入与内部完成机制

<a id="cap-001"></a>

### CAP-001 · 应用列表查询

**方向**：超管管理前端 → 应用管理服务。

**用途与边界**：名称/appId查询、分页及明确空结果；每次读取核对超管权限。 不是业务租户token可以读取的管理列表。

**请求／输入**：应用名称或appId查询条件、页码等既有分页条件。

**返回／输出**：应用名称、appId、创建时间、总数与分页信息；空列表返回明确空结果，不返回密钥。

**鉴权与权限**：超管应用管理权限，每次由服务端检查。

**幂等、异常与重试**：查询失败明确反馈，不伪造空列表或缓存为成功。

**批次关联**：不涉及批次分配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-018](features/FUNC-018.md)；[LOCAL-018](local-logic/LOCAL-018.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-031。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-APP-CREATED, FIELD-APP-ID, FIELD-APP-PAGE, FLD-070, FLD-071, FLD-090。

输出域字段：FIELD-APP-CREATED, FIELD-APP-ID, FIELD-APP-PAGE, FLD-071, FLD-090。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-028, AC-044, AC-045, AC-053, AC-058；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-002"></a>

### CAP-002 · 新增应用

**方向**：超管管理前端 → 应用管理服务。

**用途与边界**：应用名称和可访问租户有效保存后形成独立应用及凭据。 不把合成凭据当生产实现；不新增启停、重置、密钥轮换。

**请求／输入**：应用名称、可访问租户。

**返回／输出**：保存成功的应用对象、appId、创建时间及供详情展示的凭证能力；真实密钥生成/读取协议待核。

**鉴权与权限**：超管应用管理权限。

**幂等、异常与重试**：取消/失败不生成已保存对象；防止重复创建的技术机制由工程确定。

**批次关联**：不涉及批次分配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-019](features/FUNC-019.md)；[LOCAL-019](local-logic/LOCAL-019.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-031。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FLD-089, FLD-090。

输出域字段：FIELD-APP-CREATED, FIELD-APP-ID, FLD-089, FLD-090, FLD-093。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-017, AC-044, AC-045, AC-055, AC-058；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-003"></a>

### CAP-003 · 应用详情读取

**方向**：超管管理前端 → 应用管理服务。

**用途与边界**：准确读取当前应用名称、appId、密钥、授权租户及创建时间。 显示隐藏或复制是前端行为，不增设密钥重置接口；生产密钥读取机制待核。

**请求／输入**：精确应用标识。

**返回／输出**：该应用名称、appId、授权租户、创建时间及授权的密钥展示能力；列表不批量下发密钥。

**鉴权与权限**：超管应用管理权限；不存在或已删除必须拒绝。

**幂等、异常与重试**：只读；显示/复制不重置密钥，生产存储与解密边界仍待核。

**批次关联**：不涉及批次分配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-020](features/FUNC-020.md)；[LOCAL-020](local-logic/LOCAL-020.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-031。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-APP-CREATED, FIELD-APP-ID, FLD-089, FLD-090, FLD-093。

输出域字段：FIELD-APP-CREATED, FIELD-APP-ID, FLD-089, FLD-090, FLD-093。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-017, AC-044, AC-045, AC-054, AC-058；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-004"></a>

### CAP-004 · 修改应用

**方向**：超管管理前端 → 应用管理服务。

**用途与边界**：修改名称与租户授权，保持appId和原密钥；成功才撤销被移除租户的访问。 取消/失败不先撤销身份；普通修改不重置凭据。

**请求／输入**：精确应用标识、更新后的名称和授权租户。

**返回／输出**：保存结果和更新后配置；appId及原密钥保持。

**鉴权与权限**：超管应用管理权限；再次核对当前对象。

**幂等、异常与重试**：失败保持旧配置；成功后被撤租户旧身份应被拒绝，其余授权保持，真实撤销机制待核。

**批次关联**：不涉及批次分配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-001](features/FUNC-001.md)；[LOCAL-001](local-logic/LOCAL-001.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-031。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-APP-CREATED, FIELD-APP-ID, FLD-089, FLD-090, FLD-093。

输出域字段：FIELD-APP-CREATED, FIELD-APP-ID, FLD-089, FLD-090, FLD-093。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-017, AC-044, AC-045, AC-056, AC-058；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-005"></a>

### CAP-005 · 删除应用

**方向**：超管管理前端 → 应用管理服务。

**用途与边界**：确认成功只删除当前应用并使其凭据和已发身份失效。 任务、导入记录、结果与必要来源审计不级联删除；真实token撤销时效待核。

**请求／输入**：明确确认的精确应用标识。

**返回／输出**：当前目标删除结果。

**鉴权与权限**：超管应用管理权限，提交时再次核对目标。

**幂等、异常与重试**：成功才使该应用凭证/已发身份失效；取消/失败不提前失效；保留任务、导入及结果历史。

**批次关联**：不涉及批次分配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-021](features/FUNC-021.md)；[LOCAL-021](local-logic/LOCAL-021.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-031。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-APP-CREATED, FIELD-APP-ID, FLD-006, FLD-089, FLD-090, FLD-093。

输出域字段：FIELD-APP-CREATED, FIELD-APP-ID, FLD-090。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-044, AC-045, AC-057, AC-058；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-006"></a>

### CAP-006 · 应用凭据换指定租户业务身份

**方向**：DCC/业务接入系统 → 本平台身份服务。

**用途与边界**：凭据及tenantId合法且授权有效时，交换该租户业务身份；业务调用继续解析校验。 无日常前台换token按钮；业务身份不授予应用管理权；真实认证报文和有效期未定义。

**请求／输入**：应用凭证、明确tenantId；真实凭证字段名、报文及签名协议未定。

**返回／输出**：仅该授权租户的业务token；具体格式、有效期与撤销机制未定。

**鉴权与权限**：校验应用仍有效、凭证有效及tenantId仍在当前授权范围。

**幂等、异常与重试**：鉴权拒绝不创建身份；租户业务token不能访问超管管理接口。

**批次关联**：不涉及批次分配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-002](features/FUNC-002.md)；[LOCAL-002](local-logic/LOCAL-002.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-031。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-APP-ID, FLD-003, FLD-006, FLD-089, FLD-093。

输出域字段：FLD-006。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-017, AC-044, AC-045, AC-056, AC-057, AC-058；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-007"></a>

### CAP-007 · 创建任务并锁定导入来源

**方向**：既有任务创建前端 → 本平台任务服务。

**用途与边界**：成功创建后锁定所属租户、原供应商任务及DCC/手工单一来源。 复用既有任务创建能力，不为本版虚构完整建任务请求；来源不可切换或混用。

**请求／输入**：沿用既有任务创建资料，补充DCC/手工单一来源；本次关注tenantId与原供应商taskId。

**返回／输出**：创建结果及保存锁定的租户、原供应商任务和导入来源。

**鉴权与权限**：沿用任务创建权限；任务属于租户，不绑定应用。

**幂等、异常与重试**：保存后禁止切换来源或归属；不在此虚构完整供应商建任务报文。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-016](features/FUNC-016.md)；[LOCAL-016](local-logic/LOCAL-016.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-029。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FLD-003, FLD-004, FLD-078。

输出域字段：FLD-003, FLD-004, FLD-078。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-029, AC-036, AC-059；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-008"></a>

### CAP-008 · 任务与业务记录查询

**方向**：任务页面/既有授权前端 → 本平台任务与记录服务。

**用途与边界**：查询当前任务记录、阶段证据、实际fileId、主子root、结果/待核/交付/下载状态。 任务列表和具体记录详情可由既有查询复用或拆分，真实路由未定；不能把供应商查询结果替代本地记录关联。

**请求／输入**：授权租户及任务范围、既有查询筛选；具体分页报文待仓库设计。

**返回／输出**：本地record/batch、已保存root、供应商fileId、阶段证据、结果、失败快照、删除及DCC交付状态。

**鉴权与权限**：沿用任务读取权限，服务端校验租户边界。

**幂等、异常与重试**：只读展示；未知保留未知，不把查询不到当未拨打，不引入每日轮询或衰减。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-015](features/FUNC-015.md)；[LOCAL-015](local-logic/LOCAL-015.md)。

**来源与待核**：API-009；来源状态 API-009=not_required；无单独新增业务待核，工程协议仍未定。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-AGENT-ANSWERED, FIELD-BATCH-CREATED-AT, FIELD-BATCH-KIND, FIELD-CUSTOMER-ANSWERED, FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-DOWNLOAD-STATE, FIELD-EVIDENCE-SOURCE, FIELD-EXPORT-SNAPSHOT, FIELD-FRAGMENT-COMPLETENESS, FIELD-ORIGINAL-IMPORT-AT, FIELD-PHONE, FIELD-RECEIVED-AT, FIELD-RECEIVED-SEQUENCE, FIELD-RESULT-REASON, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-ROW-ID, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FIELD-SUBMISSION-STATE, FIELD-UNTRUSTED-SIP, FLD-001, FLD-002, FLD-003, FLD-004, FLD-007, FLD-008, FLD-009, FLD-010, FLD-011, FLD-013, FLD-015, FLD-020, FLD-021, FLD-022, FLD-023, FLD-028, FLD-030, FLD-035, FLD-040, FLD-041, FLD-046, FLD-047, FLD-049, FLD-050, FLD-051, FLD-054, FLD-066, FLD-078。

输出域字段：FIELD-AGENT-ANSWERED, FIELD-BATCH-CREATED-AT, FIELD-BATCH-KIND, FIELD-CUSTOMER-ANSWERED, FIELD-DELIVERY-STATE, FIELD-DOWNLOAD-STATE, FIELD-EVIDENCE-SOURCE, FIELD-EXPORT-SNAPSHOT, FIELD-FRAGMENT-COMPLETENESS, FIELD-ORIGINAL-IMPORT-AT, FIELD-PHONE, FIELD-RECEIVED-AT, FIELD-RECEIVED-SEQUENCE, FIELD-RESULT-REASON, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-ROW-ID, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FIELD-SUBMISSION-STATE, FIELD-UNTRUSTED-SIP, FLD-001, FLD-002, FLD-007, FLD-008, FLD-009, FLD-010, FLD-011, FLD-013, FLD-015, FLD-020, FLD-021, FLD-022, FLD-023, FLD-028, FLD-030, FLD-035, FLD-046, FLD-047, FLD-049, FLD-050, FLD-051, FLD-054, FLD-066。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-014, AC-015, AC-019, AC-028, AC-029, AC-032, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-047, AC-048, AC-049, AC-050, AC-051, AC-052, AC-059；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-009"></a>

### CAP-009 · DCC批量线索接收与逐行回执

**方向**：DCC → 本平台导入服务。

**用途与边界**：先鉴权、锁定来源/任务核对，缺省isNewBatch归一false，再requestId完整内容幂等；新有效行建独立record/batch及root，返逐行原始回执。 false复用主关联，不复用batch；无previous/parent必填；同请求技术重试不再次提交供应商。

**请求／输入**：租户业务token、tenantId、原供应商taskId、requestId和可定位的多行；逐行leadCode、phone、priority必填，R可选，isNewBatch可选Boolean。

**返回／输出**：完整逐行接收结果，包括失败/待核行；已创建对象返回原recordId、batchId、rootBatchId及主/子归属，未创建对象不编造ID。

**鉴权与权限**：先验证token、授权租户、原taskId与任务DCC来源。

**幂等、异常与重试**：仅missing按false归一，显式null/非Boolean不得当false；同requestId同完整归一内容返回原回执、不重建不重交；异内容拒绝整重复请求。原子性和键作用域待工程落实。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-004](features/FUNC-004.md)；[LOCAL-004-B](local-logic/LOCAL-004-B.md)、[LOCAL-004](local-logic/LOCAL-004.md)。

**来源与待核**：API-001；来源状态 API-001=missing；ISSUE-002。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-BATCH-KIND, FIELD-PHONE, FIELD-ROW-ID, FLD-001, FLD-002, FLD-003, FLD-004, FLD-006, FLD-007, FLD-008, FLD-009, FLD-015, FLD-078。

输出域字段：FIELD-BATCH-CREATED-AT, FIELD-BATCH-KIND, FIELD-ORIGINAL-IMPORT-AT, FIELD-PHONE, FIELD-RECEIVED-AT, FIELD-ROW-ID, FLD-001, FLD-002, FLD-003, FLD-004, FLD-007, FLD-008, FLD-009, FLD-010, FLD-011, FLD-013, FLD-015。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-001, AC-005, AC-006, AC-007, AC-009, AC-010, AC-012, AC-014, AC-015, AC-019, AC-029, AC-032, AC-036, AC-047, AC-048, AC-049, AC-050, AC-051, AC-052；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-010"></a>

### CAP-010 · 手工线索提交

**方向**：既有授权运营前端 → 本平台导入服务。

**用途与边界**：只提交当前CSV对应有效预览和最终priority，提交时再次验证权限、任务与锁定手工来源。 CSV预览可为前端处理，不据此虚构上传/预览端点；手工不新增DCC requestId/isNewBatch/root参数。

**请求／输入**：当前有效CSV预览对应的逐行leadCode、phone、最终priority及可选R；原任务和手工来源身份。

**返回／输出**：逐行本地接收/校验结果和新增record及单号码batch。

**鉴权与权限**：沿用手工导入权限、锁来源和既有任务可补导条件。

**幂等、异常与重试**：文本变化或预览失败不得提交旧草稿；手工不要求DCC requestId/isNewBatch/root输入；保存后自动进入供应商提交。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-004](features/FUNC-004.md)；[LOCAL-004-A](local-logic/LOCAL-004-A.md)。

**来源与待核**：API-009；来源状态 API-009=not_required；ISSUE-029。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-CSV-PREVIEW, FIELD-CSV-TEXT, FIELD-PHONE, FLD-001, FLD-003, FLD-004, FLD-008, FLD-009, FLD-078。

输出域字段：FIELD-BATCH-CREATED-AT, FIELD-CSV-PREVIEW, FIELD-CSV-TEXT, FIELD-ORIGINAL-IMPORT-AT, FIELD-RECEIVED-AT, FIELD-ROW-ID, FLD-001, FLD-009, FLD-010, FLD-011, FLD-015。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-001, AC-005, AC-007, AC-014, AC-015, AC-029, AC-030, AC-031, AC-032, AC-059, AC-060；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-011"></a>

### CAP-011 · 指定实际批次号码删除请求

**方向**：DCC；既有运营入口按原权限及已批准边界 → 本平台删除服务→供应商。

**用途与边界**：校验租户/原任务/精确record与当前batch/phone/fileId，只在供应商明确成功后标该对象已删并交付结果。 不得按root/leadCode/同号扩大删除；真实删除字段及并发作用域待核。

**请求／输入**：指定租户、原任务、精确当前业务记录/批次及手机号；由后台映射当前供应商fileId，最终字段集合待正式契约。

**返回／输出**：该目标的明确成功、失败或未知及对应状态证据。

**鉴权与权限**：DCC租户业务权限；既有运营入口依原权限，合成按钮不单独授予生产删除权。

**幂等、异常与重试**：无精确映射不调用；供应商未知不标已删。主删不删子、子删不删主；不清本地关联。与CAP-022配合落实供应商删除作用域。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-009](features/FUNC-009.md)；[LOCAL-009](local-logic/LOCAL-009.md)。

**来源与待核**：API-006；来源状态 API-006=partial；ISSUE-022。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-DELETION-FEEDBACK, FIELD-DELETION-SELECTION, FIELD-PHONE, FLD-003, FLD-004, FLD-006, FLD-008, FLD-010, FLD-011, FLD-013, FLD-020, FLD-054。

输出域字段：FIELD-DELETION-FEEDBACK, FIELD-DELETION-SELECTION, FIELD-DELIVERY-STATE, FIELD-REVIEW-REASON, FLD-010, FLD-011, FLD-020, FLD-054。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-016, AC-024, AC-025, AC-052, AC-061；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-012"></a>

### CAP-012 · 失败快照生成

**方向**：既有授权运营前端 → 本平台失败导出服务。

**用途与边界**：生成本次失败明细固定快照及生成时分片完整性信息；后到失败进入后续快照。 只生成快照不清理明细，生成不等于下载成功。

**请求／输入**：有权限的任务范围及本次失败明细集合；沿用任务失败下载入口。

**返回／输出**：本次快照及文件、已知分片完整性；不完整/未知须明确展示。

**鉴权与权限**：沿用失败下载权限与租户范围。

**幂等、异常与重试**：生成/点击/服务器开始响应均不代表下载成功；后到失败不并入已生成快照，下载失败/中断保留。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-006](features/FUNC-006.md)；[LOCAL-006](local-logic/LOCAL-006.md)。

**来源与待核**：API-009；来源状态 API-009=not_required；ISSUE-008。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-DOWNLOAD-STATE, FIELD-EXPORT-SNAPSHOT, FIELD-FRAGMENT-COMPLETENESS, FIELD-REVIEW-REASON, FLD-020, FLD-028, FLD-030, FLD-035。

输出域字段：FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-DOWNLOAD-STATE, FIELD-EXPORT-SNAPSHOT, FIELD-FRAGMENT-COMPLETENESS, FIELD-REVIEW-REASON, FLD-030。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-008, AC-013, AC-029, AC-031, AC-039, AC-040, AC-041, AC-042, AC-043, AC-052；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-013"></a>

### CAP-013 · 失败快照下载与可信完成处理

**方向**：既有授权运营前端及待确认的可信下载完成机制 → 本平台失败导出生命周期处理。

**用途与边界**：读取精确快照文件并跟踪下载；仅可信成功清本快照明细和文件，失败/中断/未知保留。 尚未证明浏览器机制能够确认成功，不能给普通客户端开放一个无校验即清理的成功接口。

**请求／输入**：有权读取的精确快照标识与文件下载请求；后续清理还须能可信绑定本次快照的下载完成证据，信号来源和证明方式尚未确定。

**返回／输出**：读取返回该快照文件；仅在可信完成后清理该快照明细和文件，并返回或记录实际清理结果。必要幂等、关联、事件分片与交付依据保持。

**鉴权与权限**：文件读取沿用既有下载权限及租户范围；完成清理由内部可信机制确认，不能使用未验真的普通客户端成功声明。

**幂等、异常与重试**：信号缺失、失败、中断均不清理；已导出事件重复不得重新生成失败明细。不是已确定的HTTP端点。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-006](features/FUNC-006.md)；[LOCAL-006](local-logic/LOCAL-006.md)。

**来源与待核**：API-009；来源状态 API-009=not_required；ISSUE-008。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-DOWNLOAD-STATE, FIELD-EXPORT-SNAPSHOT, FIELD-FRAGMENT-COMPLETENESS, FIELD-REVIEW-REASON, FLD-020, FLD-028, FLD-030, FLD-035。

输出域字段：FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-DOWNLOAD-STATE, FIELD-EXPORT-SNAPSHOT, FIELD-FRAGMENT-COMPLETENESS, FIELD-REVIEW-REASON, FLD-030。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-008, AC-013, AC-029, AC-031, AC-039, AC-040, AC-041, AC-042, AC-043, AC-052；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

## DCC 结果交付

<a id="cap-014"></a>

### CAP-014 · 每次结果/晚更新回传DCC及ACK

**方向**：本平台结果交付服务 → 后台配置固定DCC接收端。

**用途与边界**：精确原request行/record/batch/root与call或稳定事件关联，交付导入失败、通话、无话单、秒挂、删除及可信晚更新。 仅DCC来源；手工仅查看；ACK来自DCC而非供应商，真实URL、鉴权、ACK及去重报文未定。

**请求／输入**：原requestId/行定位、tenantId/原taskId/leadCode/phone、recordId、当前batchId及已存rootBatchId、真实call或稳定事件、阶段/结果/原因/时间/原SIP等。

**返回／输出**：由DCC接收端给出的确认应答；实际ACK结构和错误码待协议。

**鉴权与权限**：后台固定接收地址及安全配置；认证、验真、重放保护待DCC双方定约。

**幂等、异常与重试**：仅DCC来源；失败交付可观察，可信晚更新仍是同一对象。超时不能改成业务呼叫失败，补送不重新导入或呼叫。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-010](features/FUNC-010.md)；[LOCAL-010](local-logic/LOCAL-010.md)。

**来源与待核**：API-010；来源状态 API-010=missing；ISSUE-026。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-AGENT-ANSWERED, FIELD-BATCH-KIND, FIELD-CUSTOMER-ANSWERED, FIELD-DELIVERY-STATE, FIELD-EVIDENCE-SOURCE, FIELD-OCCURRED-AT, FIELD-PHONE, FIELD-RESULT-REASON, FIELD-RESULT-STAGE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-ROW-ID, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FLD-002, FLD-003, FLD-004, FLD-007, FLD-008, FLD-010, FLD-011, FLD-013, FLD-015, FLD-020, FLD-046, FLD-047, FLD-049, FLD-051, FLD-066, FLD-068, FLD-078。

输出域字段：FIELD-AGENT-ANSWERED, FIELD-CUSTOMER-ANSWERED, FIELD-DELIVERY-STATE, FIELD-EVIDENCE-SOURCE, FIELD-OCCURRED-AT, FIELD-PHONE, FIELD-RESULT-REASON, FIELD-RESULT-STAGE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-ROW-ID, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FLD-002, FLD-003, FLD-004, FLD-008, FLD-010, FLD-011, FLD-013, FLD-046, FLD-047, FLD-049, FLD-051, FLD-066, FLD-068。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-002, AC-018, AC-023, AC-026, AC-027, AC-035, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-052, AC-062；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-015"></a>

### CAP-015 · 失败交付补送

**方向**：交付保障机制（实施方式待定） → 本平台交付服务→同一DCC接收端。

**用途与边界**：失败可观察，补送相同业务结果或可信版本的交付，不重做导入/删除、不新增呼叫。 工程可采用后台任务或受控管理能力；合成补送按钮不自动成为新的生产前台接口。

**请求／输入**：已有未确认交付的业务结果及稳定对象/版本关联。

**返回／输出**：该次补送的DCC确认或继续失败状态。

**鉴权与权限**：沿用CAP-014后台交付身份；由受控交付保障机制触发。

**幂等、异常与重试**：复用CAP-014，无新增生产前台补送按钮或独立业务重导API；真实重试周期/上限及键待工程协议。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-010](features/FUNC-010.md)；[LOCAL-010](local-logic/LOCAL-010.md)。

**来源与待核**：API-010；来源状态 API-010=missing；ISSUE-026。

**补充文档**：沿冻结输入；无额外已核文档。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-AGENT-ANSWERED, FIELD-BATCH-KIND, FIELD-CUSTOMER-ANSWERED, FIELD-DELIVERY-STATE, FIELD-EVIDENCE-SOURCE, FIELD-OCCURRED-AT, FIELD-PHONE, FIELD-RESULT-REASON, FIELD-RESULT-STAGE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-ROW-ID, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FLD-002, FLD-003, FLD-004, FLD-007, FLD-008, FLD-010, FLD-011, FLD-013, FLD-015, FLD-020, FLD-046, FLD-047, FLD-049, FLD-051, FLD-066, FLD-068, FLD-078。

输出域字段：FIELD-AGENT-ANSWERED, FIELD-CUSTOMER-ANSWERED, FIELD-DELIVERY-STATE, FIELD-EVIDENCE-SOURCE, FIELD-OCCURRED-AT, FIELD-PHONE, FIELD-RESULT-REASON, FIELD-RESULT-STAGE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-ROW-ID, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FLD-002, FLD-003, FLD-004, FLD-008, FLD-010, FLD-011, FLD-013, FLD-046, FLD-047, FLD-049, FLD-051, FLD-066, FLD-068。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-002, AC-018, AC-023, AC-026, AC-027, AC-035, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-052, AC-062；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

## 供应商调用

<a id="cap-018"></a>

### CAP-018 · 自动提交供应商单号码批次

**方向**：本平台提交队列 → 供应商导入接口。

**用途与边界**：新有效行保存后自动逐条提交；同任务priority高先/同级FIFO，逐批保存本次实际fileId及同步数量和来源。 不人工二次提交、不追加旧fileId、不代供应商保证重复手机号接收或实际拨号；未知不自动重交。

**请求／输入**：供应商taskId、name（批次名称）、taskTelList单行tel/本次priority及供应商公共鉴权；批次名称生成规则和可选参数由适配器落实。

**返回／输出**：result/description、data.fileId/taskId、importTotal/successTotal/invalidTotal原始数量与来源。

**鉴权与权限**：独立供应商后台鉴权；不能使用DCC租户token。

**幂等、异常与重试**：新实际导入不带旧fileId追加；不擅自修改isRepeat绕过去重；未知响应不盲目重交。同任务priority高先、同级FIFO仅约束提交次序。

**批次关联**：每一有效新业务行已有独立本地batchId；请求不把batchId或rootBatchId填入fileId，响应的本次fileId另存映射。name只是批次名称，不是fileId。

**路径与方法**：/interface/{version}/task/importTaskTel；POST JSON（已有文档快照）。

**状态与责任**：供应商文档已定位，真实能力仍partial。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-005](features/FUNC-005.md)；[LOCAL-005](local-logic/LOCAL-005.md)。

**来源与待核**：API-002；来源状态 API-002=partial；ISSUE-002、ISSUE-029。

**补充文档**：DOC-IMPORT。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-BATCH-CREATED-AT, FIELD-ORIGINAL-IMPORT-AT, FIELD-PHONE, FIELD-RECEIVED-AT, FIELD-RECEIVED-SEQUENCE, FIELD-SUBMISSION-STATE, FLD-001, FLD-004, FLD-008, FLD-009, FLD-010, FLD-011, FLD-013, FLD-020, FLD-021, FLD-022, FLD-023, FLD-025, FLD-026。

输出域字段：FIELD-EVIDENCE-SOURCE, FIELD-PHONE, FIELD-RECEIVED-AT, FIELD-RECEIVED-SEQUENCE, FIELD-REVIEW-REASON, FIELD-SUBMISSION-STATE, FLD-004, FLD-009, FLD-020, FLD-021, FLD-022, FLD-023, FLD-025, FLD-026。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-011, AC-012, AC-013, AC-014, AC-015, AC-019, AC-032, AC-035, AC-039, AC-041, AC-043, AC-046, AC-049, AC-050, AC-051；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-019"></a>

### CAP-019 · 获取供应商精确批次信息

**方向**：本平台供应商适配服务 → AliCti。

**用途与边界**：获取供应商精确批次信息 用于现有业务精确关联；不恢复每日衰减，不增加前台操作或自动重导。

**请求／输入**：taskId、fileId均为文档必填；另含供应商鉴权。

**返回／输出**：result/description/errorCode、批次信息及相应计数/限制名单；实际类型与嵌套层级须核对。

**鉴权与权限**：按对应供应商接口鉴权；validateType选择departmentId或enterpriseId，并按文档使用timestamp/sign；配置、类型与签名规则需真实环境核对，密钥不进入前台。

**幂等、异常与重试**：查询结果须与当前任务/file精确核对；空或未知不推定零失败或未拨打。

**批次关联**：fileId来自该次导入的保存回执，不能替换成本地batchId或rootBatchId。

**路径与方法**：/interface/{version}/task/getTaskFile；GET / POST（已有文档快照）。

**状态与责任**：已取得文档的候选适配操作，未联调。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-005](features/FUNC-005.md)、[FUNC-015](features/FUNC-015.md)；[LOCAL-005](local-logic/LOCAL-005.md)、[LOCAL-015](local-logic/LOCAL-015.md)。

**来源与待核**：API-002；来源状态 API-002=partial；ISSUE-002。

**补充文档**：DOC-FILE。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：见本项文档字段；不虚构已确认平台物理字段映射。

输出域字段：见本项文档响应字段。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-011, AC-012, AC-013, AC-014, AC-015, AC-019, AC-028, AC-029, AC-032, AC-035, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-046, AC-047, AC-048, AC-049, AC-050, AC-051, AC-052, AC-059；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-020"></a>

### CAP-020 · 查询供应商任务号码

**方向**：本平台供应商适配服务 → AliCti。

**用途与边界**：查询供应商任务号码 用于现有业务精确关联；不恢复每日衰减，不增加前台操作或自动重导。

**请求／输入**：taskId必填；fileId、tel及分页/状态等为文档可选。精确查当前记录时携带已保存fileId，不能仅按同号定位。

**返回／输出**：任务号码列表及可选totalCount，保留每条实际fileId和原始状态。

**鉴权与权限**：按对应供应商接口鉴权；validateType选择departmentId或enterpriseId，并按文档使用timestamp/sign；配置、类型与签名规则需真实环境核对，密钥不进入前台。

**幂等、异常与重试**：分页与筛选语义需适配验证；不得将只按手机号返回的多批候选任意归到一条。

**批次关联**：taskId + 本次实际fileId用于限定目标，phone辅助核验；不恢复每日状态查询。

**路径与方法**：/interface/{version}/task/listTaskTel；GET / POST（已有文档快照）。

**状态与责任**：已取得文档的候选适配操作，未联调。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-015](features/FUNC-015.md)；[LOCAL-015](local-logic/LOCAL-015.md)。

**来源与待核**：API-002；来源状态 API-002=partial；ISSUE-002。

**补充文档**：DOC-TELS。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：见本项文档字段；不虚构已确认平台物理字段映射。

输出域字段：见本项文档响应字段。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-014, AC-015, AC-019, AC-028, AC-029, AC-032, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-047, AC-048, AC-049, AC-050, AC-051, AC-052, AC-059；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-021"></a>

### CAP-021 · 预测话单查询与可信结果补查

**方向**：本平台供应商适配服务 → AliCti。

**用途与边界**：预测话单查询与可信结果补查 用于现有业务精确关联；不恢复每日衰减，不增加前台操作或自动重导。

**请求／输入**：startTime、startTimeEnd及文档支持的taskIds/mainUniqueId/callId/requestUniqueId等筛选；不能添加文档未列出的fileId筛选。

**返回／输出**：客户挂断方、客户接听时长、原status/SIP、finishRetryFlag及实际通话标识；缺失单独保留。

**鉴权与权限**：沿该接口独立鉴权协议；不能将/interface路径的签名方式未经核对套用。

**幂等、异常与重试**：无话单不等于未拨打；0/1/未知分开。挂断枚举、客户真实接听和时长单位仍ISSUE-005。

**批次关联**：该文档没有fileId请求/响应字段；需可信call/事件与本地已保存fileId映射，映射缺失或多候选待核。供应商requestId/requestUniqueId不能直接当DCC业务requestId。

**路径与方法**：/cc/list_cdr_predictive_call；GET（已有文档快照）。

**状态与责任**：已取得文档的候选适配操作，未联调。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-011](features/FUNC-011.md)、[FUNC-012](features/FUNC-012.md)、[FUNC-013](features/FUNC-013.md)、[FUNC-015](features/FUNC-015.md)；[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-015](local-logic/LOCAL-015.md)。

**来源与待核**：API-004；来源状态 API-004=partial；ISSUE-005。

**补充文档**：DOC-CDR。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：见本项文档字段；不虚构已确认平台物理字段映射。

输出域字段：见本项文档响应字段。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-003, AC-004, AC-014, AC-015, AC-019, AC-020, AC-021, AC-022, AC-023, AC-024, AC-028, AC-029, AC-032, AC-033, AC-034, AC-035, AC-037, AC-038, AC-039, AC-040, AC-041, AC-042, AC-043, AC-047, AC-048, AC-049, AC-050, AC-051, AC-052, AC-059, AC-062；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-022"></a>

### CAP-022 · 删除供应商指定实际批次号码

**方向**：本平台供应商适配服务 → AliCti。

**用途与边界**：删除供应商指定实际批次号码 用于现有业务精确关联；不恢复每日衰减，不增加前台操作或自动重导。

**请求／输入**：taskId及精确目标策略；文档提供fileId/fileName/tels/status，按优先级处理，不能当成AND交集。

**返回／输出**：result/description/errorCode及可能的data.skippedCallingTels；部分跳过也可能返回成功。

**鉴权与权限**：按对应供应商接口鉴权；validateType选择departmentId或enterpriseId，并按文档使用timestamp/sign；配置、类型与签名规则需真实环境核对，密钥不进入前台。

**幂等、异常与重试**：tels优先于批次、状态和全任务；fileName会选最近批次。skipCalling/skipRetry与进行中删除需核实，不照搬默认值。总体result成功不足以证明每个目标删除。

**批次关联**：优先评估仅用已保存taskId+fileId的单号码批次范围，必须先证明该file内仅本次目标；不可混加tels假定交集。不满足精确隔离不执行。

**路径与方法**：/interface/{version}/task/deleteTaskTel；GET / POST（已有文档快照）。

**状态与责任**：已取得文档的候选适配操作，未联调。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-009](features/FUNC-009.md)；[LOCAL-009](local-logic/LOCAL-009.md)。

**来源与待核**：API-006；来源状态 API-006=partial；ISSUE-022。

**补充文档**：DOC-DELETE。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：见本项文档字段；不虚构已确认平台物理字段映射。

输出域字段：见本项文档响应字段。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-016, AC-024, AC-025, AC-052, AC-061；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-023"></a>

### CAP-023 · 配置供应商推送订阅

**方向**：本平台供应商适配服务 → AliCti。

**用途与边界**：配置供应商推送订阅 用于现有业务精确关联；不恢复每日衰减，不增加前台操作或自动重导。

**请求／输入**：文档列name、type及targetUrlId或url/method/contentType/timeout配置；实际订阅、接收地址及鉴权待核。

**返回／输出**：推送设置结果；不能替代实际52/53/1060事件载荷契约。

**鉴权与权限**：供应商后台配置权限与回调验真分开落实。

**幂等、异常与重试**：这是集成准备能力，不新增产品前台设置页；未证明零失败推送、事件ID、ACK或重放保证。

**批次关联**：53真实fileId与分片序号分开；1060不等于平台换主叫能力。

**路径与方法**：/cc/create_push_action；POST JSON（已有文档快照）。

**状态与责任**：冻结来源已定位配置路径，载荷与启用仍partial。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-012](features/FUNC-012.md)、[FUNC-013](features/FUNC-013.md)、[FUNC-017](features/FUNC-017.md)；[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-013](local-logic/LOCAL-013.md)、[LOCAL-017](local-logic/LOCAL-017.md)。

**来源与待核**：API-003；来源状态 API-003=partial；ISSUE-027。

**补充文档**：DOC-PUSH-CONFIG。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：见本项文档字段；不虚构已确认平台物理字段映射。

输出域字段：见本项文档响应字段。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-003, AC-020, AC-033, AC-035, AC-039, AC-040, AC-041, AC-042, AC-043, AC-062；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

## 供应商结果接收

<a id="cap-016"></a>

### CAP-016 · 供应商通话/无话单失败/SIP结果接收

**方向**：供应商可信事件或话单查询结果 → 本平台结果接收与关联服务。

**用途与边界**：可信稳定关联后记录原始结果、判定秒挂并处理重复或SIP晚更新；不可信纯SIP隔离待核。 可共用事件入口或区分消息，真实事件和验真契约未定；秒挂判定和待核处理是内部逻辑，不新增秒挂计算或人工强制成功API。

**请求／输入**：供应商真实call/稳定事件、任务批次关联、原结果/SIP/时间、客户接听时长及挂断方证据；实际推送或补查载荷待核。

**返回／输出**：可信关联记录、短挂识别、无话单失败、重复/晚更新处理；需回调ACK时其协议另行核实。

**鉴权与权限**：供应商事件验真、租户和任务映射必须独立验证。

**幂等、异常与重试**：52预测呼叫失败与53导入失败分开；1060不能直接认定线路风控已支持。无可信call关联的纯SIP隔离；不能按后来最新主批归并旧事件。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-011](features/FUNC-011.md)、[FUNC-012](features/FUNC-012.md)、[FUNC-013](features/FUNC-013.md)；[LOCAL-011](local-logic/LOCAL-011.md)、[LOCAL-012](local-logic/LOCAL-012.md)、[LOCAL-013](local-logic/LOCAL-013.md)。

**来源与待核**：API-003, API-004；来源状态 API-003=partial, API-004=partial；ISSUE-005、ISSUE-026。

**补充文档**：DOC-PUSH-8, DOC-PUSH-52, DOC-PUSH-16, DOC-PUSH-17。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-AGENT-ANSWERED, FIELD-CUSTOMER-ANSWERED, FIELD-EVENT-PAYLOAD, FIELD-EVENT-TYPE, FIELD-EVIDENCE-SOURCE, FIELD-OCCURRED-AT, FIELD-RESULT-REASON, FIELD-RESULT-STAGE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FIELD-UNTRUSTED-SIP, FLD-020, FLD-043, FLD-044, FLD-045, FLD-046, FLD-047, FLD-048, FLD-049, FLD-050, FLD-051, FLD-052, FLD-066, FLD-078。

输出域字段：FIELD-AGENT-ANSWERED, FIELD-CUSTOMER-ANSWERED, FIELD-EVIDENCE-SOURCE, FIELD-OCCURRED-AT, FIELD-RESULT-REASON, FIELD-RESULT-STAGE, FIELD-RESULT-VERSION, FIELD-REVIEW-REASON, FIELD-SHORT-HANGUP, FIELD-STATUS-DESC, FIELD-UNTRUSTED-SIP, FLD-046, FLD-047, FLD-049, FLD-050, FLD-051, FLD-066。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-003, AC-004, AC-020, AC-021, AC-022, AC-023, AC-024, AC-033, AC-034, AC-035, AC-039, AC-040, AC-041, AC-042, AC-043, AC-062；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

<a id="cap-017"></a>

### CAP-017 · 53异步导入失败分片接收

**方向**：供应商53通知 → 本平台导入失败关联服务。

**用途与边界**：按已核租户、taskId、实际fileId及原始号码精准关联，乱序迟到处理、重复去重，声明冲突待核。 分片号不是业务batch或root；片齐不等整导入完成；未收到不推定零失败。

**请求／输入**：53事件enterpriseId/taskId/fileId、fileName、totalFailedCount、totalBatchCount/currentBatchCount、failedTelList原始数据及failedReason；原文数组/JSON字符串差异待核。

**返回／输出**：精确失败关联、分片证据、失败明细及DCC来源交付状态；真实ACK契约待核。

**鉴权与权限**：供应商推送验真及本地保存的租户/任务/file映射校验。

**幂等、异常与重试**：片齐不等整导入完成；未收到不证明零失败；重复/乱序/冲突/迟到按同次事件对象处理，不造新业务记录。

**批次关联**：按本地已保存的recordId/batchId/rootBatchId及供应商fileId关联；不凭同号或最近主批重新猜配。

**路径与方法**：尚未确定正式路由；尚未确定方法／消息协议。

**状态与责任**：当前业务能力，正式协议待补。开发方补实际模块、报文和协议；涉及业务语义的缺口由产品与接口提供方共同核对。

**关联功能与逻辑**：[FUNC-017](features/FUNC-017.md)；[LOCAL-017](local-logic/LOCAL-017.md)。

**来源与待核**：API-003；来源状态 API-003=partial；ISSUE-027。

**补充文档**：DOC-PUSH-53。

<details>
<summary>查看字段和验收追溯</summary>

输入域字段：FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-EVENT-PAYLOAD, FIELD-EVENT-TYPE, FIELD-FRAGMENT-COMPLETENESS, FLD-004, FLD-020, FLD-027, FLD-028, FLD-029, FLD-030, FLD-031, FLD-033, FLD-035, FLD-036。

输出域字段：FIELD-DEDUP-EVIDENCE, FIELD-DELIVERY-STATE, FIELD-EXPORT-SNAPSHOT, FIELD-FRAGMENT-COMPLETENESS, FIELD-REVIEW-REASON, FLD-020, FLD-028, FLD-030, FLD-035。

这些字段是业务对象的读写依赖，不能把所有字段直接作为请求必填。完整含义见[字段规格](field-specs.md)。

验收：AC-039, AC-040, AC-041, AC-042, AC-043；执行办法见[验收映射](acceptance-map.md)，均为计划，未运行生产测试。

</details>

## 已退出本期的接口

| 来源 ID | 当前处置 |
| --- | --- |
| API-005 | 每日号码状态查询与存量priority修改（已取消，退出当前范围）；保留历史 ID，不列为本期实施接口。 |
| API-007 | 平台换主叫接口（退出当前范围）；保留历史 ID，不列为本期实施接口。 |
| API-008 | 系统风控解除/恢复依据（DCC职责，退出平台接口范围）；保留历史 ID，不列为本期实施接口。 |

API-009在来源的not_required只表示无须核验外部供应商服务；本平台查询、手工提交和失败下载仍需实现对应接口或内部处理。

## 不单独新增接口的行为

- 应用详情显示/隐藏/复制

- 页面返回/取消/按钮禁用与解释

- CSV预览与最终priority编辑（可纯前端，服务端提交仍校验）

- 主子分配、归一幂等、秒挂判定、重复冲突处理（内部逻辑，已归属入站/出站能力）

- 没有新增每日衰减/重导预算/换主叫/风控解除接口

## 供应商文档依据

本轮读取既有文档快照，未重新联网验证最新版本。下表记录能核得的原文地址；原地址缺失的项保留本地快照指纹，需开发方取正式文档复验。证据定位、SHA 和摘要见 [interface-evidence.json](interface-evidence.json)。

| 证据 | 来源 | 使用限制 |
| --- | --- | --- |
| DOC-IMPORT | [原文](https://wiki.alicti.cn/html/wiki/API/预测式外呼/任务号码导入接口.html) | 已存只读文本；URL从同目录候选审阅HTML证据表核对。 |
| DOC-FILE | 本地已存文档快照；原网页地址未恢复 | 已存只读文本，正文含完整API地址。未从本轮可见快照元数据找回原文URL；不得假称本轮浏览验证URL。 |
| DOC-TELS | 本地已存文档快照；原网页地址未恢复 | 已存只读文本，正文含完整API地址。未从本轮可见快照元数据找回原文URL。 |
| DOC-DELETE | 本地已存文档快照；原网页地址未恢复 | 已存只读文本，正文含完整API地址。未从本轮可见快照元数据找回原文URL。 |
| DOC-CDR | [原文](https://wiki.alicti.cn/html/wiki/API/通话记录/预测式外呼/预测外呼通话记录接口.html) | 只读文档，不证明精确call/fileId关联已实现。 |
| DOC-PUSH-CONFIG | [原文](https://wiki.alicti.cn/html/wiki/API/配置管理/推送管理/新增推送设置接口.html) | 配置接口；并非实际回调接收接口和完整ACK契约。 |
| DOC-PUSH-53 | [原文](https://wiki.alicti.cn/html/wiki/API/字段定义/推送变量和值/预测外呼导入号码失败推送变量.html) | 变量表，不是认证、ACK、重试、终态和幂等完整协议。 |
| DOC-PUSH-8 | [原文](https://wiki.alicti.cn/html/wiki/API/字段定义/推送变量和值/挂机推送时底层变量和值.html) | 只使用预测外呼段；不同呼叫产品字段不得串用。 |
| DOC-PUSH-52 | [原文](https://wiki.alicti.cn/html/wiki/API/字段定义/推送变量和值/预测外呼呼叫失败推送变量.html) | 正文标题误写客户接听，按URL/失败字段识别；不能因此把它当16。 |
| DOC-PUSH-16 | [原文](https://wiki.alicti.cn/html/wiki/API/字段定义/推送变量和值/预测外呼客户接听状态推送变量.html) | result为success/error，事件名或success不单独证明实际客户接通。 |
| DOC-PUSH-17 | [原文](https://wiki.alicti.cn/html/wiki/API/字段定义/推送变量和值/预测外呼双方接听推送变量.html) | 正向双方接听证据，uniqueId与主话单ID关系仍待核。 |

## 形成可实施接口契约还需补齐

- 补正式仓库的路由、HTTP方法或消息主题及实际模块；逻辑字段引用不是完整线缆报文。

- 逐字段明确必填/类型/枚举/错误码/鉴权与签名、限流、超时和幂等键；继承既有协议应给版本证据。

- 用隔离环境验证同号独立fileId、精确查询/删除、事件去重/迟到、下载可信成功及DCC可靠交付；本清单不宣称已完成联调。

8 项原有真实接口／行为待核继续保留。本清单补充不改变已批准原型，不升级需求或开发门禁状态。

本清单由工作区 `plan.json` 的 `technical_design.interfaces` 生成，避免另维护一套业务规则。生成时规划文件 SHA-256：`8cdc7f4d574d3cde082f8a81d2f6dcae9092e9d9a31181ecfbee4379df55a020`。
