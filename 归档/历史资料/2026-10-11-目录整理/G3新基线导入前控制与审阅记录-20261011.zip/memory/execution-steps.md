# 执行步骤

10个顺序业务步骤；冻结功能ID不重拆。只消费当前只读基线与批准启动规划。新managed任务与旧source未迁移任务隔离。未请求说明文档或标注。所有相对路径均在当前工作区，原目录/inputs/五份事实视图不改。
新增 dcc-runtime、dcc-records、application-access、mock及CSS是因为底座没有本版完整领域及PAGE-001，新record组件隔离2151行既有任务workspace；工具目录不在实现落点。

## Step 01: 隔离本版入口与演示状态

### 需求来源
SC-001 FLD-072；页面来源 LOCAL / 上游只读视图。

### 目标
两个版本同源但前缀独立，写入/清理不互相改变；当前入口无旧需求导航，本地HTTP可打开，资源无阻塞404。

### Files
- index.html
- js/alicti-storage.js
- config/nav.json
- README.md

### Expected Change
update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
更换本版Storage前缀（local/session、事件及Web Locks），不迁移旧缓存；关闭当前工作区旧说明与旧需求入口，四个核心视图保留。更新入口状态为本版合成演示。原目录只读保护。

### Acceptance
两个版本同源但前缀独立，写入/清理不互相改变；当前入口无旧需求导航，本地HTTP可打开，资源无阻塞404。

### Verification
检查源码前缀，浏览器实际写入/读出local与session并核对锁名；1440宽度入口/登录/四视图。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
None。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 02: 复用发布冻结业务图集

### 需求来源
FLOW-001 FLOW-002 SC-001 SC-002 SC-003 SC-004；页面来源 LOCAL / 上游只读视图。

### 目标
业务图保持baseline ID/fingerprint及来源标记，角色/条件/异常可见，默认收起目录，适应宽度/缩放/全屏可用。

### Files
- flowcharts/business-process.html
- flowcharts/sequence-interaction.html

### Expected Change
update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
执行 tools/import_analysis.py publish-diagrams . 确定性发布两份图；本步owner业务图，时序图下一步单独验证。禁止手改图几何或冻结副本。

### Acceptance
业务图保持baseline ID/fingerprint及来源标记，角色/条件/异常可见，默认收起目录，适应宽度/缩放/全屏可用。

### Verification
verify基线、发布来源和本地业务图实际浏览器可见性；节点不少于2，连线标签不空白。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-01 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 03: 独立核对发布时序图集

### 需求来源
SEQ-001 SEQ-002 SEQ-003 SEQ-004 SEQ-005 SEQ-006 SEQ-007 SEQ-008 SEQ-009；页面来源 LOCAL / 上游只读视图。

### 目标
9条时序可读，至少2参与方和1消息可见；统一导航/折叠/适应宽度/全屏；API缺口原状态保留。

### Files
- flowcharts/sequence-interaction.html

### Expected Change
verify-only

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
核对上步确定性发布时序图，保留SEQ-001～SEQ-009原生SVG与宽屏壳，不重新渲染。

### Acceptance
9条时序可读，至少2参与方和1消息可见；统一导航/折叠/适应宽度/全屏；API缺口原状态保留。

### Verification
本地浏览器逐序列查看、截图；verify发布来源meta和冻结字节适配一致性。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-02 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 04: 保存应用授权并演示指定租户身份

### 需求来源
FUNC-001 FUNC-002 AC-017 AC-028 AC-044 AC-045 SC-001 SEQ-005 FLD-003 FLD-004 FLD-005 FLD-061 FLD-062 FLD-063 FLD-064 FLD-065；页面来源 PAGE-001 ACTION-001 ACTION-002。

### 目标
超管可保存虚构配置并演示授权/未授权tenant身份；租户管理员三层拒绝；任务属租户而非应用。无真实key/token/网络请求，运营既有权限保留。

### Files
- index.html
- js/nav.js
- js/app.js
- js/pages/application-access.js
- js/components/dcc-runtime.js
- mock/dcc-v1.1.0.js
- assets/css/dcc-v1.1.0.css
- related-systems/index.html

### Expected Change
create/update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
新增独立本版runtime/fixtures/样式/应用页，因为底座没有应用授权领域。应用保存仅超管；菜单/直达/管理模拟接口同时拒绝租户管理员且不改配置。虚构凭据占位，一租户多应用，指定tenant授权交换模拟身份不授予管理权。关联系统页展示DCC/平台/AliCti职责、partial/missing与合成边界。

### Acceptance
超管可保存虚构配置并演示授权/未授权tenant身份；租户管理员三层拒绝；任务属租户而非应用。无真实key/token/网络请求，运营既有权限保留。

### Verification
模型单元断言管理拒绝不写，身份仅tenant作用域；浏览器分别登录super/admin并验菜单/URL/保存/拒绝，关联系统可读。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-03 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 05: 在现有向导锁定来源并自动接收逐行线索

### 需求来源
FUNC-004 FUNC-005 FUNC-013 FUNC-015 FUNC-016 AC-001 AC-005 AC-006 AC-007 AC-009 AC-010 AC-011 AC-012 AC-013 AC-014 AC-019 AC-028 AC-029 AC-030 AC-031 AC-035 AC-036 AC-037 AC-038 AC-039 AC-040 AC-041 AC-042 AC-043 AC-046 SC-001 SEQ-001 SEQ-006 FLD-001 FLD-002 FLD-003 FLD-004 FLD-005 FLD-006 FLD-007 FLD-008 FLD-009 FLD-010 FLD-011 FLD-012 FLD-013 FLD-014 FLD-015 FLD-016 FLD-017 FLD-018 FLD-019 FLD-068 FLD-069 FLD-070 FLD-071 FLD-072 FLD-073；页面来源 PAGE-002（完整ACTION见acceptance-map）。

### 目标
46AC相关导入项逐行通过；缺R有效、缺priority/lead失败、不整批回滚；重复有效业务推送新批次；接口手工互斥且跨租户/直接函数拒绝。导入不等接通；准确成功与未知独立；record展示关联和三阶段状态。

### Files
- index.html
- js/pages/cloud-task-workspace.js
- js/pages/cloud-call-tasks.js
- js/pages/customer-tasks.js
- js/components/repeat-predictive.js
- js/components/dcc-runtime.js
- js/components/dcc-records.js
- mock/dcc-v1.1.0.js
- assets/css/dcc-v1.1.0.css

### Expected Change
create/update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
现有向导新增DCC接口/手工来源选择，确认创建锁定。新增record组件因原2151行工作区需隔离本版记录区；记录页只读来源，手工按钮常驻，接口来源禁用。统一模型校验tenant/task/source与必填leadCode/priority；R可选无字典；逐行独立、新记录单号新批次，保留taskId与时间，自动提交。手工提交前统一priority再逐条覆盖。仅同任务待提交高priority/同级本地时间FIFO，不重送unknown/不撤回已提交/不同任务独立。同步保留result/importTotal/successTotal/invalidTotal来源，准确行成功正常保存，只有汇总不盲配，矛盾待核。守卫旧import/assign/prepare/apply/commitDirectImport/syncAssigned/RepeatPredictive/edit/copy；新managed任务不可由旧四列CSV/名单/平台再次联系绕过。source缺失旧任务不自动迁移。主叫权重/供应商retry保留并与DCC重导区分。

### Acceptance
46AC相关导入项逐行通过；缺R有效、缺priority/lead失败、不整批回滚；重复有效业务推送新批次；接口手工互斥且跨租户/直接函数拒绝。导入不等接通；准确成功与未知独立；record展示关联和三阶段状态。

### Verification
模型断言混合输入/锁源/跨租户/排序/unknown守卫/准确同步与冲突；浏览器现有向导确认来源、接口记录禁用手工、手工逐条priority及记录页、旧入口拒绝。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-04 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 06: 归并53失败分片并按快照下载

### 需求来源
FUNC-006 FUNC-010 FUNC-013 FUNC-015 FUNC-017 AC-002 AC-008 AC-013 AC-018 AC-026 AC-027 AC-028 AC-029 AC-031 AC-035 AC-037 AC-038 AC-039 AC-040 AC-041 AC-042 AC-043 SC-001 SEQ-001 SEQ-007 FLD-020 FLD-021 FLD-022 FLD-023 FLD-024 FLD-025 FLD-026 FLD-027 FLD-028 FLD-052 FLD-053 FLD-058 FLD-060 FLD-066 FLD-067 FLD-070 FLD-071 FLD-074；页面来源 PAGE-002（完整ACTION见acceptance-map）。

### 目标
2/3→1/3→重复2/3→3/3仅每个失败一次；无推送不宣告零失败。S(A,B)后C到达，成功只删A/B，C保留；业务客户和DCC待补送不变。

### Files
- js/components/dcc-runtime.js
- js/components/dcc-records.js
- mock/dcc-v1.1.0.js
- assets/css/dcc-v1.1.0.css

### Expected Change
update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
53按enterprise映射tenant/task/fileId/原始号码关联精确本地batch/lead；乱序/重复/迟到保留，歧义待核。total/current仅失败推送组，不推定导入终态。分开local/import/call失败和unknown，接口导入失败立即按固定DCC地址模拟回传，手工仅查看；失败补送不重导。下载生成独立快照，生成/点击不清，失败/中断保留，独立可信成功模拟仅清该快照明细/文件，迟到新失败留下一次。去重/分片/关联/交付状态不清，不重生已导出重复。

### Acceptance
2/3→1/3→重复2/3→3/3仅每个失败一次；无推送不宣告零失败。S(A,B)后C到达，成功只删A/B，C保留；业务客户和DCC待补送不变。

### Verification
模型断言分片/歧义/声明冲突/快照生命周期/已导出重复/DCC补送；浏览器失败页签、生成下载、模拟失败/中断/成功和迟到新失败交互。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-05 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 07: 关联每次结果并识别秒挂与无话单失败

### 需求来源
FUNC-010 FUNC-011 FUNC-012 FUNC-013 FUNC-015 AC-002 AC-003 AC-004 AC-018 AC-020 AC-021 AC-022 AC-023 AC-024 AC-026 AC-027 AC-028 AC-029 AC-033 AC-034 AC-035 AC-037 AC-038 AC-039 AC-040 AC-041 AC-042 AC-043 SC-002 SC-003 SC-004 SEQ-002 SEQ-003 SEQ-004 FLD-029 FLD-030 FLD-031 FLD-032 FLD-033 FLD-034 FLD-035 FLD-036 FLD-037 FLD-038 FLD-039 FLD-040 FLD-041 FLD-042 FLD-043 FLD-044 FLD-045 FLD-046 FLD-047 FLD-048 FLD-049 FLD-050 FLD-051 FLD-052 FLD-053 FLD-054 FLD-055 FLD-056 FLD-057 FLD-058 FLD-059 FLD-060 FLD-074 FLD-075 FLD-076 FLD-077；页面来源 PAGE-002（完整ACTION见acceptance-map）。

### 目标
秒挂边界矩阵、无话单稳定事件/缺callID、0/1/null最后标记、重复/SIP更新、接口失败补送均正确；不建立平台重导计数/倒计时。

### Files
- js/components/dcc-runtime.js
- js/components/dcc-records.js
- mock/dcc-v1.1.0.js
- assets/css/dcc-v1.1.0.css

### Expected Change
update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
按稳定callID/event关联每次结果，接口固定地址回传/手工仅查看，首送失败可补送且不改业务记录。秒挂必须客户真接通+客户挂断+客户真实有效0～2秒（含0/2），null/未接通/坐席挂排除，不用桥接时长。可信无话单禁呼/限呼/无中继独立记录立即回传，不等恢复/话单；空话单查询不伪造失败。finishRetryFlag严格整数0/1/未知，不把最后一条当业务计划完成。重复不新呼叫，同call SIP晚更新同对象且独立回传更新，状态缺口/冲突待核。

### Acceptance
秒挂边界矩阵、无话单稳定事件/缺callID、0/1/null最后标记、重复/SIP更新、接口失败补送均正确；不建立平台重导计数/倒计时。

### Verification
模型按SC-002/003/004和SEQ消息顺序断言；浏览器各合成场景可切换，记录详情/原字段来源/回传状态/SIP晚更新可见。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-06 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 08: 按原导入自然日跟进当前优先级

### 需求来源
FUNC-007 FUNC-008 AC-014 AC-015 AC-032 SC-001 SEQ-008 FLD-040 FLD-041 FLD-042 FLD-043 FLD-044 FLD-045 FLD-069 FLD-073；页面来源 PAGE-002（完整ACTION见acceptance-map）。

### 目标
23:59→次日00:00触发日差；p3两日为1且同日重跟进仍1；unknown/接通保持；已删除不跟进。

### Files
- js/components/dcc-runtime.js
- js/components/dcc-records.js
- mock/dcc-v1.1.0.js

### Expected Change
update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
保留原北京时间导入日，可信未拨/未接通按日差衰减最低1，重复同日不重降；当天及历史均参与。状态未知/无话单不足不等未拨；已接通不凭空降。批次继承原日和当前值，供应商存量priority写回能力单独待核。工作时间到来不提权，不等禁止呼叫。

### Acceptance
23:59→次日00:00触发日差；p3两日为1且同日重跟进仍1；unknown/接通保持；已删除不跟进。

### Verification
模型显式北京时间时钟矩阵；浏览器日期与状态模拟及原日期/当前priority/待核原因可见。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-07 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 09: 精准删除并保留DCC原链重推

### 需求来源
FUNC-009 FUNC-004 FUNC-010 AC-001 AC-002 AC-005 AC-006 AC-007 AC-009 AC-010 AC-012 AC-014 AC-016 AC-018 AC-019 AC-024 AC-025 AC-026 AC-027 AC-029 AC-030 AC-031 AC-036 AC-037 AC-038 AC-039 AC-040 AC-041 AC-042 AC-043 SC-001 SC-002 SC-004 SEQ-009 SEQ-001 FLD-046 FLD-047 FLD-048 FLD-049 FLD-050 FLD-051 FLD-058 FLD-069 FLD-074 FLD-075；页面来源 PAGE-002（完整ACTION见acceptance-map）。

### 目标
同号两批删除一批不影响另一；成功/拒绝/未知状态真实保留；DCC重推新批保留原链，不覆盖旧客户。

### Files
- js/components/dcc-runtime.js
- js/components/dcc-records.js
- mock/dcc-v1.1.0.js

### Expected Change
update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
DCC指定tenant/task/batch精确记录，明确供应商删除成功后本地保留、仅对应停止衰减并回传删除状态；失败不删/不停，未知待核。同号其他记录保护。DCC再次业务推送沿原供应商task生成关联新batch并继承原日期/当前priority；不计算业务重呼预算、不自行定时重推，变化手机号/同号多线索未决保留待核。

### Acceptance
同号两批删除一批不影响另一；成功/拒绝/未知状态真实保留；DCC重推新批保留原链，不覆盖旧客户。

### Verification
模型断言准确范围/失败/unknown/同号保护/继承；浏览器指定批次模拟删除和DCC重推，记录仍可查看。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-08 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

## Step 10: 形成实际产品方案评审输入

### 需求来源
FUNC-001 FUNC-002 FUNC-004 FUNC-005 FUNC-006 FUNC-007 FUNC-008 FUNC-009 FUNC-010 FUNC-011 FUNC-012 FUNC-013 FUNC-015 FUNC-016 FUNC-017 AC-001 AC-002 AC-003 AC-004 AC-005 AC-006 AC-007 AC-008 AC-009 AC-010 AC-011 AC-012 AC-013 AC-014 AC-015 AC-016 AC-017 AC-018 AC-019 AC-020 AC-021 AC-022 AC-023 AC-024 AC-025 AC-026 AC-027 AC-028 AC-029 AC-030 AC-031 AC-032 AC-033 AC-034 AC-035 AC-036 AC-037 AC-038 AC-039 AC-040 AC-041 AC-042 AC-043 AC-044 AC-045 AC-046 FLOW-001 FLOW-002 SEQ-001 SEQ-002 SEQ-003 SEQ-004 SEQ-005 SEQ-006 SEQ-007 SEQ-008 SEQ-009 FLD-001 FLD-002 FLD-003 FLD-004 FLD-005 FLD-006 FLD-007 FLD-008 FLD-009 FLD-010 FLD-011 FLD-012 FLD-013 FLD-014 FLD-015 FLD-016 FLD-017 FLD-018 FLD-019 FLD-020 FLD-021 FLD-022 FLD-023 FLD-024 FLD-025 FLD-026 FLD-027 FLD-028 FLD-029 FLD-030 FLD-031 FLD-032 FLD-033 FLD-034 FLD-035 FLD-036 FLD-037 FLD-038 FLD-039 FLD-040 FLD-041 FLD-042 FLD-043 FLD-044 FLD-045 FLD-046 FLD-047 FLD-048 FLD-049 FLD-050 FLD-051 FLD-052 FLD-053 FLD-054 FLD-055 FLD-056 FLD-057 FLD-058 FLD-059 FLD-060 FLD-061 FLD-062 FLD-063 FLD-064 FLD-065 FLD-066 FLD-067 FLD-068 FLD-069 FLD-070 FLD-071 FLD-072 FLD-073 FLD-074 FLD-075 FLD-076 FLD-077；页面来源 LOCAL / 上游只读视图。

### 目标
15FUNC/46AC/2PAGE/13ACTION全部反映实际方案且映射真实文件；上游版本与哈希一致，无代理业务/运营批准。

### Files
- product-input.json
- README.md

### Expected Change
create/update

### 输入
当前冻结记忆、memory/field-map.md、相关SC/SEQ明细、CLAUDE.md和docs/decisions.md；partial/missing保持合成边界，不读raw/Wiki。

### 工作
根据实际实现与冻结ID生成唯一product-input.json（features/acceptance/pages/rules/flows/fields），保留产品方案文件/行为落点、synthetic接口缺口、当前待业务/运营真实确认。不是把原需求自动标审。更新README启动/路径/真实验证状态，不生成同义PRD、说明或标注。

### Acceptance
15FUNC/46AC/2PAGE/13ACTION全部反映实际方案且映射真实文件；上游版本与哈希一致，无代理业务/运营批准。

### Verification
JSON结构/ID与实际文件校验、基线verify，最终内容上复验此前所有步骤后进入S8；业务/运营批准需实际用户。
- Browser Evidence Tool: playwright-cli when needed；资源/console/桌面可见行为；证据留/tmp，不写交付业务目录。

### Verification Skill
prototype-verifier

### 依赖
step-09 pass。

### 失败处理
实现/表现缺陷留S7修复复验；拆分遗漏回S6；业务事实矛盾回04，不修改冻结事实。相同检查点三次失败按circuit-state熔断。

