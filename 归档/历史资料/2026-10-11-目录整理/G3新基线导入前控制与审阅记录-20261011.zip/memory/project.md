# 项目记忆 — 当前迭代 云呼叫中心 v1.1.0 DCC增量原型

## 项目定位

- 项目名称：云呼叫中心
- 当前迭代：云呼叫中心 v1.1.0 DCC增量原型
- 需求版本：1.1.0
- 冻结基线：`ra-云呼叫中心-v1.1.0-原始需求重新分析草稿-21476e056b26e8cc` / `21476e056b26e8ccfde197134151e812271da709fbde7b01119617dd5157406b`
- 类型：无构建步骤的静态前端演示原型
- 入口：`index.html`

## 产品目标

DCC决策重导，平台单一任务来源导入与每次结果回传；保留自然日priority跟进；异步导入失败分片关联/回传及快照导出，超管管理应用、同任务待提交优先级FIFO

## 目标用户

- 超管
- 运营人员

## 核心页面列表

- `PAGE-001` 应用接入管理：系统设置 / 应用接入管理；场景 ["SC-001"]；时序 ["SEQ-005"]；功能 ["FUNC-001", "FUNC-002"]
- `PAGE-002` 预外呼任务记录页：云呼叫 / 预外呼 / 任务 / 记录页；场景 ["SC-001", "SC-002", "SC-003", "SC-004"]；时序 ["SEQ-001", "SEQ-002", "SEQ-003", "SEQ-004", "SEQ-006", "SEQ-007", "SEQ-008", "SEQ-009"]；功能 ["FUNC-004", "FUNC-005", "FUNC-006", "FUNC-007", "FUNC-008", "FUNC-009", "FUNC-010", "FUNC-011", "FUNC-012", "FUNC-013", "FUNC-015", "FUNC-016", "FUNC-017"]

## 核心用户路径

- `FLOW-001` 导入、结果分流与原始链闭环：创建任务提交时锁定接口/手工方式，校验tenant/task，应用仅鉴权与追踪 → 逐行校验并保存单号批次自动提交；同步数量准确记录，result0不等逐条全成功；待提交高优先级先/同级FIFO，已提交不重排，仅同任务，不同任务独立 → 53失败推送分片回查企业/任务/供应商fileId/原始号码到本地批次和leadCode，重复不新增迟到不丢；接口任务回传导入阶段失败，手工只查看，不计呼叫不自重导 → 供应商每次事件/话单回查任务批次线索手机号；无话单失败独立保存、秒挂按真实条件识别 → 接口任务每次结果回传后台固定DCC地址，手工任务仅平台查看；重复/晚更新不制造新呼叫 → DCC决定是否/何时重新导入；平台不创建重导计划或额度 → 保留原导入北京时间自然日priority衰减，可信未拨/未接通才降级，精准删除成功停降级
- `FLOW-002` 失败导出与业务记录保护：本地校验失败、供应商同步/异步导入失败分类进入既有失败下载入口；呼叫失败独立记录 → 按已知失败分片展示收齐或不完整/待核，不推定整个导入终态 → 生成本次失败快照和导出文件；点击/生成不等成功下载 → 可信成功下载只清本次快照明细和文件；中断/失败保留 → 保留必要关联、去重、分片及DCC交付状态；迟到新失败可再次下载，已导出重复不再生成

## 主要数据对象

- 冻结基线未单列数据对象；按已冻结场景、字段与状态模型定位，不从功能名称反推对象。

## 交付方式

以本地静态 HTML 原型交付；业务流程图和时序交互图复用冻结基线中的自包含 HTML，并由原型交付导航统一打开。

## 上游假设与确认边界

保留上游假设的原文与状态；G3 接受风险不等于接口或业务假设已获验证。

- P1仅分析排序，不是实施先后
- 北京时间原导入自然日priority衰减保留；真实状态/存量修改能力与每日时刻交开发核实
- DCC管理重导与计数，平台不建预算/计时器；供应商内部尝试完整性及SIP晚更新交开发核实
- 工作时间边界（SRC-078/079）：平台按DCC传入priority保存、同任务排序并提交，不新增工作时间策略、不因工作时间到来自动提权；既有自然日衰减最低1、同级FIFO与已提交不撤回保持。低优先级不是禁止呼叫；无新增功能。

## 范围

- In scope：["SC-001", "SC-002", "SC-003", "SC-004"]
- Out of scope：["真实凭据/token/呼叫/供应商删除", "自动解除未证实风控", "旧R排序/3秒/5分钟/1次默认", "05开发包/发布/039"]

## 未确认 open items 引用

- 见 `memory/open-items.md`；上游已接受风险保持原决策，不在原型 Loop 内静默改写。

## 目录结构

- `inputs/requirement-analysis/` — 已校验、只读的需求分析冻结基线
- `memory/requirement-analysis-baseline.json` — 原型侧追溯目录
- `memory/feature-list.md` — 功能事实视图
- `flowcharts/` — 从冻结图集发布的本地 HTML 交付页
- `pages/`、`js/`、`mock/` — 原型页面、交互与模拟数据

## 工作原则

- 业务事实只从冻结基线读取；范围、功能、规则或接口结论变化时回到需求分析 Loop 生成新基线。
- 原型 Loop 只补充展示、交互、Mock 和演示编排决策，并通过上游 ID 保持追溯。
- 不消费 LLM Wiki/query 正文，不沿来源引用回查知识库；新材料与事实缺口交还需求分析 Loop。

## 基础确认事实与上游状态

以下内容由冻结 project_facts 原样物化；字段中的假设、缺口或风险状态不因导入而升级。

| 事实类别 | 冻结记录 |
| --- | --- |
| 角色与职责 | {"description": "应用管理仅超管；租户管理员菜单/页面/管理接口拒绝，不实际改变账号权限", "name": "超管"} |
| 角色与职责 | {"description": "按既有权限导入、查看及下载失败明细；不授予应用管理权", "name": "运营人员"} |
| 系统与责任边界 | {"description": "主动传入客户与精准删除请求", "name": "DCC"} |
| 系统与责任边界 | {"description": "本地留存、优先级、状态守卫与关联批次", "name": "云呼叫中心"} |
| 系统与责任边界 | {"description": "供应商任务、号码导入、实际调度/主叫选择与结果；真实能力待核", "name": "AliCti供应商"} |
| 产品结构 | {"description": "用户明确新增系统设置菜单；凭证占位，无可用密钥/token；仅超管可访问/操作，服务端拒绝租户管理员", "name": "系统设置/应用接入管理"} |
| 产品结构 | {"description": "用户明确任务级单独记录页，手工导入按钮常驻；导入/重呼/失败页签是分析方案，未冒充用户实测", "name": "预外呼任务/记录页"} |
| 状态与转换 | {"id": "STATE-001", "name": "导入业务记录", "states": ["本地校验失败", "本地保存", "供应商导入待提交", "供应商同步数量与准确成功证据", "供应商导入失败（同步/53）", "供应商结果未知/待核", "供应商已删除（本地保留）"], "transitions": ["有效行本地保存 → 同任务待提交priority高先/同级FIFO → 自动提交；已提交不重排", "同步准确证据正常记录；只汇总不盲指定成功行，未知待核", "53异步失败 → 分片关联合并 → 失败导出及按任务来源回传/查看，不计实际呼叫", "可信下载成功仅清本次快照明细/文件；保留关联、去重、分片、交付状态，后到新失败待再次下载", "精准删除明确成功 → 供应商已删除（本地保留）"]} |
| 状态与转换 | {"id": "STATE-002", "name": "每次结果与回传记录", "states": ["结果已关联", "结果待核", "接口回传待发送", "回传成功", "回传失败待补送", "手工仅平台查看"], "transitions": ["每次结果/晚更新 → 同对象准确关联 → 接口回传或手工查看", "重复不新增呼叫；回传失败记录并补送，不改变业务结果"]} |

## 完整冻结输入入口

路径相对于原型项目根目录。结构化事实约束实现，Markdown/HTML 用于对照确认与图集复用；本记忆摘要不替代这些入口。

| Entry | Role | Frozen Path |
| --- | --- | --- |
| business_rules | business_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/memory/business-rules.json |
| business_scenario_atlas | review_view | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/outputs/business-scenario-atlas.html |
| feature_list | product_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/memory/feature-list.json |
| feature_list_view | review_view | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/outputs/feature-list.md |
| interaction_sequence_atlas | review_view | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/outputs/interaction-sequence-atlas.html |
| interface_index | external_dependency_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/interfaces/interface-index.json |
| interface_verification_matrix | review_view | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/outputs/system-sequence-interface-verification-matrix.md |
| normalized_user_stories | business_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/memory/normalized-user-stories.json |
| open_items | risk_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/runtime/open-items.json |
| page_index | prototype_planning_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/planning/page-index.json |
| page_planning | review_view | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/outputs/menu-and-page-planning-reference.md |
| page_structure_atlas | review_view | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/outputs/page-structure-atlas.html |
| product_baseline | review_view | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/outputs/product-structure-and-business-process-baseline.md |
| project_facts | business_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/memory/project-facts.json |
| scenario_index | business_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/scenarios/scenario-index.json |
| sequence_index | interaction_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/sequence-index.json |
| traceability | trace_fact | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/runtime/traceability.json |
| verification_report | verification_evidence | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/runtime/verification-report.json |

## 场景与交互时序定位

S6/S7/S8 按相关 ID 读取下列冻结明细与图集，落实消息顺序、回调和异常分支；不是只发布图页。

| ID | Name | Scenario | Frozen Detail |
| --- | --- | --- | --- |
| SC-001 | DCC客户接收与按手机号拆批 | SC-001 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/scenarios/SC-001.json |
| SC-002 | 线路侧风控结果关联与回传 | SC-002 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/scenarios/SC-002.json |
| SC-003 | 无话单失败原因记录与回传 | SC-003 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/scenarios/SC-003.json |
| SC-004 | 客户秒挂识别与每次结果回传 | SC-004 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/scenarios/SC-004.json |
| SEQ-001 | DCC导入逐行保存、单号拆批与自动提交 | SC-001 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-001.json |
| SEQ-002 | 线路侧风控结果关联与回传 | SC-002 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-002.json |
| SEQ-003 | 无话单失败原因记录与回传 | SC-003 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-003.json |
| SEQ-004 | 客户秒挂识别与每次结果回传 | SC-004 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-004.json |
| SEQ-005 | 系统设置应用接入与租户身份 | SC-001 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-005.json |
| SEQ-006 | 手工线索导入与提交前priority覆盖 | SC-001 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-006.json |
| SEQ-007 | 接口及手工失败下载生命周期 | SC-001 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-007.json |
| SEQ-008 | 北京时间自然日状态跟进与priority降级 | SC-001 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-008.json |
| SEQ-009 | DCC精准删除成功与本地留存 | SC-001 | inputs/requirement-analysis/ra---v1.1.0---21476e056b26e8cc/sequences/SEQ-009.json |
