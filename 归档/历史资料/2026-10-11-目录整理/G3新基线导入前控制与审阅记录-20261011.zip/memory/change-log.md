# 本轮变更记录

## step-01：入口与存储隔离
- 日期：2026-10-10。
- 文件：index.html、js/alicti-storage.js、config/nav.json、README.md。
- 变更：新Storage前缀覆盖local/session、storage事件与Web Locks；不读取旧前缀或迁移旧状态。当前主入口关闭旧说明/旧今日需求/旧页面结构链接，保留四核心视图和版本入口，原目录未改。入口明确合成演示实现中。
- 验证：交prototype-verifier检查，结果以verification-log为准。

## step-02：冻结业务图集复用
- 2026-10-10 运行publish-diagrams，确定性发布business-process和sequence-interaction（后者step-03独立verify-only），保留原几何并注入来源/统一导航。基线verify通过。
- 文件：flowcharts/business-process.html、flowcharts/sequence-interaction.html。

## step-03：时序图独立核对
- 文件：flowcharts/sequence-interaction.html，verify-only；step-02确定性生成后保持不改。按9条冻结时序核对来源和实际可见图，未重绘。

## step-04：应用保存、指定租户合成身份与关联系统
- 日期：2026-10-10。
- 文件：index.html、js/app.js、js/nav.js、js/pages/application-access.js、js/components/dcc-runtime.js、mock/dcc-v1.1.0.js、assets/css/dcc-v1.1.0.css、related-systems/index.html。
- 变更：系统设置语义下接入应用管理菜单/路由，复用 PlatformUI 和灰白蓝视觉；两个既有虚构应用仅保存授权配置，无新增、删除、启停或真实密钥动作。菜单、直达、页面及模型保存均从当前 AppState 判定超管；租户管理员直接保存拒绝且不写配置。
- 身份边界：DccRuntime 使用独立本版存储；凭证仅固定不可用占位。指定 tenant 授权校验可成功或拒绝；返回合成租户业务身份，任务归租户、应用只来源追踪，不调用 AppState 切换或授予管理权。保存与交换按 SEQ-005 显示处理及反馈。
- 关联系统：ready 页展示 DCC 业务重导/计数、平台导入/准确关联/每次回传、AliCti 实际调度职责；逐项保留 API-001～API-010 的 missing/partial/not_required 和 real_call_allowed=false，说明后台固定回传边界、1060/主叫证据限制及仅合成。
- 实现检查：5 个涉及 JS 的 node --check 通过。单步验证交主控 prototype-verifier；正式结果以 verification-log 为准。
- 只读复核修正：公开 snapshot 与 listApplications 同样要求当前超管；内部保存使用私有副本，租户管理员不能通过诊断快照读取管理配置。

## step-05：创建锁源、逐行导入与独立记录
- 日期：2026-10-10。
- 文件：index.html、js/pages/cloud-task-workspace.js、js/pages/cloud-call-tasks.js、js/pages/customer-tasks.js、js/components/repeat-predictive.js、js/components/dcc-runtime.js、js/components/dcc-records.js、mock/dcc-v1.1.0.js、assets/css/dcc-v1.1.0.css。
- 向导：既有预外呼新建步骤新增 DCC 接口 / 手工来源选择，确认创建时持久锁定；编辑保留锁定字段，复制新任务重新选源。供应商重呼、拨打策略和主叫权重继续复用，不作为 DCC 重导额度。
- 模型：新任务单独登记本版来源与合成供应商任务标识，旧 source 缺失任务不迁移；DCC 使用已签发租户业务身份，手工复用 task.create 与对象租户范围。逐行验证 leadCode / 手机号 / 独立 priority，R 可选且无字典；有效行各建独立记录及单号批次，校验失败另存且不回滚有效行。
- 提交：保存后按同任务待提交 priority 高先、同级本地接收 FIFO 自动提交，不撤回已提交或重送 unknown；不同任务独立。保留同步响应 result、fileId、taskId 和三项数量来源，准确单号成功与汇总/矛盾待核分开，导入不算实际呼叫。同 leadCode+phone 业务重推仍新批，继承原导入日与当前 priority；变更或歧义关系暂停，不按最新同号盲配。
- 页面：任务列表 / 任务中心进入导入重呼记录区，来源只读，手工按钮常驻且接口来源禁用；手工 CSV 预览、统一 priority 和提交前逐条覆盖。四套合成线索样例支持有效/混合拒绝/超时/数量矛盾；详情展示准确关联及原始同步证据。本地、供应商导入、实际呼叫三阶段独立。
- 旧写入：CustomerTasks 导入/分配/prepare/apply/commit/rollback/旧结果及 RepeatPredictive 最终写入按 canonical task、附件真实行及持久标记拒绝 managed；工作区 direct import、assigned sync、名单附着及旧再次联系均守卫，新任务不能由旧四列 CSV 或伪造去标记对象绕过。
- 实现检查：7 个涉及 JS 的 node --check 通过。浏览器及正式领域验证交主控 prototype-verifier，结果以 verification-log 为准；本记录不提前标注步骤通过。
- 浏览器呈现修正：新本版预外呼向导移除旧可选号码去重策略，固定保留每条有效推送并新建单号批次；直接修改旧 isRepeat 入口拒绝且确认门禁校验保留模式。预览、确认和时段提示改为创建后在任务记录页按锁定来源接收/导入，旧任务及自动外呼路径保留原有名单行为。
- 新本版向导第三步、确认摘要及预览明确“供应商重呼设置”，说明其与 DCC 业务重导/恢复/计数分开；仅包装当前向导的展示标题，保留 legacy retry 字段与编辑器逻辑。
- 同一呈现修正补齐确认页后续提示：接口来源引导当前任务记录页接收 DCC，手工来源引导记录页手工预览/提交；新向导步骤标签与待接收/待导入状态保持相同语义。
- 创建成功 toast 同步按锁定来源引导任务记录页接收 DCC 或手工导入，避免新任务落回旧“继续添加客户”说明。

- step-04缓存修正：更新index内已改app/nav/storage脚本版本参数，避免正常重载继续读旧导航；失败证据已记录，待复验。

- step-01补核：侧栏旧G1/G2/G3待确认文案改当前批准/产品待评审状态；step-04细化：来源追踪去除实现ID，关联系统加入空favicon防止浏览器默认请求404。

- 任务记录集成修正：新建时在 AliCtiDemo.taskCreated 之后、创建事务与记录登记之前，将同一合成供应商任务返回的 demoProviderTaskId 字符串绑定为 dccSupplierTaskId，providerTaskId 保持 null；已保存任务及账本的锁定标识不迁移。新合成编号分配考虑已恢复任务编号，避免新会话重新从编号起点碰撞。
- 记录时间展示改用局部 Asia/Shanghai 格式化，列表、详情与提交证据以北京可读日期时间呈现，原始毫秒及响应事实不改。managed 任务中心从只读记录账本显示本地条数、导入接受/待核及本地失败，实际呼叫保持待核；不写旧客户总数或完成进度。编辑页供应商重呼标题与新向导一致，既有 retry 参数保持原样。
- 编号复用反例修正：新合成 task 编号分配同时读取 DccRuntime 本版持久账本保留的所有 supplierTaskId；已从任务目录删除但保留关联的编号仍保留，新会话不重用。保留账本无法解析则中止分配，不迁移或重写账本；缓存版本更新为 step05h。

## step-06：53 失败分片、独立快照与固定 DCC 交付
- 日期：2026-10-10。
- 文件：index.html、js/components/dcc-runtime.js、js/components/dcc-records.js、mock/dcc-v1.1.0.js、assets/css/dcc-v1.1.0.css。
- 关联：使用显式合成 enterprise→tenant 映射交叉核对 canonical 任务范围、供应商 taskId/fileId 和当次已提交请求的原始号码数据；提供的 leadCode、priority 与 R 同时过滤候选，不依赖可变 current priority 或最近同号。映射不明/跨范围明确拒绝并返回原始待核证据，多候选和成功/失败矛盾保留各来源待核，不写假关联。
- 分片：保留各次原始声明和同片号版本，2→1→重复2→3 的乱序、重复和迟到独立归并；声明/内容冲突不覆盖。已声明分片收齐只证明失败推送组收齐，全导入终态始终未知，无 53 不推定零失败。演示的稳定分片组标识仅为合成适配，真实协议仍 partial。
- 失败与交付：本地校验、供应商导入失败与关联待核分开进入活动下载明细；必要事件、原始证据、去重、版本和分片持久保留。准确 API 导入失败模拟交付后台固定 DCC 接收端，保留 tenant/task/batch/lead/phone 和原始原因；手工任务仅平台查看，不创建交付。失败补送仅更新原交付尝试和状态，不新增供应商提交、业务记录或实际呼叫。
- 下载：生成冻结本次明细 ID/版本和已知完整性的独立 CSV 快照；生成/点击不代表成功，无固定到期，失败和中断保留。独立可信合成成功只清该快照绑定版本的活动明细和文件，迟到 C 或同失败的新证据版本继续保留；必要业务关联、去重、分片及 DCC 待补送状态不清，已导出相同事件不再生。
- 页面：既有记录区新增导入记录 / 导入失败与下载 / DCC 交付内部页签，复用 PlatformUI、灰白蓝及北京时间展示；保留常驻手工按钮和锁源说明。处理、拒绝和结果均可见，下载信号与补送按钮明确仅合成，不设置真实 URL 或发送真实回调。
- 实现检查：涉及三个 JS 的语法检查通过；单步实际浏览器与正式门禁交主控 prototype-verifier，结果以 verification-log 为准。本记录不提前宣布本步通过，未进入 step-07。

## step-07：逐次实际结果、秒挂、稳定无话单与 SIP 晚更新
- 日期：2026-10-10。
- 文件：index.html、js/components/dcc-runtime.js、js/components/dcc-records.js、mock/dcc-v1.1.0.js、assets/css/dcc-v1.1.0.css。
- 关联与结果：按已核合成企业映射、canonical 任务、精确记录/批次/fileId/号码和稳定 callID 或无话单事件标识关联。缺可信语义、缺稳定标识、关联歧义和同对象非 SIP 矛盾独立保留待核及各次原证据，不按最新同号盲配、不造话单或新呼叫。同一 unchanged 结果重放不新增对象或交付。
- 秒挂：客户真接通、客户主动挂断与可信有效客户 customerBridgeDuration 0～2 秒共同成立，含 0/2 边界。时长缺失/异常、接听未知和语义未核保持 pending_review / unknown；未接听或坐席挂断明确排除。坐席 agentBridgeDuration 仅作为合成原字段显示，不替代客户时长；onHookSource 原字段及合成挂断语义同时保留，真实映射仍待核。
- 无话单：可信禁呼未解禁、限呼未到期和无可用中继事件有稳定标识和准确业务关联时立即独立保存与按来源交付，不等待恢复或话单，不造 callID 或 finishRetryFlag。空话单查询只记 unknown 查询证据，不推未拨或失败。
- 最后标记与晚更新：finishRetryFlag 只解释数字整数 0/1，其余类型、缺省与 null 原值和提供状态保持 unknown；不从 SIP 标记推导，不宣布任务或 DCC 计划完成。同 callID 的可信 SIP 晚更新保留同对象、原结果和各来源，版本递增并建立独立交付；重放更新不新建呼叫。
- 来源分流：API 每次准确实际结果及 SIP 更新均模拟交付后台固定 DCC 接收端；手工只在平台查看。首送失败与补送共用既有交付状态，补送只改原交付尝试，不增加导入、业务记录或实际呼叫。没有平台重导计数、预算、恢复或倒计时。
- 页面：既有记录区增加实际结果页签、呼叫/稳定无话单独立表、原字段/秒挂/严格最后标记/来源/更新详情和可切换的正向边界、接听未知、时长未核/异常及排除合成场景；导入列表及详情按 recordId 展示真实已观察对象，不再固定显示无结果。共用 DCC 页同时显示导入失败与每次结果/更新的版本交付，旧下载与補送交互保持可用。
- 实现检查：涉及三个 JS 的语法检查通过，页面子任务仅修改记录组件与样式；实际浏览器与步骤门禁交主控 prototype-verifier，正式结果以 verification-log 为准。本记录不提前宣布本步通过，未进入 step-08。

## step-08：可信状态获取与原日 priority 跟进
- 日期：2026-10-10。
- 文件：index.html、js/components/dcc-runtime.js、js/components/dcc-records.js、mock/dcc-v1.1.0.js；沿用既有 DCC 样式。
- 状态获取：独立 FUNC-007 合成入口覆盖当天和历史记录，按 canonical 任务范围和精确 record/batch 校验所有已提供定位字段；返回的状态、来源及原证据逐次留存。未知、缺失、仅空话单、未可信语义、状态声明矛盾或与同批实际接通冲突均待核，不推定未拨；已确认 supplierDeleted 记录排除查询，未增加删除操作。
- 降级：独立 FUNC-008 合成入口必须有同一北京日可信未拨/已拨未接通状态。从 lastDecayDay 到当前北京自然日的差继续减当前 priority，最低 1；原日与已处理日期不回退，不借工作时间提权。记录原日、initial/current、已衰减日期及历史，新批次继承原日/current/lastDecayDay；高值 8→7→新批 7→次日两批 6 避免再次扣完整历史。未确认原日期/此前衰减日期、已接通、未知和已确认供应商删除保持不降。
- 写回边界：本地 priority 目标及日期处理可观察，供应商存量修改与逐条确认独立标 pending_contract；API-005 仍 missing，不声称真实写回成功，低 priority 不等于禁呼，无平台重导预算、恢复或倒计时。
- 页面与样例：新增状态与 priority 页签、明确北京时钟、独立获取/降级按钮及日志；合成原 10月8日 priority 8 的历史线索支持 10月9日处理、显式 DCC 再次输入和 10月10日跟进。原日/新批时间/继承/状态原证据/本地 priority 历史与供应商待核分别展示，手工不混入 DCC 再次推送。
- 历史投影保护：按既有只读交付约定，当 HistorySnapshot.read_only===true 时，DccRuntime 写入、合成接收、补送和身份发放拒绝；任务写入在 canAccessTask writing 分支统一守卫，应用保存、身份交换、DCC 业务接收及排队自动提交另核绕过路径。按原 role/scope 的读取仍可用；此为展示投影保护，不新增业务 FUNC，不改已冻结快照或 tools。
- 实现检查：涉及三个 JS 的语法检查通过；当前业务实现与浏览器验证交主控 prototype-verifier，正式结果以 verification-log 为准。本记录不提前宣布本步通过，未进入 step-09。

- 本步领域类型修正：当前状态 states:[] 时，将非空检查写为显式布尔判断，trusted 始终为 boolean false，不返回数字 0；缺失仍 unknown/待核且不降级。仅修该布尔链与缓存版本 step08b，正式复验由主控记录。

## step-09：精准供应商删除与保留原链的 DCC 显式推送
- 日期：2026-10-10。
- 文件：index.html、js/components/dcc-runtime.js、js/components/dcc-records.js、mock/dcc-v1.1.0.js、assets/css/dcc-v1.1.0.css（仅既有选择框宽度约束）。
- 精准删除：完整租户、供应商任务、单号批次、tel 及所提供 record/file 字段必须准确匹配已提交且有准确 fileId 的本地记录；仅同号、跨范围、歧义或未提交关联拒绝且不写请求。DCC 指令只由有效已发放租户身份定位接口来源任务；该身份不改变前台角色与管理权。
- 结果与本地保留：供应商请求和每次响应分开保存原始证据、来源、可信标志与明确 succeeded/rejected/unknown 合成语义；只有可信明确成功标记对应 supplierDeleted 并停止其降级，其他同号批次、本地记录、实际结果及原链保留。未知不归一化为拒绝/成功，待确认期间不停止按可信状态判断降级；后到冲突保留已知准确成功及全部原证据，不反向恢复供应商批次。未声称删除可撤销已执行呼叫。
- 来源分流与补送：接口来源每个独立准确删除结果生成 supplier_deletion 状态交付至后台固定 DCC 接收端。交付失败不撤销已确认删除，既有补送仅修复交付，不再次删除或导入。手工任务只在平台查看，无 DCC 删除指令及结果交付。API-006 仍 partial，真实成功判据/并发行为待核；使用显式合成结果，不编造生产码映射。
- 原链推送：仅显式 DCC 业务输入在原 supplierTaskId 下生成独立新 record/batch；UI 明确选原记录，同 lead/phone 精确继承原导入时间/北京日、initial/current priority 与 lastDecayDay，旧删除标记不传给新批。同号多线索/变手机号、旧原日期与时间矛盾/缺失、current/initial 缺确认或原链待核时保留新记录待核、暂停供应商提交，不按最新同号猜原链或借新日期补原日。lastDecayDay 未确认保持 null，后续计算待核不再次扣完整历史。没有平台重呼预算、自动恢复或定时重推。
- 页面：沿用 PAGE-002 状态与 priority 页，添加默认空的精确记录选择、四种合成删除场景、独立删除请求/原字段详情、接口任务原链显式推送和共享 DCC 状态交付；成功后仍能选原本地记录查看/明确推新批。沿用历史只读投影保护，所有新增写入口受真实 role/scope 与 readonly 守卫。
- 实现检查：语法检查与实际 VM/UI 辅助链检查完成；加载的 runtime/records/mock/CSS 缓存统一 step09a。正式领域与浏览器结果交主控 prototype-verifier，本记录不提前宣布整步通过，未进入 step-10。

## step-10：形成实际产品方案评审输入
- 日期：2026-10-10。
- 文件：product-input.json、README.md；本段为自身实现记录，不修改稳定业务 JS、冻结五视图、审批或验证状态。
- 输入：以当前已批准冻结基线的规范 JSON、77 字段映射及实际 Step04–09 源码锚点生成唯一方案输入；15 FUNC/46 AC/21 BR/2 PAGE/13 ACTION/77 FLD/4 SC/9 SEQ/10 API/2 FLOW 的 ID 与冻结关系保留，历史计划未来状态不冒充当前实现。实际文件与符号明确映射，实现已存在、写后最终内容复验仍 pending。
- 适配与来源：77 个规范字段唯一定义置于 project_facts[].fields，无顶层 fields 重复源；保留来源字段、本地合成等价键、可观察逻辑及真实契约缺口。规范化来源元数据和 SC/SEQ/API/规则/故事/风险已内嵌；source_refs 使用 product-input.json#ID，上游引用仅作 provenance，不消费 raw/Wiki/查询正文。documents=[]，不要求未来标准包根加载裸 js 或 memory 文档；实现路径是工作区元数据，未来静态树为 prototype/。
- 真实边界：API verification_status 与 business_contract_status 原样保留，real_call_allowed 全 false。来源、失败快照、每次结果、状态/priority、删除和原链显式推送为实际合成方案；待核风险保留，不宣称真实联调或供应商内部调度已确认。
- 评审状态：业务与运营均 pending_actual_confirmation、reviewer/evidence null；未生成批准、凭证、receipt、正式 05 开发包、新说明/标注或同义 PRD。README 更新本地启动、真实页面入口、01–09 已记录单步状态与最终整体验证待主控的边界，未预写 S8 完成。
- 实现检查：/private/tmp/dcc-product-check.py 在实际输入上返回 exit0、零 errors/warnings，核对全部规范集合、冻结关系、接口状态与实际源码锚点。此为结构/范围校验，不替代最终当前 digest 的领域/浏览器复验及产品人审；产物稳定后停止业务写入，交主控审计和全步门禁。

## 最终导航交付契约修正

入口统一导航脚本改用规范相对引用 js/delivery-nav.js；脚本及业务语义未改。验证日志移除唯一模板占位。当前内容重新实际验证全部十步及全局视图，原记录保留。

<!-- project-version-changes:start -->
## 当前项目版本变更（共用台账派生视图）

台账：/Users/huhaowen/Documents/038-云外呼平台/Demo_Protype_2/memory/project-versions.json

项目 alicti-c7a41f75 / 版本 v1.1.0 / 1.1.0

- CH-DCC-20261009 [analysis / accepted]: 2026-10-09用户确认业务基线替换；旧DCC演示退役，原型待重建；影响 SC-001, SC-002, SC-003, SC-004；来源 需求/1.1.0/source-index.json SRC-002～050
- CHANGE-PRODUCT-FINAL-VERIFICATION-20261010 [product / accepted]: 全部实现及实际产品输入已形成；验收状态对账后对最终内容开启独立验证轮次，历史单步证据保留且不复用。；影响 S7；来源 /Users/huhaowen/Documents/038-云外呼平台/Demo_Protype_2/prototype-v1.1.0/memory/change-log.md
- CHANGE-PRODUCT-DELIVERY-NAV-CONTRACT-20261010 [product / accepted]: 最终门禁要求统一导航脚本规范引用；修正入口query引用及日志模板残留后，对当前最终内容独立重验全部步骤。；影响 S7；来源 /Users/huhaowen/Documents/038-云外呼平台/Demo_Protype_2/prototype-v1.1.0/memory/change-log.md
- CHANGE-PRODUCT-REVIEW-DEFECTS-20261011 [product / accepted]: 用户暂不批准并继续审阅；实际复现同刻状态重放误降priority、CSV失败预览提交旧数据、未可信SIP阻断可信更新及输入切换陈旧反馈，既有范围内实现缺陷需S7修复后重新验证。；影响 S7；来源 /Users/huhaowen/Documents/038-云外呼平台/Demo_Protype_2/prototype-v1.1.0/memory/change-log.md
- CH-DCC-20261011-PRIORITY-BATCH [analysis / implemented]: 用户确认取消平台每日优先级衰减及相关每日查询，DCC按本次priority决策导入；按明确previousBatchId关联新批次，补逐行requestId重试幂等、父批次归属校验与根批次追溯。；影响 ；来源 /Users/huhaowen/Documents/Codex/2026-10-09/task/dcc-v1.1.0-reanalysis/runtime/change-impact.json
- CH-DCC-20261011-LEAD-GROUP [analysis / implemented]: 用户确认同线索仅同手机号多次导入，按租户/原供应商任务/线索编码自动归组，不要求DCC传previousBatchId；接口主批/子批标志的完整分支和缺省规则继续审阅。；影响 ；来源 /Users/huhaowen/Documents/Codex/2026-10-09/task/dcc-v1.1.0-reanalysis/runtime/change-impact.json
- CH-DCC-20261011-APPLICATION-IMPORT-UI [product / implemented]: 用户要求更新唯一原型：应用列表新增详情修改删除、简化密钥用途和技术说明、预外呼导入客户常驻；同步已确认主子批协议并修复既有缺陷，正式G3保持待审阅；影响 analysis, product, development；来源 prototype/docs/decisions.md#d-009
- CH-DCC-20261011-PROTOTYPE-REPAIR [product / implemented]: 2026-10-11 用户直接要求开始更新唯一原型并修复应用接入五项页面问题及已发现缺陷；本轮为审阅中实现，业务G3仍待确认，不生成正式产品快照；影响 S7；来源 /Users/huhaowen/Documents/038-云外呼平台/Demo_Protype_2/prototype/memory/change-log.md
- CH-DCC-20261011-RECONCILE [analysis / implemented]: 用户SRC087明确要求应用列表新增详情修改删除及简化/常驻入口，SRC088要求完整回归对齐后推进；补齐上游独立业务操作和页面场景时序事实，旧冻结包只读保留；影响 ；来源 /Users/huhaowen/Documents/Codex/2026-10-09/task/dcc-v1.1.0-reanalysis/runtime/change-impact.json
<!-- project-version-changes:end -->

## 2026-10-11 · 纠正重复原型工作目录

根据用户实际目录约定，将旧prototype完整归档，当前prototype-v1.1.0整体移为唯一prototype；逐文件哈希对照无丢失。更新根README、当前README、D-006、config/project.json及产品输入路径说明；冻结CLAUDE/S2计划、需求输入、1.0只读快照、业务JS和Mock未改。台账锁事务仅迁移工作区路径与公开入口信息，revision10、分析冻结及审批历史保留，不创建产品receipt。S7四类问题尚待修复，目录/导航复验不是全局产品通过。


## 2026-10-11 · 应用接入简化、常驻导入与已确认主子批候选实现

- 直接依据用户“开始更新原型，并修复发现的问题”的五项指令及D-008已确认批次规则，执行于唯一prototype目录；解释“修改公共”为修改功能，详见D-009。共享台账CH-DCC-20261011-APPLICATION-IMPORT-UI / CH-DCC-20261011-PROTOTYPE-REPAIR，正式分析和产品批准仍未生成。
- step-04：应用列表/新增/详情/修改/删除独立视图；密钥生成、mask/显示/复制；改名及租户修改不重置；删除精确撤销。超管与必要租户边界保留，日常UI移除技术交换演示和来源说明。
- step-05：预外呼列表/详情/导入记录工具栏常驻客户导入，DCC和手工按来源打开；旧未启动任务补导合并原客户和批次，已运行等状态保留禁用原因。CSV源文本改动即时失效预览，无效表头清旧数据，提交复核当前预览版本。
- step-05/07/09：每次新业务按本次priority和默认false的isNewBatch拆主/子；旧requestId保持原record/batch/root、有效内容冲突整请求拒绝；结果/SIP/失败/删除沿精确映射携request/root，主删除不波及子。演示再次导入明确本次priority=4，不用旧值默认继承。
- step-07：未可信SIP保留独立待核证据，不污染已确认呼叫的非SIP冲突状态；后续准确可信更新及重复去重复验。
- step-08旧每日状态查询/自然日衰减能力退出，保留旧调用的FEATURE_RETIRED反馈且无写库；旧业务记忆和图集未覆盖，不能把退役能力当旧步骤的完整通过。
- step-09：切换删除目标和样例清旧反馈，删除回执仍绑定当前精确批次。
- 本轮更新8项入口资源cache query，避免已打开浏览器沿用旧脚本；简化导航当前状态提示为“本地合成演示；本轮修改待审阅”。没有部署、真实服务、生产密钥或拨号。
- 当前只对候选修改留新鲜本地/浏览器验证；02保持S7，正式G3和02业务/运营审阅以及04新增应用操作映射待完成。只读冻结输入、五份派生事实、原S2/CLAUDE、历史快照未改，不执行正式S8/S9或05。

## 2026-10-11 · 本轮完整回归及需求／原型对齐

- 按 SRC-087／088 受控回 04 S1～S8，补齐应用独立操作与场景／时序／页面，当前 17 FUNC／62 AC／21 BR／5 SC／8 SEQ／5 PAGE／20 ACTION；CH-DCC-20261011-RECONCILE。已确认的主子批／requestId／本次 priority 规则保留，旧稳定 ID、退役对象、来源与历史包不改写。
- `js/pages/application-access.js` 纠正独立 PAGE／FUNC 标记，后台身份能力只作必要上下文，无日常 token 交换入口。
- `js/components/dcc-records.js` 修复处理中 CSV 编辑竞态：提交锁定所有编辑控件，await 后复核文本／预览／行与身份、范围、任务上下文；变化取消写入并恢复编辑，存储失败可重试。负例与 13 个 VM 案例及真实浏览器修复后结果留存。
- `flowcharts/business-process.html`、`flowcharts/sequence-interaction.html` 从当前上游原样复用 SVG，明确 G3-pending 和源摘要；`related-systems/index.html` 同步当前职责／接口边界。`js/review-view-cache.js` 与 `index.html` 只为当前三份图页补版本刷新，普通缓存入口实测已加载现行稿。
- 当前代码 23 项 hash 与 17 FUNC 实现证据绑定；1804 条领域断言、16 个应用语义案例、17 个关联交付案例，57 次核心行为布局、48 次需求主图与 12 次核心交付图页三宽观察通过。证据归档在既有 `memory/verification-evidence/`，未生成新说明、标注、原型版本目录或 05 包。
- 现行快照 `7f304bb7edec…`；新 G3 未批准。02 S7 前置检查因上游 analysis stale／unbound 未通过，正式输入／五份事实／product-input 保留历史；不把当前回归通过写成正式 S8／产品冻结。后续按 G3 → 正式导入／物化 → 02 S8 → 业务／运营评审顺序推进。
