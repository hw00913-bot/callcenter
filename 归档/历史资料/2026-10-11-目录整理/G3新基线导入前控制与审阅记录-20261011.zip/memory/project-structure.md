# 项目结构摘要

## 可编辑业务文件清单
| 路径 | 类型 | 责任 | 可编辑原因 |
| --- | --- | --- | --- |
| index.html | entry | 现有平台入口与脚本装载 | 接入本版模块、统一交付壳；保留无关页面 |
| js/alicti-storage.js | shared | local/session Storage 与 Web Locks | 本版独立命名空间，禁止继承旧版缓存 |
| js/app.js | state | 账号/租户/权限/会话 | 扩充应用管理拒绝边界时核对既有角色 |
| js/nav.js | route | 左侧业务路由与守卫 | 新增应用接入管理，租户管理员拒绝 |
| config/nav.json | delivery-config | 交付视图配置 | 本轮可选交付关闭，移除工作区旧说明入口 |
| js/pages/cloud-task-workspace.js | page | 现有创建向导、任务中心、记录页 | 承载任务来源锁定及记录页交互 |
| js/pages/cloud-call-tasks.js | page | 预外呼列表 | 接入任务级记录页入口，保留其他任务类型 |
| js/pages/cloud-call-records.js | page | 通话记录 | 按必要范围接入每次结果展示，不改无关报表 |
| js/components/platform-ui.js | component | 表格/弹层/状态/布局 | 优先复用，不无必要改变公共实现 |
| mock/data.js | data | 身份、任务、业务基础数据 | 保留既有基础场景，不篡改冻结事实 |
| js/pages/application-access.js（拟新增） | page | PAGE-001 应用管理 | 底座没有该页面，仅超管入口/页面/管理模拟接口 |
| js/components/dcc-runtime.js（拟新增） | domain | 本版导入/结果/分片/衰减/删除领域模型 | 与旧供应商适配器隔离合成边界，防止平台重呼遗留逻辑进入本版 |
| js/components/dcc-records.js（拟新增） | component | 本版任务记录UI | 隔离2151行旧工作区，复用task center入口 |
| mock/dcc-v1.1.0.js（拟新增） | fixtures | 本版正常及异常合成样例 | 旧mock不覆盖冻结SC/SEQ及未知状态 |
| assets/css/dcc-v1.1.0.css（拟新增） | style | 新增区块和页面 | 复用现有灰白蓝风格，作用域限制为本版 |
| flowcharts/business-process.html | frozen-view | 业务图集 | 仅import_analysis publish-diagrams确定性复用 |
| flowcharts/sequence-interaction.html | frozen-view | 时序图集 | 仅import_analysis publish-diagrams确定性复用 |
| related-systems/index.html | delivery-page | DCC/平台/AliCti边界展示 | 按当前记忆展示职责和真实接口缺口 |
| README.md | entry-help | 当前启动方式与状态 | 交付时更新真实进展 |

## 页面与入口
- index.html 是唯一平台宿主；js/nav.js 维护实际业务路由，config/nav.json 是交付视图配置，并非业务菜单事实。
- 预外呼列表 predictive-tasks -> cloud-task-create 创建向导 -> cloud-task-center 任务中心/记录页。IVR和呼入入口保留。
- js/pages/cloud-task-workspace.js 同时注册创建向导和任务中心，不能另造脱离既有路径的演示页。
- js/app.js 提供 AppState，RouteRuntime 根据角色/租户/菜单/动作权限拒绝访问。

## 公共组件与复用边界
- js/components/platform-ui.js、js/common.js 提供已有表格、分页、弹窗、反馈；新增能力优先调用。
- 旧 retry/repeat 模块服务既有底座；本版DCC任务不能沿用平台重导预算/计时器，需按任务来源约束调用。对无关1.0功能的改动须说明影响。
- js/alicti-storage.js 在所有业务脚本之前装载，可通过前缀同时隔离Storage和Web Locks；不得读写旧前缀数据。

## 数据与配置来源
- mock/data.js及mock/*.js：现有合成身份/租户/任务/通话；本版样例独立新增。
- config/project.json：工作区配置。config/workflow.json与config/requirement-analysis.json只由工具维护。
- inputs/requirement-analysis/ 与五份确定性事实记忆只读；通过 memory/requirement-analysis-baseline.json 和 project.md 的已验真入口按SC/SEQ读取。

## 可选交付与流程图位置
- annotations/仅基础设施，本轮未请求，不纳入业务实现/验证；禁止新标注数据。
- docs/interaction.html、本轮标注提示词/覆盖表未请求，不创建。底座复制的docs/functional-spec等仅历史，不作为当前需求、不能进入本轮主导航。
- 业务流程图 flowcharts/business-process.html、时序图 flowcharts/sequence-interaction.html 原壳待发布冻结内容，不能手绘重排。
- related-systems/index.html 必需页，已确认DCC/云呼叫中心/AliCti关系，需展示责任与合成边界。

## 不纳入实现/交付的目录
- tools/prototype-loop-orchestrator/和tools/*.py仅控制工具，不属于业务实现/验收统计。
- inputs/requirement-analysis/只读冻结副本，包内原始证据仅由脚本验真，不读取正文。
- blueprint/、references/、历史说明均不得用作重建本版业务事实。
- 原目录 ../prototype、../需求/1.0.0、../需求/1.1.0/snapshots、共享版本台账历史均不由builder修改。

## 实际扫描
- assets/css：40个实际文件。
- js/pages：26个实际文件。
- js/components：54个实际文件。
- mock：25个实际文件。
- 当前不含node_modules或构建工具；静态HTML/CSS/vanilla JS通过本地HTTP运行。
- 新文件路径为实现落点建议，S6需按真实能力确认并列清创建原因。存储隔离及旧导航退出在S7需实际验证，目录不同不代表已隔离。
