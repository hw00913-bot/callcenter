window.AnnotationData = {};
