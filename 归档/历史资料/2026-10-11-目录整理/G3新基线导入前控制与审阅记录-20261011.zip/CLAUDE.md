# 项目协作规则

## 本轮执行对象

本轮为云呼叫中心 v1.1.0 DCC 增量原型，工作区为 `/Users/huhaowen/Documents/038-云外呼平台/Demo_Protype_2/prototype-v1.1.0`。采用 HTML、CSS 和原生 JavaScript，在本地 HTTP 环境演示，不部署、不接入真实服务。产品、业务和运营评审以 1440、1920、2560 桌面宽屏为主要设备范围；沿用底座视觉和组件，只调整本轮功能涉及的行为与反馈。

上游已完成 04 G1/G2/G3 和 S9，导入的唯一业务基线为 `ra-云呼叫中心-v1.1.0-原始需求重新分析草稿-21476e056b26e8cc`；fingerprint 为 `21476e056b26e8ccfde197134151e812271da709fbde7b01119617dd5157406b`，manifest SHA-256 为 `6776cbeea861e227c9c145588848fad622c47077e9de49a5635fa32ad1e02448`。02 的计划批准必须绑定这份 manifest，不用 G3 或旧轮批准替代本轮 S2。

本轮实现范围为 15 项有效 FUNC、46 个 AC、21 条 BR、4 个 SC、9 个 SEQ 和 2 个 PAGE。任务来源选择属于既有任务列表新建向导，确认创建后锁定，记录页只读展示；应用管理仅超管。DCC 决定重导与业务计数，平台负责导入、准确关联及接口任务每次结果回传；手工任务仅平台查看。未知、冲突、重复、晚更新以及导入失败分片按冻结事实处理，不能增加平台重导、解除、额度或时段调度。

冻结 API 的 partial/missing、风险正文和供应商行为的证据限制必须保留。风险记录中的旧标题、旧批准前说明只用于追溯，不覆盖其当前职责正文和已批准门禁。Mock 使用虚构身份、客户及结果，区分导入阶段与实际呼叫阶段；界面按业务需要展示结果，不把技术核验参数变成运营设置。每次合成结果、失败补送和下载信号需可观察，不能把 Mock 成功写成真实联调成功。

底座 `/Users/huhaowen/Documents/038-云外呼平台/Demo_Protype_2/prototype`、1.0 历史快照、原供应商资料和 04 冻结输入均禁止修改。保留底座的通用能力、菜单、布局与公共组件；只在新工作区适配本轮增量。新副本不继承旧 memory、审批、验证日志、工具包或标注，浏览器存储和互斥键应在本轮实现与验收中证明隔离，不能只根据目录不同推定隔离。

S3 使用确定性 materialize 物化冻结业务事实，S6 按 FUNC/AC/PAGE/ACTION 和相关 SC/SEQ 拆分，S7 按步骤实现与验证。三份上游图集只读复用，不重算 SVG 几何；S8 留存每项 FUNC 实现证据与每个页面业务操作的 FUNC 依据，检查遗漏、重复及职责边界。业务事实差异回到 04，不在原型侧改写导入 JSON。

当前新轮没有额外说明文档或标注请求，不生成新说明文档、标注提示词或标注数据；底座目录已有的历史说明保持原位。后续明确追加交付须由请求入口记录，再按相应阶段生成。本轮也不生成报价、同义 PRD、发布站点或正式 05 开发交付包。

@memory/project.md
@memory/project-startup-plan.md
@memory/business-rules.md
@memory/feature-list.md
@memory/source-materials.md
@memory/open-items.md

## 本地运行

在项目根目录执行以下命令启动本地 HTTP 服务：

```bash
python3 -m http.server 8080
```

然后在浏览器中打开 http://localhost:8080

> 注意：本项目通过 fetch 加载 `config/nav.json`，必须通过 HTTP 服务器访问。
> 直接双击 `index.html`（file:// 协议）会导致导航菜单无法加载。

## 语法校验

```bash
# 校验所有 JS 文件语法
find . -path './tools/prototype-loop-orchestrator' -prune -o -name '*.js' -print -exec node --check {} \;
```

## Loop 阶段预检

进入下一阶段前运行对应门禁：

```bash
python3 tools/loop_run.py check . --preflight-stage s4
python3 tools/loop_run.py check . --preflight-stage s6
python3 tools/loop_run.py check . --preflight-stage s7
python3 tools/loop_run.py check . --preflight-stage s8
python3 tools/loop_run.py check . --preflight-stage s9
python3 tools/loop_run.py check . --preflight-stage final
```

预检失败时必须回到提示的阶段补齐产物，不能继续实现、标注或交付。

每个阶段完成后必须通过 `python3 tools/loop_run.py complete . --stage Sx ...` 更新 `config/workflow.json` 并追加 `memory/stage-log.md`。不要手写阶段完成或手动把阶段标记为 pass。

## 开始工作前

1. 阅读 `memory/project-startup-plan.md` 了解启动时的初始规划；S2 后该文件只读，不得回改。
2. 阅读 `memory/project.md`、`memory/business-rules.md`、`memory/feature-list.md`、`memory/source-materials.md`、`memory/field-map.md` 和 `memory/open-items.md`，这些文件是 S3 后的当前项目事实。
3. 若 `config/requirement-analysis.json` 的 mode 为 `imported`，读取 `memory/requirement-analysis-baseline.json`，并把冻结基线中的业务事实视为只读。
4. 涉及历史变更时阅读 `docs/decisions.md` 和 `memory/change-log.md`。
5. 涉及页面标注时以 `.clauderules` 为唯一规则源，并优先引用 `memory/source-materials.md` 中的来源编号和 `memory/field-map.md` 中的字段编号。
6. 先理解现有代码和逻辑；非必要不得修改既有业务板块。

## 项目执行边界

- 未完成 PM 目标、范围、核心流程、数据对象和交付目标确认前，不进入实现。
- S1 未写入 `memory/project-startup-plan.md` 前，不进入 S2；S2 后不得修改该文件，只能作为溯源读取。
- S2 未写入本文件的项目级执行规则前，不进入 S3。
- S3 未初始化项目记忆、业务规则、功能清单、资料记录、字段映射和开放问题前，不进入拆分或实现。
- 实现必须以 `memory/project.md`、`memory/business-rules.md`、`memory/feature-list.md`、`memory/source-materials.md`、`memory/field-map.md` 和 `docs/decisions.md` 为准。
- 已导入需求分析基线时，不得在原型 Loop 内改写其范围、规则、功能、接口结论或图形几何；业务变化必须回到需求分析 Loop 重新冻结。
- 冻结输入不止功能清单：还包括基础确认事实、业务流程/泳道、交互时序及其 SC/SEQ 明细、接口核验和页面规划。按当前步骤从已验证入口读取，将时序与分支落实到页面状态、Mock 和验收；不能只发布图页。
- LLM Wiki 只由需求分析 Loop 消费。原型不查询知识库、不读取 query/loop-context 正文；新 Wiki 材料先回上游分析。包内原始证据仅供脚本校验完整性，来源元数据只用于追溯。
- 如果启动规划、资料和项目记忆之间冲突，先回到需求确认或记录 open item，不直接实现。

## 修改约束

- 本项目是无构建步骤的静态前端原型，入口为 `index.html`。
- 可复用 B 端公共组件放入 `js/components/`，页面逻辑放入 `js/pages/`。
- 修改业务规则后同步更新 `memory/business-rules.md`（该文件已被 CLAUDE.md 自动加载）。
- 功能范围和说明必须与 `memory/feature-list.md` 中的 `FUNC-*` 一致；原型页和操作保留上游 ID。
- 新增或使用外部资料后同步更新 `memory/source-materials.md`。
- 涉及 API 字段、参考项目字段、枚举、表格列、筛选项或详情字段时，同步更新 `memory/field-map.md`。
- 未确认的问题写入 `memory/open-items.md`（该文件已被 CLAUDE.md 自动加载）。
- JS 修改后执行语法检查；资源路径修改后进行浏览器验证。
- 进入实现、全局验证、标注和交付前必须通过对应 `tools/loop_run.py check` 阶段预检。
- 阶段完成后使用 `tools/loop_run.py complete` 更新阶段状态，不能只在对话上下文中说明。
- 验证失败和熔断计数必须写入 `memory/circuit-state.json`，不能只写在对话上下文里。

## 安全规则 (Safety Rules)

- **数据与逻辑分离**：所有大型 B 端数据集和 Mock 表格必须存放在 `mock/data.js` 中。严禁在 `js/pages/` 内部硬编码原始数据表。
- **配置文件架构分离**：CLAUDE.md 严格限定于本地开发/校验命令（运行、测试、语法检查等），而 `.clauderules` 专门用于页面标注系统的安装、维护和运行时规则。
