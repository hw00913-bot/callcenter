# LOCAL-FIELD-SAVE 独立保存字段及通用条件

**READY_FOR_ENGINEERING_DESIGN — 产品可交接，工程设计需补齐**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [保存接口车系及通用取数字段配置 · FUNC\-029](../features/FUNC-029.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-029

触发：有权管理员在自定义字段编辑器保存字段

## 前置条件

- 当前账号、企业/租户/对象和处理阶段有对应权限；输入来自本局部声明的当前对象。
- 沿当前已确认范围执行；不借原型或历史ID扩张权限。

## 必须遵守的全局规则

- [BR-026](../global-logic.md#BR-026)
- [BR-030](../global-logic.md#BR-030)
- [BR-034](../global-logic.md#BR-034)
- [BR-035](../global-logic.md#BR-035)

## 输入与输出

输入：[FIELD-DEFINITION-ID](../field-specs.md#FIELD-DEFINITION-ID)、[FIELD-DEFINITION-LABEL](../field-specs.md#FIELD-DEFINITION-LABEL)、[FIELD-DEFINITION-TYPE](../field-specs.md#FIELD-DEFINITION-TYPE)、[FIELD-DICTIONARY-REF](../field-specs.md#FIELD-DICTIONARY-REF)、[FIELD-USE-UPSTREAM](../field-specs.md#FIELD-USE-UPSTREAM)、[FIELD-UPSTREAM-ID](../field-specs.md#FIELD-UPSTREAM-ID)、[FIELD-UPSTREAM-PROPERTY](../field-specs.md#FIELD-UPSTREAM-PROPERTY)、[FIELD-DOWNSTREAM-PARAM](../field-specs.md#FIELD-DOWNSTREAM-PARAM)、[FIELD-QUERY-REQUIRED](../field-specs.md#FIELD-QUERY-REQUIRED)、[FIELD-DEFINITION-ENABLED](../field-specs.md#FIELD-DEFINITION-ENABLED)

输出：[FIELD-DEFINITION](../field-specs.md#FIELD-DEFINITION)、[FIELD-DEFINITION-ID](../field-specs.md#FIELD-DEFINITION-ID)、[FIELD-DEPENDENCY-SUMMARY](../field-specs.md#FIELD-DEPENDENCY-SUMMARY)、[FIELD-DEFINITION-ENABLED](../field-specs.md#FIELD-DEFINITION-ENABLED)

## 处理步骤

### LOCAL-FIELD-SAVE-STEP-1

选择原填写方式或接口取数；本次车系绑定Mapping且无上游

读取：FIELD-DEFINITION-LABEL, FIELD-DEFINITION-TYPE, FIELD-DICTIONARY-REF, FIELD-USE-UPSTREAM；写入：无

规则：BR-026, BR-030, BR-034, BR-035

### LOCAL-FIELD-SAVE-STEP-2

普通接口开启条件时配置一个上游、声明属性、支持参数和必需性

读取：FIELD-USE-UPSTREAM, FIELD-UPSTREAM-ID, FIELD-UPSTREAM-PROPERTY, FIELD-DOWNSTREAM-PARAM, FIELD-QUERY-REQUIRED；写入：无

规则：BR-026, BR-030, BR-034, BR-035

### LOCAL-FIELD-SAVE-STEP-3

校验来源授权、类型/属性/参数、定义及无环链，再独立保存字段库并重绘依赖概览

读取：FIELD-DEFINITION-ID, FIELD-DEFINITION-LABEL, FIELD-DEFINITION-TYPE, FIELD-DICTIONARY-REF, FIELD-USE-UPSTREAM, FIELD-UPSTREAM-ID, FIELD-UPSTREAM-PROPERTY, FIELD-DOWNSTREAM-PARAM, FIELD-QUERY-REQUIRED, FIELD-DEFINITION-ENABLED；写入：FIELD-DEFINITION, FIELD-DEFINITION-ID, FIELD-DEPENDENCY-SUMMARY, FIELD-DEFINITION-ENABLED

规则：BR-026, BR-030, BR-034, BR-035

## 分支与异常

### LOCAL-FIELD-SAVE-BRANCH-1

条件：本次意向车系

结果：固定唯一单选接口及无上游，原门店文本仍普通字段

涉及字段：FIELD-DEFINITION-TYPE, FIELD-DICTIONARY-REF, FIELD-USE-UPSTREAM

验证：CHECK-109

### LOCAL-FIELD-SAVE-BRANCH-2

条件：条件关闭

结果：不要求映射，不触发下游取数参数

涉及字段：FIELD-USE-UPSTREAM

验证：CHECK-110, CHECK-125

### LOCAL-FIELD-SAVE-BRANCH-3

条件：自身/循环/缺定义/不支持参数或类型不兼容

结果：拒绝保存并指出配置项，不静默删参或转换旧配置

涉及字段：FIELD-UPSTREAM-ID, FIELD-UPSTREAM-PROPERTY, FIELD-DOWNSTREAM-PARAM

验证：CHECK-110, CHECK-124

### LOCAL-FIELD-SAVE-BRANCH-4

条件：保存字段但未保存分类

结果：只完成字段入库，不自动加入分类或改变客服当前通话

涉及字段：FIELD-DEFINITION

验证：CHECK-109, CHECK-133

## 完成后的状态

- 仅本次动作的合法结果生效；取消或核对/保存异常保留原对象与输入，不宣称成功。

## 字段定义

- [FIELD-DEFINITION](../field-specs.md#FIELD-DEFINITION)
- [FIELD-DEFINITION-ID](../field-specs.md#FIELD-DEFINITION-ID)
- [FIELD-DEFINITION-LABEL](../field-specs.md#FIELD-DEFINITION-LABEL)
- [FIELD-DEFINITION-TYPE](../field-specs.md#FIELD-DEFINITION-TYPE)
- [FIELD-DEPENDENCY-SUMMARY](../field-specs.md#FIELD-DEPENDENCY-SUMMARY)
- [FIELD-DICTIONARY-REF](../field-specs.md#FIELD-DICTIONARY-REF)
- [FIELD-DOWNSTREAM-PARAM](../field-specs.md#FIELD-DOWNSTREAM-PARAM)
- [FIELD-QUERY-REQUIRED](../field-specs.md#FIELD-QUERY-REQUIRED)
- [FIELD-UPSTREAM-ID](../field-specs.md#FIELD-UPSTREAM-ID)
- [FIELD-UPSTREAM-PROPERTY](../field-specs.md#FIELD-UPSTREAM-PROPERTY)
- [FIELD-USE-UPSTREAM](../field-specs.md#FIELD-USE-UPSTREAM)
- [FIELD-DEFINITION-ENABLED](../field-specs.md#FIELD-DEFINITION-ENABLED)

## 来源与验证

来源条目：acceptance:AC-108, acceptance:AC-109, acceptance:AC-110, acceptance:AC-111, acceptance:AC-124, acceptance:AC-125, acceptance:AC-133, acceptance:AC-134, documents:outputs~1menu-and-page-planning-reference.md, documents:outputs~1page-structure-atlas.html, documents:planning~1page-index.json, features:FUNC-029, features:FUNC-029/boundary/business_rules/0, features:FUNC-029/boundary/business_rules/1, features:FUNC-029/boundary/business_rules/2, features:FUNC-029/boundary/business_rules/3, features:FUNC-029/boundary/exception_paths/0, features:FUNC-029/boundary/exception_paths/1, flows:FLOW-005, flows:FLOW-005/steps/0, flows:FLOW-005/steps/1, flows:FLOW-005/steps/2, flows:FLOW-005/steps/3, flows:FLOW-005/steps/4, interfaces:API-017, interfaces:API-018, pages:PAGE-007, pages:PAGE-007/actions/0, pages:PAGE-007/actions/1, pages:PAGE-007/actions/2, pages:PAGE-007/fields/0, pages:PAGE-007/fields/1, pages:PAGE-007/fields/10, pages:PAGE-007/fields/11, pages:PAGE-007/fields/2, pages:PAGE-007/fields/3, pages:PAGE-007/fields/4, pages:PAGE-007/fields/5, pages:PAGE-007/fields/6, pages:PAGE-007/fields/7, pages:PAGE-007/fields/8, pages:PAGE-007/fields/9, rules:BR-026, rules:BR-030, rules:BR-034, rules:BR-035, scenarios:SC-012, scenarios:SC-012/alternate_flows/0, scenarios:SC-012/alternate_flows/0/steps/0, scenarios:SC-012/alternate_flows/1, scenarios:SC-012/alternate_flows/1/steps/0, scenarios:SC-012/alternate_flows/1/steps/1, scenarios:SC-012/alternate_flows/1/steps/2, scenarios:SC-012/alternate_flows/2, scenarios:SC-012/alternate_flows/2/steps/0, scenarios:SC-012/alternate_flows/2/steps/1, scenarios:SC-012/main_flow/0, scenarios:SC-012/main_flow/1, scenarios:SC-012/main_flow/2, scenarios:SC-012/main_flow/3, scenarios:SC-012/main_flow/4, scenarios:SC-012/main_flow/5, scenarios:SC-012/postconditions/0, scenarios:SC-012/postconditions/1, scenarios:SC-012/postconditions/2, scenarios:SC-012/preconditions/0, scenarios:SC-012/preconditions/1, sequences:SEQ-014, sequences:SEQ-014/messages/0, sequences:SEQ-014/messages/1, sequences:SEQ-014/messages/10, sequences:SEQ-014/messages/11, sequences:SEQ-014/messages/12, sequences:SEQ-014/messages/13, sequences:SEQ-014/messages/14, sequences:SEQ-014/messages/15, sequences:SEQ-014/messages/16, sequences:SEQ-014/messages/17, sequences:SEQ-014/messages/18, sequences:SEQ-014/messages/19, sequences:SEQ-014/messages/2, sequences:SEQ-014/messages/20, sequences:SEQ-014/messages/21, sequences:SEQ-014/messages/22, sequences:SEQ-014/messages/23, sequences:SEQ-014/messages/24, sequences:SEQ-014/messages/25, sequences:SEQ-014/messages/26, sequences:SEQ-014/messages/27, sequences:SEQ-014/messages/28, sequences:SEQ-014/messages/3, sequences:SEQ-014/messages/4, sequences:SEQ-014/messages/5, sequences:SEQ-014/messages/6, sequences:SEQ-014/messages/7, sequences:SEQ-014/messages/8, sequences:SEQ-014/messages/9, stories:US-015, stories:US-015/preconditions/0, stories:US-016, stories:US-016/preconditions/0

验证：CHECK-109, CHECK-110, CHECK-124, CHECK-125, CHECK-133, CHECK-108, CHECK-111, CHECK-134, CHECK-FIELD-LIFECYCLE

## 实施任务

未声明；请结合范围说明核对。
