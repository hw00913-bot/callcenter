# 删除自定义字段并保留通话快照 · FUNC\-032

**READY\_FOR\_ENGINEERING\_DESIGN — 产品可交接，工程设计需补齐**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

具备本租户业务配置权限的管理员可发起并确认删除当前字段库定义；六个统计预置字段及Mapping预置字段也适用，不按预置身份禁止。历史已经保存字段值不影响删除；仍存在的定义保持原类型/选项约束。 成功只移除该字段库定义，历史按保存时名称、类型、选项和值独立展示，当前通话及话后沿开始版继续保存，独立分类归档不变；不连删分类/接口，不自动补回默认字段，其他租户不受影响。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md) — 共用页面，另有 2 个功能

## 局部逻辑

- [删除当前字段库定义并保留通话快照 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：有本租户业务配置权限的人员删除字段定义

- 当前账号、企业/租户/对象和处理阶段有对应权限；输入来自本局部声明的当前对象。
- 沿当前已确认范围执行；不借原型或历史ID扩张权限。

### 处理步骤

1. **LOCAL\-FIELD\-DELETE\-STEP\-1**：点击删除时核对当前分类引用（含隐藏/停用）及其他当前字段的直接查询依赖；可选条件仍是配置引用，历史及完整本通/归档快照只作保留影响。

2. **LOCAL\-FIELD\-DELETE\-STEP\-2**：确认时重查目标、权限、配置版本及当前引用；历史已填值不阻挡，移除当前字段库定义。

3. **LOCAL\-FIELD\-DELETE\-STEP\-3**：历史详情按当时快照显示，本通/话后按开始版保存，归档独立定义不变；刷新不补默认。

### 分支与异常

- **LOCAL\-FIELD\-DELETE\-BRANCH\-1**：当当前分类/其他字段直接引用存在或必要依据无法核对，仅列当前需要解除的分类或字段名称，并提供去修改分类/字段入口；不列历史编号。先核对同一弹层请求、身份/租户及引用仍存在，再打开正确对象；修改需另行保存，旧入口或引用变化不误开对象。。

- **LOCAL\-FIELD\-DELETE\-BRANCH\-2**：当普通/预置字段已有完整通话或归档快照且当前配置引用已解除，仍允许删除字段库定义，保留当时名称、类型、选项和值供历史/本通继续。。

- **LOCAL\-FIELD\-DELETE\-BRANCH\-3**：当取消、当前配置引用/身份版本变化或读写异常，保留原定义及草稿；仅完整快照新增或变化不使确认过期。。

### 完成后的状态

- 仅本次动作的合法结果生效；取消或核对/保存异常保留原对象与输入，不宣称成功。

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [通话及业务对象上下文 · FIELD\-CALL\-CONTEXT](../field-specs.md#FIELD-CALL-CONTEXT)；依据：[删除当前字段库定义并保留通话快照 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [已删除分类保留定义 · FIELD\-CATEGORY\-ARCHIVE](../field-specs.md#FIELD-CATEGORY-ARCHIVE)；依据：[删除当前字段库定义并保留通话快照 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [分类字段引用集合 · FIELD\-CLASS\-FIELD\-REFS](../field-specs.md#FIELD-CLASS-FIELD-REFS)；依据：[删除当前字段库定义并保留通话快照 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [字段定义整体 · FIELD\-DEFINITION](../field-specs.md#FIELD-DEFINITION)；依据：[删除当前字段库定义并保留通话快照 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [自定义字段稳定标识 · FIELD\-DEFINITION\-ID](../field-specs.md#FIELD-DEFINITION-ID)；依据：[删除当前字段库定义并保留通话快照 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [业务分类识别与配置 · FIELD\-CATEGORY\-DEFINITION](../field-specs.md#FIELD-CATEGORY-DEFINITION)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [分类字段顺序 · FIELD\-CLASS\-ORDER](../field-specs.md#FIELD-CLASS-ORDER)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [分类字段是否必填 · FIELD\-CLASS\-REQUIRED](../field-specs.md#FIELD-CLASS-REQUIRED)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [分类字段是否显示 · FIELD\-CLASS\-VISIBLE](../field-specs.md#FIELD-CLASS-VISIBLE)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [字段名称 · FIELD\-DEFINITION\-LABEL](../field-specs.md#FIELD-DEFINITION-LABEL)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [填写方式 · FIELD\-DEFINITION\-TYPE](../field-specs.md#FIELD-DEFINITION-TYPE)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [上游依赖展示 · FIELD\-DEPENDENCY\-SUMMARY](../field-specs.md#FIELD-DEPENDENCY-SUMMARY)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [字段取数接口引用 · FIELD\-DICTIONARY\-REF](../field-specs.md#FIELD-DICTIONARY-REF)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [下游入参字段名 · FIELD\-DOWNSTREAM\-PARAM](../field-specs.md#FIELD-DOWNSTREAM-PARAM)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [查询条件是否必需 · FIELD\-QUERY\-REQUIRED](../field-specs.md#FIELD-QUERY-REQUIRED)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [上游字段 · FIELD\-UPSTREAM\-ID](../field-specs.md#FIELD-UPSTREAM-ID)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [上游取值属性 · FIELD\-UPSTREAM\-PROPERTY](../field-specs.md#FIELD-UPSTREAM-PROPERTY)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [是否使用其他字段作为条件 · FIELD\-USE\-UPSTREAM](../field-specs.md#FIELD-USE-UPSTREAM)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [字段库启用状态 · FIELD\-DEFINITION\-ENABLED](../field-specs.md#FIELD-DEFINITION-ENABLED)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

## 本功能验收

- **AC\-143**：具备本租户业务配置权限的管理员可发起并确认删除当前字段库定义；六个统计预置字段及Mapping预置字段也适用，不按预置身份禁止。历史已经保存字段值不影响删除；仍存在的定义保持原类型/选项约束。

- **AC\-144**：自定义字段删除只核对当前业务分类引用（含隐藏/停用）及其他当前字段的直接依赖；历史已保存字段值、独立归档定义和完整本通/话后字段快照只作保留影响，不阻止删除字段库定义。删除不改写快照、业务数据或草稿；本通继续按开始版保存，后续通话按新配置。权限/目标版本、当前引用或必要快照无法可靠核对、提交失败仍保留原对象，不自动补默认。取数接口的实时资格与来源保留规则不变。

- **AC\-145**：字段删除提交前重新核对租户、成员权限、目标配置版本及当前分类/依赖引用。取消、并发新增当前引用、核对失败或保存失败保留原定义/草稿；仅新增或更新完整通话快照不使删除确认失效，不清业务数据、不改本通版本或历史快照。

- **AC\-146**：成功只移除该字段库定义，历史按保存时名称、类型、选项和值独立展示，当前通话及话后沿开始版继续保存，独立分类归档不变；不连删分类/接口，不自动补回默认字段，其他租户不受影响。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-032。产品：云外呼平台 v1\.1\.1 业务数据接口字典与字段取数联动 / 1\.1\.1。

来源类型：analysis；来源指纹：06ff20c0417423ef883d38c2ea13ade0cef280e7d0d2cc08c26587440970627a。

- memory/feature\-list\.json\#FUNC\-032

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
