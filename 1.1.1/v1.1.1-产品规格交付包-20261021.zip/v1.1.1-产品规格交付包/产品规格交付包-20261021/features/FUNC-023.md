# 新增业务数据接口条目 · FUNC\-023

**READY\_FOR\_ENGINEERING\_DESIGN — 产品可交接，工程设计需补齐**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

超管用自定义名称、预置取数能力、可用租户和启用状态建立接口条目，系统生成稳定内部标识，供授权租户字段引用。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [取数接口字典 · UI\-PAGE\-006](../ui-pages/UI-PAGE-006.md) — 共用页面，另有 6 个功能

## 局部逻辑

- [新增取数接口条目 · LOCAL\-DICT\-CREATE](../local-logic/LOCAL-DICT-CREATE.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：超管点击新增并提交四项配置

- 当前账号、企业/租户/对象和处理阶段有对应权限；输入来自本局部声明的当前对象。
- 沿当前已确认范围执行；不借原型或历史ID扩张权限。

### 处理步骤

1. **LOCAL\-DICT\-CREATE\-STEP\-1**：选择预置能力并填写可读名称、租户范围与启停状态

2. **LOCAL\-DICT\-CREATE\-STEP\-2**：校验名称及已接入能力、租户集合，生成稳定标识并保存四项配置

3. **LOCAL\-DICT\-CREATE\-STEP\-3**：仅在保存成功后加入字典列表，使用仍受启停与授权约束

### 分支与异常

- **LOCAL\-DICT\-CREATE\-BRANCH\-1**：当空白/超长/全局重名或能力租户无效，原表单说明问题，不创建条目。

- **LOCAL\-DICT\-CREATE\-BRANCH\-2**：当同一能力使用不同名称，允许创建独立条目，不共享其后授权或启停结果。

- **LOCAL\-DICT\-CREATE\-BRANCH\-3**：当取消或保存异常，保留原字典和当前输入，不显示新增成功。

### 完成后的状态

- 仅本次动作的合法结果生效；取消或核对/保存异常保留原对象与输入，不宣称成功。

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [取数能力 · FIELD\-CAPABILITY](../field-specs.md#FIELD-CAPABILITY)；依据：[新增取数接口条目 · LOCAL\-DICT\-CREATE](../local-logic/LOCAL-DICT-CREATE.md)

- [接口启用状态 · FIELD\-DICT\-ENABLED](../field-specs.md#FIELD-DICT-ENABLED)；依据：[新增取数接口条目 · LOCAL\-DICT\-CREATE](../local-logic/LOCAL-DICT-CREATE.md)

- [取数接口条目标识 · FIELD\-DICT\-ID](../field-specs.md#FIELD-DICT-ID)；依据：[新增取数接口条目 · LOCAL\-DICT\-CREATE](../local-logic/LOCAL-DICT-CREATE.md)

- [接口名称 · FIELD\-DICT\-NAME](../field-specs.md#FIELD-DICT-NAME)；依据：[新增取数接口条目 · LOCAL\-DICT\-CREATE](../local-logic/LOCAL-DICT-CREATE.md)

- [可用租户集合 · FIELD\-TENANT\-GRANTS](../field-specs.md#FIELD-TENANT-GRANTS)；依据：[新增取数接口条目 · LOCAL\-DICT\-CREATE](../local-logic/LOCAL-DICT-CREATE.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [通话及业务对象上下文 · FIELD\-CALL\-CONTEXT](../field-specs.md#FIELD-CALL-CONTEXT)；依据：[取数接口字典 · UI\-PAGE\-006](../ui-pages/UI-PAGE-006.md)

- [已删除分类保留定义 · FIELD\-CATEGORY\-ARCHIVE](../field-specs.md#FIELD-CATEGORY-ARCHIVE)；依据：[取数接口字典 · UI\-PAGE\-006](../ui-pages/UI-PAGE-006.md)

- [字段定义整体 · FIELD\-DEFINITION](../field-specs.md#FIELD-DEFINITION)；依据：[取数接口字典 · UI\-PAGE\-006](../ui-pages/UI-PAGE-006.md)

## 本功能验收

- **AC\-105**：平台提供可供字段引用的业务数据接口字典；超管仅配置接口名称、取数能力、可用租户、启用状态。名称可自定义，取数能力从研发预置的可用能力中选择；条目内部标识由系统自动生成，无需手工填写。 名称必填、去首尾空格后最多60字、全局不重名且英文不区分大小写；同一能力允许多个独立条目。

- **AC\-106**：取数接口字典在“客户管理→业务分类”第三Tab，由超管统一维护全局条目及可用租户；租户管理员只见原业务分类/自定义字段维护，仍能选择已授权接口，不获得字典维护或跨租户权限。

- **AC\-127**：超管填写名称、选择预置取数能力、勾选可用租户并设置启停状态后，能够保存新的字典条目；使用受启停与租户授权约束。接口地址、请求方式、鉴权、请求参数及返回字段映射由研发预置，新增尚未接入的能力需先由研发接入。 名称长度及重名校验失败不得保存；同一能力的不同条目独立维护名称、租户授权和状态。

- **AC\-131**：已被字段配置引用的接口字典条目保留；编辑、启停或租户授权调整不自动删除条目、原引用配置和历史已保存数据。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-023。产品：云外呼平台 v1\.1\.1 业务数据接口字典与字段取数联动 / 1\.1\.1。

来源类型：analysis；来源指纹：923aae4c88f95eb803ba79f89afa043755adfc82a01a706894c286491c7857ff。

- memory/feature\-list\.json\#FUNC\-023

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
