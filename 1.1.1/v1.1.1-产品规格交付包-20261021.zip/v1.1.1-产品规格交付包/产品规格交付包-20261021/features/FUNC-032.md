# 删除未使用自定义字段 · FUNC\-032

**READY\_FOR\_ENGINEERING\_DESIGN — 产品可交接，工程设计需补齐**

[返回功能目录](README.md) · [返回开发包入口](../README.md)

## 本功能做什么

具备本租户业务配置权限的管理员可发起并确认删除未使用字段；六个统计预置字段及Mapping预置字段也适用，不按预置身份一刀切禁止。仍存在的定义继续保持既有类型/选项和接口单选等约束。 使用引用阻止并说明位置，成功仅移除目标且刷新不补回。

来源业务域：未提供；来源业务模块：未提供。

本页是同一份规划的功能阅读视图，仅整理已声明的关联，不增加业务规则，也不代表本功能已通过完整性核验。

## 推荐阅读顺序

1. 看下面的相关页面，确认用户从哪里进入。
2. 阅读局部逻辑，再按需打开字段定义。
3. 对照本功能验收，查看实施任务及其前置依赖。

[全局逻辑](../global-logic.md)和[通用 UI 规范](../ui-spec.md)供核对共同规则；无需每次从头通读。

## 相关页面

- [业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md) — 共用页面，另有 2 个功能

## 局部逻辑

- [删除本租户未使用字段 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

本局部说明只声明关联当前功能，以下内容直接取自同一份规划。

### 触发与前置条件

触发：有本租户业务配置权限的人员删除字段定义

- 当前账号、企业/租户/对象和处理阶段有对应权限；输入来自本局部声明的当前对象。
- 沿当前已确认范围执行；不借原型或历史ID扩张权限。

### 处理步骤

1. **LOCAL\-FIELD\-DELETE\-STEP\-1**：读取真实分类/依赖/归档/业务值及当前草稿引用，不按预置身份或整版库存一刀切

2. **LOCAL\-FIELD\-DELETE\-STEP\-2**：确认时重查对象、权限及引用，未用时仅删本字段

3. **LOCAL\-FIELD\-DELETE\-STEP\-3**：保留其他字段/分类/接口和旧通话定义，刷新不补默认

### 分支与异常

- **LOCAL\-FIELD\-DELETE\-BRANCH\-1**：当实际使用或无法核对，说明位置并阻止物理删除。

- **LOCAL\-FIELD\-DELETE\-BRANCH\-2**：当未使用的统计或Mapping预置字段，同样可删，仍存预置定义继续原类型选项保护。

- **LOCAL\-FIELD\-DELETE\-BRANCH\-3**：当取消/并发/权限/读写异常，原字段与草稿保留，不升级当前通话。

### 完成后的状态

- 仅本次动作的合法结果生效；取消或核对/保存异常保留原对象与输入，不宣称成功。

## 本功能明确关联的字段

这些关系来自已声明的页面／局部说明；字段仍可能被其他功能复用。

- [通话及业务对象上下文 · FIELD\-CALL\-CONTEXT](../field-specs.md#FIELD-CALL-CONTEXT)；依据：[删除本租户未使用字段 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [已删除分类保留定义 · FIELD\-CATEGORY\-ARCHIVE](../field-specs.md#FIELD-CATEGORY-ARCHIVE)；依据：[删除本租户未使用字段 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [分类字段引用集合 · FIELD\-CLASS\-FIELD\-REFS](../field-specs.md#FIELD-CLASS-FIELD-REFS)；依据：[删除本租户未使用字段 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [字段定义整体 · FIELD\-DEFINITION](../field-specs.md#FIELD-DEFINITION)；依据：[删除本租户未使用字段 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

- [自定义字段稳定标识 · FIELD\-DEFINITION\-ID](../field-specs.md#FIELD-DEFINITION-ID)；依据：[删除本租户未使用字段 · LOCAL\-FIELD\-DELETE](../local-logic/LOCAL-FIELD-DELETE.md)

## 共用说明中的字段上下文

以下字段来自共用页面、局部说明或任务，用于定位上下文；不等于本功能都需要实现。

- [业务分类识别与配置 · FIELD\-CATEGORY\-DEFINITION](../field-specs.md#FIELD-CATEGORY-DEFINITION)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [分类字段顺序 · FIELD\-CLASS\-ORDER](../field-specs.md#FIELD-CLASS-ORDER)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [分类字段是否必填 · FIELD\-CLASS\-REQUIRED](../field-specs.md#FIELD-CLASS-REQUIRED)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [分类字段是否显示 · FIELD\-CLASS\-VISIBLE](../field-specs.md#FIELD-CLASS-VISIBLE)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [字段名称 · FIELD\-DEFINITION\-LABEL](../field-specs.md#FIELD-DEFINITION-LABEL)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [填写方式 · FIELD\-DEFINITION\-TYPE](../field-specs.md#FIELD-DEFINITION-TYPE)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [上游依赖展示 · FIELD\-DEPENDENCY\-SUMMARY](../field-specs.md#FIELD-DEPENDENCY-SUMMARY)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [字段取数接口引用 · FIELD\-DICTIONARY\-REF](../field-specs.md#FIELD-DICTIONARY-REF)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [下游入参字段名 · FIELD\-DOWNSTREAM\-PARAM](../field-specs.md#FIELD-DOWNSTREAM-PARAM)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [查询条件是否必需 · FIELD\-QUERY\-REQUIRED](../field-specs.md#FIELD-QUERY-REQUIRED)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [上游字段 · FIELD\-UPSTREAM\-ID](../field-specs.md#FIELD-UPSTREAM-ID)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [上游取值属性 · FIELD\-UPSTREAM\-PROPERTY](../field-specs.md#FIELD-UPSTREAM-PROPERTY)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

- [是否使用其他字段作为条件 · FIELD\-USE\-UPSTREAM](../field-specs.md#FIELD-USE-UPSTREAM)；依据：[业务分类与字段配置 · UI\-PAGE\-007](../ui-pages/UI-PAGE-007.md)

## 本功能验收

- **AC\-143**：具备本租户业务配置权限的管理员可发起并确认删除未使用字段；六个统计预置字段及Mapping预置字段也适用，不按预置身份一刀切禁止。仍存在的定义继续保持既有类型/选项和接口单选等约束。

- **AC\-144**：本租户任一分类引用（含隐藏/停用引用）、其他接口字段依赖，或实际业务数据/当前通话实际使用及非空草稿引用该字段时，拒绝删除并列出位置。整版通话快照中未被实际类别使用的字段库存不单独算字段使用；真实演示业务记录也算使用，并明确标识演示记录。

- **AC\-145**：删除提交前再次核对租户、成员权限和引用；取消、并发新增引用、引用读取无法确认或保存失败时保持原定义/其他草稿，不删除业务数据、不改写通话版本和历史快照。

- **AC\-146**：成功只删除该未使用字段定义，不连删分类或接口；持久空字段库或缺少预置ID均不得触发默认补回，重新进入/刷新仍保持删除结果，其他租户和已有通话继续按原版本处理。

## 实施任务

本产品阶段阅读版不展示实施任务。开发接手后需核对工程方案与任务拆分，具体见[开发补充清单](../developer-supplement.md)。

## 来源与范围边界

本页仅整理本次范围内的 FUNC\-032。产品：云外呼平台 v1\.1\.1 业务数据接口字典与字段取数联动 / 1\.1\.1。

来源类型：analysis；来源指纹：923aae4c88f95eb803ba79f89afa043755adfc82a01a706894c286491c7857ff。

- memory/feature\-list\.json\#FUNC\-032

涉及来源变化、规则冲突或缺失时，回到产品事实和规划修订；[覆盖核对](../completeness-matrix.md)保留逐项追踪依据。
