# LOCAL-TENANT-GRANT 开放租户使用范围

**READY_FOR_ENGINEERING_DESIGN — 产品可交接，工程设计需补齐**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [开放接口条目的租户使用范围 · FUNC\-027](../features/FUNC-027.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-027

触发：超管保存租户集合并新增部分租户

## 前置条件

- 当前账号、企业/租户/对象和处理阶段有对应权限；输入来自本局部声明的当前对象。
- 沿当前已确认范围执行；不借原型或历史ID扩张权限。

## 必须遵守的全局规则

- [BR-024](../global-logic.md#BR-024)
- [BR-034](../global-logic.md#BR-034)

## 输入与输出

输入：[FIELD-DICT-ID](../field-specs.md#FIELD-DICT-ID)、[FIELD-TENANT-GRANTS](../field-specs.md#FIELD-TENANT-GRANTS)、[FIELD-DICT-ENABLED](../field-specs.md#FIELD-DICT-ENABLED)

输出：[FIELD-TENANT-GRANTS](../field-specs.md#FIELD-TENANT-GRANTS)

## 处理步骤

### LOCAL-TENANT-GRANT-STEP-1

计算目标集合相对原集合的新增授权

读取：FIELD-DICT-ID, FIELD-TENANT-GRANTS；写入：无

规则：BR-024, BR-034

### LOCAL-TENANT-GRANT-STEP-2

保存授权，仅在条目启用且成员/对象有权时允许新增引用或查询

读取：FIELD-DICT-ID, FIELD-TENANT-GRANTS, FIELD-DICT-ENABLED；写入：FIELD-TENANT-GRANTS

规则：BR-024, BR-034

## 分支与异常

### LOCAL-TENANT-GRANT-BRANCH-1

条件：未选租户或条目停用

结果：不产生新查询资格

涉及字段：FIELD-TENANT-GRANTS, FIELD-DICT-ENABLED

验证：CHECK-107, CHECK-108

### LOCAL-TENANT-GRANT-BRANCH-2

条件：并发变更/权限或保存异常

结果：保留原集合及输入，不扩大其他条目范围

涉及字段：FIELD-TENANT-GRANTS

验证：CHECK-107, CHECK-AUTH

## 完成后的状态

- 仅本次动作的合法结果生效；取消或核对/保存异常保留原对象与输入，不宣称成功。

## 字段定义

- [FIELD-DICT-ENABLED](../field-specs.md#FIELD-DICT-ENABLED)
- [FIELD-DICT-ID](../field-specs.md#FIELD-DICT-ID)
- [FIELD-TENANT-GRANTS](../field-specs.md#FIELD-TENANT-GRANTS)

## 来源与验证

来源条目：features:FUNC-027, features:FUNC-027/boundary/business_rules/0, features:FUNC-027/boundary/business_rules/1, features:FUNC-027/boundary/exception_paths/0, flows:FLOW-005, flows:FLOW-005/steps/0, flows:FLOW-005/steps/1, flows:FLOW-005/steps/2, flows:FLOW-005/steps/3, flows:FLOW-005/steps/4, interfaces:API-017, pages:PAGE-006, pages:PAGE-006/actions/0, pages:PAGE-006/actions/1, pages:PAGE-006/actions/2, pages:PAGE-006/actions/3, pages:PAGE-006/actions/4, pages:PAGE-006/actions/5, pages:PAGE-006/fields/0, pages:PAGE-006/fields/1, pages:PAGE-006/fields/2, pages:PAGE-006/fields/3, rules:BR-024, rules:BR-034, scenarios:SC-011, scenarios:SC-011/alternate_flows/0, scenarios:SC-011/alternate_flows/0/steps/0, scenarios:SC-011/alternate_flows/1, scenarios:SC-011/alternate_flows/1/steps/0, scenarios:SC-011/alternate_flows/1/steps/1, scenarios:SC-011/alternate_flows/2, scenarios:SC-011/alternate_flows/2/steps/0, scenarios:SC-011/alternate_flows/2/steps/1, scenarios:SC-011/main_flow/0, scenarios:SC-011/main_flow/1, scenarios:SC-011/main_flow/2, scenarios:SC-011/main_flow/3, scenarios:SC-011/main_flow/4, scenarios:SC-011/main_flow/5, scenarios:SC-011/postconditions/0, scenarios:SC-011/postconditions/1, scenarios:SC-011/postconditions/2, scenarios:SC-011/postconditions/3, scenarios:SC-011/preconditions/0, scenarios:SC-011/preconditions/1, sequences:SEQ-013, sequences:SEQ-013/messages/0, sequences:SEQ-013/messages/1, sequences:SEQ-013/messages/10, sequences:SEQ-013/messages/11, sequences:SEQ-013/messages/12, sequences:SEQ-013/messages/13, sequences:SEQ-013/messages/2, sequences:SEQ-013/messages/3, sequences:SEQ-013/messages/4, sequences:SEQ-013/messages/5, sequences:SEQ-013/messages/6, sequences:SEQ-013/messages/7, sequences:SEQ-013/messages/8, sequences:SEQ-013/messages/9, stories:US-014, stories:US-014/preconditions/0, acceptance:AC-107, acceptance:AC-108, acceptance:AC-137

验证：CHECK-107, CHECK-108, CHECK-137

## 实施任务

未声明；请结合范围说明核对。
