# LOCAL-DICT-CREATE 新增取数接口条目

**READY_FOR_ENGINEERING_DESIGN — 产品可交接，工程设计需补齐**

[返回阅读入口](../README.md) · [功能目录](../features/README.md) · [全局逻辑](../global-logic.md)

- [新增业务数据接口条目 · FUNC\-023](../features/FUNC-023.md)

## 职责与触发

所属工程模块：开发接手后确定

功能：FUNC-023

触发：超管点击新增并提交四项配置

## 前置条件

- 当前账号、企业/租户/对象和处理阶段有对应权限；输入来自本局部声明的当前对象。
- 沿当前已确认范围执行；不借原型或历史ID扩张权限。

## 必须遵守的全局规则

- [BR-023](../global-logic.md#BR-023)
- [BR-024](../global-logic.md#BR-024)
- [BR-034](../global-logic.md#BR-034)

## 输入与输出

输入：[FIELD-DICT-NAME](../field-specs.md#FIELD-DICT-NAME)、[FIELD-CAPABILITY](../field-specs.md#FIELD-CAPABILITY)、[FIELD-TENANT-GRANTS](../field-specs.md#FIELD-TENANT-GRANTS)、[FIELD-DICT-ENABLED](../field-specs.md#FIELD-DICT-ENABLED)

输出：[FIELD-DICT-ID](../field-specs.md#FIELD-DICT-ID)、[FIELD-DICT-NAME](../field-specs.md#FIELD-DICT-NAME)、[FIELD-CAPABILITY](../field-specs.md#FIELD-CAPABILITY)、[FIELD-TENANT-GRANTS](../field-specs.md#FIELD-TENANT-GRANTS)、[FIELD-DICT-ENABLED](../field-specs.md#FIELD-DICT-ENABLED)

## 处理步骤

### LOCAL-DICT-CREATE-STEP-1

选择预置能力并填写可读名称、租户范围与启停状态

读取：FIELD-DICT-NAME, FIELD-CAPABILITY, FIELD-TENANT-GRANTS, FIELD-DICT-ENABLED；写入：无

规则：BR-023, BR-024, BR-034

### LOCAL-DICT-CREATE-STEP-2

校验名称及已接入能力、租户集合，生成稳定标识并保存四项配置

读取：FIELD-DICT-NAME, FIELD-CAPABILITY, FIELD-TENANT-GRANTS, FIELD-DICT-ENABLED；写入：FIELD-DICT-ID, FIELD-DICT-NAME, FIELD-CAPABILITY, FIELD-TENANT-GRANTS, FIELD-DICT-ENABLED

规则：BR-023, BR-024, BR-034

### LOCAL-DICT-CREATE-STEP-3

仅在保存成功后加入字典列表，使用仍受启停与授权约束

读取：FIELD-DICT-ID；写入：无

规则：BR-023, BR-024, BR-034

## 分支与异常

### LOCAL-DICT-CREATE-BRANCH-1

条件：空白/超长/全局重名或能力租户无效

结果：原表单说明问题，不创建条目

涉及字段：FIELD-DICT-NAME, FIELD-CAPABILITY, FIELD-TENANT-GRANTS

验证：CHECK-105, CHECK-127

### LOCAL-DICT-CREATE-BRANCH-2

条件：同一能力使用不同名称

结果：允许创建独立条目，不共享其后授权或启停结果

涉及字段：FIELD-CAPABILITY, FIELD-DICT-ID, FIELD-TENANT-GRANTS, FIELD-DICT-ENABLED

验证：CHECK-105, CHECK-127

### LOCAL-DICT-CREATE-BRANCH-3

条件：取消或保存异常

结果：保留原字典和当前输入，不显示新增成功

涉及字段：FIELD-DICT-NAME

验证：CHECK-127

## 完成后的状态

- 仅本次动作的合法结果生效；取消或核对/保存异常保留原对象与输入，不宣称成功。

## 字段定义

- [FIELD-CAPABILITY](../field-specs.md#FIELD-CAPABILITY)
- [FIELD-DICT-ENABLED](../field-specs.md#FIELD-DICT-ENABLED)
- [FIELD-DICT-ID](../field-specs.md#FIELD-DICT-ID)
- [FIELD-DICT-NAME](../field-specs.md#FIELD-DICT-NAME)
- [FIELD-TENANT-GRANTS](../field-specs.md#FIELD-TENANT-GRANTS)

## 来源与验证

来源条目：documents:interfaces~1interface-index.json, documents:memory~1business-rules.json, documents:memory~1feature-list.json, documents:memory~1normalized-user-stories.json, documents:memory~1project-facts.json, documents:outputs~1business-scenario-atlas.html, documents:outputs~1business-scenario-list.md, documents:outputs~1feature-list.md, documents:outputs~1menu-and-page-planning-reference.md, documents:outputs~1page-structure-atlas.html, documents:outputs~1product-structure-and-business-process-baseline.md, documents:planning~1existing-surface-evidence.json, documents:planning~1page-index.json, documents:project-version.json, documents:runtime~1open-items.json, documents:runtime~1traceability.json, documents:runtime~1verification-report.json, documents:scenarios~1SC-008.json, documents:scenarios~1SC-009.json, documents:scenarios~1SC-010.json, documents:scenarios~1SC-011.json, documents:scenarios~1SC-012.json, documents:scenarios~1SC-013.json, documents:scenarios~1SC-014.json, documents:scenarios~1SC-015.json, documents:scenarios~1SC-016.json, documents:scenarios~1scenario-index.json, features:FUNC-023, features:FUNC-023/boundary/business_rules/0, features:FUNC-023/boundary/business_rules/1, features:FUNC-023/boundary/business_rules/2, features:FUNC-023/boundary/business_rules/3, features:FUNC-023/boundary/exception_paths/0, flows:FLOW-005, flows:FLOW-005/steps/0, flows:FLOW-005/steps/1, flows:FLOW-005/steps/2, flows:FLOW-005/steps/3, flows:FLOW-005/steps/4, interfaces:API-017, pages:PAGE-006, pages:PAGE-006/actions/0, pages:PAGE-006/actions/1, pages:PAGE-006/actions/2, pages:PAGE-006/actions/3, pages:PAGE-006/actions/4, pages:PAGE-006/actions/5, pages:PAGE-006/fields/0, pages:PAGE-006/fields/1, pages:PAGE-006/fields/2, pages:PAGE-006/fields/3, rules:BR-023, rules:BR-024, rules:BR-034, scenarios:SC-008, scenarios:SC-008/alternate_flows/0, scenarios:SC-008/alternate_flows/0/steps/0, scenarios:SC-008/alternate_flows/1, scenarios:SC-008/alternate_flows/1/steps/0, scenarios:SC-008/alternate_flows/1/steps/1, scenarios:SC-008/main_flow/0, scenarios:SC-008/main_flow/1, scenarios:SC-008/main_flow/2, scenarios:SC-008/main_flow/3, scenarios:SC-008/main_flow/4, scenarios:SC-008/postconditions/0, scenarios:SC-008/postconditions/1, scenarios:SC-008/postconditions/2, scenarios:SC-008/preconditions/0, scenarios:SC-008/preconditions/1, sequences:SEQ-010, sequences:SEQ-010/messages/0, sequences:SEQ-010/messages/1, sequences:SEQ-010/messages/10, sequences:SEQ-010/messages/11, sequences:SEQ-010/messages/12, sequences:SEQ-010/messages/2, sequences:SEQ-010/messages/3, sequences:SEQ-010/messages/4, sequences:SEQ-010/messages/5, sequences:SEQ-010/messages/6, sequences:SEQ-010/messages/7, sequences:SEQ-010/messages/8, sequences:SEQ-010/messages/9, stories:US-013, stories:US-013/preconditions/0, stories:US-013/preconditions/1, acceptance:AC-105, acceptance:AC-106, acceptance:AC-127

验证：CHECK-105, CHECK-106, CHECK-127, CHECK-131

## 实施任务

未声明；请结合范围说明核对。
